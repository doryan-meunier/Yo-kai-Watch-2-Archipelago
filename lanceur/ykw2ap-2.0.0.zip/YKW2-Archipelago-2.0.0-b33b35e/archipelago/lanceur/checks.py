"""Tracker des checks (onglet « Checks » du lanceur), SANS affichage : lecture de `checks.json` (écrit par le client,
`client/checks_local.py`) et de `progression.json`, plan de la graine d'après la logique de l'APWorld, état de chaque
location (faite / accessible maintenant / plus tard dans l'histoire / objets manquants), filtres, compteurs, objets
reçus. La vue tkinter est dans `vue_checks.py`. Bibliothèque standard seulement.

**Aucun spoiler** : le contenu d'une location n'est connu ici que si elle est faite ou indiquée par un hint (c'est
tout ce que le client écrit dans `checks.json`) ; le spoiler log complet est un fichier `.txt` séparé, écrit par le
client sur demande explicite (`demander_spoiler`).
"""
from __future__ import annotations

import collections
import sys
from dataclasses import dataclass, field
from pathlib import Path

_CLIENT = Path(__file__).resolve().parents[1] / "client"
if str(_CLIENT) not in sys.path:
    sys.path.insert(0, str(_CLIENT))

import checks_local as ck  # noqa: E402  (client/, distribué avec le lanceur)

from . import tracker as TK  # noqa: E402

NOM_CHECKS = ck.NOM_CHECKS
FICHIERS = (ck.NOM_CHECKS, TK.NOM_PROGRESSION, TK.NOM_INVITES)
TYPES = ck.TYPES
ETATS = ("fait", "accessible", "plus_tard", "bloque", "inconnu")
# `logique.PORTAILS` de l'APWorld : checks tardifs des portails mystères ; « tunnel » : boss du bout du Tunnel sans fin
PORTAILS = ("donjon", "salle", "crank", "requetes", "tunnel")
AUTRES = "__autres__"
FAMILLE_EVENEMENT = "evenement"             # objets des Yo-kai d'évènement (option `objets_evenement` de l'APWorld)
FAMILLE_INVITATION = "invitation"           # objets « Invitation : <Yo-kai> » (option `invites` de l'APWorld)
NOM_ORIGINE = {"fr": "Histoire et objets-clés", "en": "Story and key items"}


# Checks « Ami » dont le Yo-kai, posé à sa place du jeu d'origine par son objet AP, attend que cette place soit libre
# (n° du Médaillium -> texte `ck_e_app_<clé>` ; docs/systemes/archipelago_evenement_invitation.md §10) : Jibanyan S
# (433) quand Jibanyan est ami, Hovernyan (351) une fois le chapitre 6 terminé. Vrai pour toute graine, ancienne ou
# nouvelle, jouée avec un patch à jour.
APPARITION = {433: "jibanyan", 351: "hovernyan"}


@dataclass
class Check:
    id: int
    nom: str
    zone: str                                  # clé de région de l'APWorld (AUTRES : absente du plan local)
    type: str                                  # coffre | objet_cle | boss | requete | tablo | chapitre | velo
    etat: str                                  # fait | accessible | plus_tard | bloque | inconnu
    contenu: str | None = None                 # « objet » ou « objet (pour joueur) » : fait ou indiqué SEULEMENT
    indice: bool = False                       # contenu connu par un indice (hint)
    exclue: bool = False                       # remplissage seulement (APWorld)
    # check « tardif » des portails mystères (APWorld, `logique.PORTAILS`) : donjon | salle | crank | requetes | tunnel ; None sinon
    portail: str | None = None
    # Yo-kai d'évènement à sa place d'origine qui n'apparaît pas dès l'objet reçu (APPARITION) : jibanyan | hovernyan
    apparition: str | None = None
    chapitres: int = 0                         # chapitres terminés exigés par la règle (et les connexions)
    manque: tuple[str, ...] = ()               # noms des objets manquants (bloque)
    rangs: int = 0                             # exemplaires de « Rang de montre » manquants (bloque)


@dataclass
class Recu:
    n: int
    objet: str
    expediteur: str
    lieu: str
    soi: bool


@dataclass
class Invitation:
    """Un objet « Invitation : <Yo-kai> » de la graine (rubrique « Invitations » du sous-onglet « Carte »)."""
    cle: str                                   # clé de l'objet de l'APWorld
    nom: str                                   # nom de l'objet (« Invitation : Noko »)
    yokai: str                                 # nom du Yo-kai invité
    recus: int = 0                             # exemplaires reçus (checks.json)
    medaille: int | None = None                # n° du Médaillium de l'invité (None : inconnu de la logique locale)
    # état de l'invité d'une invitation REÇUE, si le lanceur le connaît déjà (`invites.json` du client, ou check
    # « Ami : <nom> » fait) : attente | file | present | ami ; None : inconnu (ou invitation pas reçue)
    etat: str | None = None
    piece: int | None = None                   # présent : 0 la Suite, 1..9 les chambres 101..109
    rang: int | None = None                    # dans la file : rang (1..)


@dataclass
class ModeleChecks:
    present: bool = False                      # checks.json lisible
    connecte: bool = False
    spoiler: bool = False                      # le client a le contenu de toutes les locations (spoiler log possible)
    joueur: str = ""
    graine: str = ""
    checks: list[Check] = field(default_factory=list)
    zones: list[tuple[str, str]] = field(default_factory=list)     # (clé, nom) dans l'ordre de l'APWorld
    recus: list[Recu] = field(default_factory=list)
    chapitres_reels: int | None = None         # chapitres vraiment terminés (None : inconnus -> sens « en logique »)
    plan_ok: bool = False                      # logique de l'APWorld disponible et plan reconstruit
    objets_recus: dict[str, int] = field(default_factory=dict)     # clé d'objet de l'APWorld -> exemplaires reçus
    # objets des Yo-kai d'évènement de la graine (famille « evenement » dans le pool, ordre de l'APWorld) : section à
    # part de la colonne d'objets du sous-onglet « Carte » ; vide : option inactive (section cachée)
    objets_evenement: list[str] = field(default_factory=list)
    # invitations de la graine (famille « invitation » dans le pool, ordre de l'APWorld = ordre de la file en jeu) :
    # rubrique « Invitations » de la même colonne ; vide : graine sans l'option `invites` (rubrique absente)
    invitations: list[Invitation] = field(default_factory=list)
    horodatage: float = 0.0
    langue: str = "fr"

    @property
    def sans_donnees(self) -> bool:
        """Pas encore de checks de la partie (pas de `checks.json` valide, ou client jamais connecté à la graine :
        aucune location) : l'onglet l'explique au lieu d'une liste et d'une carte vides."""
        return not self.present or not self.checks

    def compter(self, checks: list[Check] | None = None) -> dict[str, int]:
        c = collections.Counter(x.etat for x in (self.checks if checks is None else checks))
        c["total"] = len(self.checks if checks is None else checks)
        return c

    def nom_zone(self, cle: str) -> str:
        return dict(self.zones).get(cle, cle)


# Yo-criminels (docs/systemes/archipelago_criminels_combats_jour.md) : le criminel du moment est un personnage posé
# dans la rue, sur les 5 cartes de la ville (6 points possibles par carte) ; clés de région de l'APWorld de ces cartes
# (t101g00, t103g00, t104g00, t105g00, t106g00), dans l'ordre du jeu.
ZONES_CRIMINELS = ("les_hauts_de_granval", "coteau_fleuri", "centre_ville_de_granval", "quartier_des_boutiques",
                   "la_corniche")


def ou_chercher(m: ModeleChecks, c: Check) -> list[str]:
    """Noms des zones où chercher un check qui n'a pas de lieu fixe : les 5 cartes de la ville pour un Yo-criminel
    (sa « zone » dans l'APWorld n'est que la région de sa règle de logique) ; [] pour les autres checks."""
    if c.type != "criminel":
        return []
    return [m.nom_zone(z) for z in ZONES_CRIMINELS]


def signature(dossier: Path) -> tuple:
    out = []
    for n in FICHIERS:
        try:
            st = (Path(dossier) / n).stat()
            out.append((st.st_size, st.st_mtime_ns))
        except OSError:
            out.append(None)
    return tuple(out)


def _texte_contenu(c: dict, langue: str) -> str:
    return ck.contenu_texte(str(c.get("objet") or "?"), c.get("joueur"), bool(c.get("soi")), langue)


def construire(d: dict | None, progression: dict | None, langue: str = "fr", logique=None,
               invites: dict | None = None) -> ModeleChecks:
    """Modèle de l'onglet à partir de `checks.json` (`d`) et de `progression.json` (même partie seulement) ;
    `invites` : `invites.json` du client (état des invités de l'Auberge, même partie seulement), None : inconnu."""
    m = ModeleChecks(langue=langue)
    if not d or d.get("format") != ck.FORMAT_CHECKS or not isinstance(d.get("locations"), list):
        return m
    m.present = True
    m.connecte, m.spoiler = bool(d.get("connecte")), bool(d.get("spoiler_disponible"))
    m.joueur, m.graine = str(d.get("joueur") or ""), str(d.get("graine") or "")
    m.horodatage = float(d.get("horodatage") or 0.0)
    L = logique or ck.logique_apworld()
    ids_objets = {}
    cles_evenement: list[str] = []
    objets_invitation: list[dict] = []
    if L is not None:
        try:
            from importlib import import_module
            don = import_module(ck.PAQUET_PUR + ".donnees").donnees()
            ids_objets = {int(o["id_ap"]): o["cle"] for o in don.objets}
            cles_evenement = [o["cle"] for o in don.objets if o.get("famille") == FAMILLE_EVENEMENT]
            objets_invitation = [o for o in don.objets if o.get("famille") == FAMILLE_INVITATION]
        except Exception:                                  # noqa: BLE001
            ids_objets, cles_evenement, objets_invitation = {}, [], []
    toutes = [int(x) for x in d["locations"]]
    faites = {int(x) for x in d.get("faites") or []}
    contenus = {int(k): v for k, v in (d.get("contenus_faits") or {}).items() if isinstance(v, dict)}
    indices = {int(k): v for k, v in (d.get("indices") or {}).items() if isinstance(v, dict)}
    recus_brut = [r for r in d.get("recus") or [] if isinstance(r, dict)]
    m.recus = [Recu(int(r.get("n", i + 1)), str(r.get("objet") or "?"), str(r.get("expediteur") or "?"),
                    str(r.get("location") or ""), bool(r.get("soi"))) for i, r in enumerate(recus_brut)]
    m.objets_recus = dict(collections.Counter(ids_objets[int(r["id"])] for r in recus_brut
                                              if isinstance(r.get("id"), int) and int(r["id"]) in ids_objets))
    plan = ck.construire_plan(d.get("options"), langue, L)
    m.objets_evenement = objets_evenement_graine(d.get("options"), plan, cles_evenement, m.objets_recus)
    # progression réelle : sauvegarde liée de CETTE partie, et checks « Histoire : chapitre N terminé » faits
    prog = progression if isinstance(progression, dict) and progression.get("format") == TK.FORMAT_PROGRESSION \
        and progression.get("ident_partie") in (None, d.get("ident_partie")) else None
    acces: dict[int, ck.Acces] = {}
    places: dict[int, object] = {}
    if plan is not None:
        m.plan_ok = True
        # région d'origine de l'APWorld (« Menu ») : dons d'objets-clés et checks d'histoire, sans lieu précis
        m.zones = [(cle, NOM_ORIGINE.get(langue, NOM_ORIGINE["fr"]) if cle == "menu" else nom) for cle, nom in plan.regions]
        places = {loc.id_ap: loc for loc in plan.locations if loc.id_ap is not None}
        chap_faits = [int(loc.cle) for i, loc in places.items() if i in faites and loc.genre == "histoire"]
        m.chapitres_reels = ck.chapitres_termines(prog, chap_faits)
        objets = [ids_objets[int(r["id"])] for r in recus_brut
                  if isinstance(r.get("id"), int) and int(r["id"]) in ids_objets]
        acces = ck.evaluer(plan, objets, m.chapitres_reels)
    for i in toutes:
        loc = places.get(i)
        if i in faites:
            etat = "fait"
        elif loc is None or i not in acces:
            etat = "inconnu"
        else:
            etat = acces[i].etat
        a = acces.get(i)
        contenu, indice = None, False
        if i in faites and i in contenus:
            contenu = _texte_contenu(contenus[i], langue)
        if i in indices:
            indice = True
            if contenu is None:
                contenu = _texte_contenu(indices[i], langue)
        manque = tuple(L.nom_objet(k, langue) if L is not None else k for k in (a.objets if a else ()))
        m.checks.append(Check(
            id=i, nom=loc.nom if loc is not None else f"#{i}", zone=loc.region if loc is not None else AUTRES,
            type=ck.type_de(loc) if loc is not None else "coffre", etat=etat, contenu=contenu, indice=indice,
            exclue=bool(loc.exclue) if loc is not None else False,
            portail=getattr(loc, "portail", None) if loc is not None else None,
            apparition=APPARITION.get(getattr(loc, "medaille", None))
            if loc is not None and loc.genre == "ami" and not getattr(loc, "medailles", ()) else None,
            chapitres=a.chapitres if a else 0,
            manque=manque if etat == "bloque" else (), rangs=a.rangs if a and etat == "bloque" else 0))
    m.invitations = invitations_graine(plan, objets_invitation, m.objets_recus, L, langue)
    etats_invitations(m.invitations, TK.lire_invites(invites, d.get("ident_partie")),
                      {loc.medaille for i, loc in places.items()
                       if i in faites and loc.genre in ("invite", "ami") and getattr(loc, "medaille", None)})
    if any(c.zone == AUTRES for c in m.checks):
        m.zones.append((AUTRES, "Autres locations" if langue != "en" else "Other locations"))
    return m


def objets_evenement_graine(options, plan, cles: list[str], recus: dict[str, int]) -> list[str]:
    """Objets d'évènement de la graine (`cles` : ceux de l'APWorld, dans son ordre). Option publiée (slot_data 18) :
    ceux du pool du plan (tous s'il n'y a pas de plan), aucun si elle est inactive ; graine plus ancienne (option
    inconnue) : tous, mais seulement si l'un d'eux a été reçu (sinon section cachée). Seulement des objets DE CE MONDE
    que le joueur peut recevoir : aucun spoiler (ni lieu ni contenu)."""
    opt = options.get("objets_evenement") if isinstance(options, dict) else None
    if opt is None:
        return list(cles) if any(recus.get(k, 0) for k in cles) else []
    if not opt:
        return []
    if plan is None:
        return list(cles)
    pool = set(getattr(plan, "pool_objets_cles", ()) or ())
    return [k for k in cles if k in pool]


def invitations_graine(plan, objets: list[dict], recus: dict[str, int], logique, langue: str) -> list[Invitation]:
    """Invitations de la graine (`objets` : ceux de la famille « invitation » de l'APWorld, dans son ordre). Leur
    présence vient de la GRAINE : objets du pool du plan reconstruit d'après ses options (`invites_mode` et
    `evenement_places` de slot_data), plus tout objet d'invitation déjà reçu (plan absent, logique locale d'une autre
    version) ; une graine sans l'option, ou d'avant, n'en a aucune. Seulement des objets DE CE MONDE que le joueur
    peut recevoir, reçus ou non : aucun spoiler (ni lieu ni contenu)."""
    pool = set(getattr(plan, "pool_objets_cles", ()) or ()) if plan is not None else set()
    # Yo-kai invité de chaque objet : tables de l'APWorld (invités de l'Auberge, Yo-kai d'évènement à leur place)
    par_objet: dict[str, dict] = {}
    for table in (getattr(logique, "INVITES", ()), getattr(logique, "AMIS", ())):
        for a in table or ():
            if isinstance(a, dict) and a.get("objet") and "base_invite" not in a:
                par_objet.setdefault(a["objet"], a)
    out = []
    for o in objets:
        cle = o["cle"]
        n = int(recus.get(cle, 0))
        if cle not in pool and not n:
            continue
        nom = o["nom_en"] if langue == "en" else o["nom_fr"]
        a = par_objet.get(cle) or {}
        yokai = a.get("yokai_en" if langue == "en" else "yokai_fr") or nom.split(":", 1)[-1].strip()
        med = a.get("medaille")
        out.append(Invitation(cle, nom, str(yokai), n, med if isinstance(med, int) else None))
    return out


def etats_invitations(invitations: list[Invitation], invites: list[dict], amis: set) -> None:
    """État de l'invité de chaque invitation REÇUE, d'après ce que le lanceur a déjà (`invites` : `tracker.lire_invites`
    de `invites.json` ; `amis` : n° du Médaillium des checks « Ami » faits) ; rien pour une invitation pas reçue."""
    par_medaille = {x["medaille"]: x for x in invites}
    for inv in invitations:
        if not inv.recus or inv.medaille is None:
            continue
        x = par_medaille.get(inv.medaille)
        if x is not None:
            inv.etat, inv.piece, inv.rang = x["etat"], x.get("piece"), x.get("rang")
        if inv.medaille in amis:
            inv.etat, inv.piece, inv.rang = "ami", None, None


def charger(dossier: str | Path, langue: str = "fr") -> ModeleChecks:
    d = Path(dossier)
    return construire(ck.lire_json(d / ck.NOM_CHECKS), TK.lire_json(d / TK.NOM_PROGRESSION), langue,
                      invites=TK.lire_json(d / TK.NOM_INVITES))


# ------------------------------------------------------------------------------------------------ filtres
@dataclass
class Filtre:
    texte: str = ""
    type: str | None = None                    # un de TYPES, ou None (tous)
    zone: str | None = None
    pas_faits: bool = False
    accessibles: bool = False

    def garde(self, c: Check, m: ModeleChecks) -> bool:
        if self.type and c.type != self.type:
            return False
        if self.zone and c.zone != self.zone:
            return False
        if self.pas_faits and c.etat == "fait":
            return False
        if self.accessibles and c.etat != "accessible":
            return False
        if self.texte:
            t = TK.replier(self.texte)
            cible = " ".join((c.nom, m.nom_zone(c.zone), c.contenu or ""))
            if t not in TK.replier(cible):
                return False
        return True


def par_zone(m: ModeleChecks, f: Filtre) -> list[tuple[str, str, list[Check], dict[str, int]]]:
    """[(clé de zone, nom, checks gardés, compteurs de TOUTE la zone)] dans l'ordre des régions de l'APWorld ; zones
    sans check gardé omises. Dans une zone : non faits d'abord (accessibles, plus tard, bloqués), puis faits."""
    ordre = {e: i for i, e in enumerate(("accessible", "plus_tard", "bloque", "inconnu", "fait"))}
    out = []
    for cle, nom in m.zones:
        tous = [c for c in m.checks if c.zone == cle]
        gardes = sorted((c for c in tous if f.garde(c, m)), key=lambda c: (ordre.get(c.etat, 9), c.nom))
        if gardes:
            out.append((cle, nom, gardes, m.compter(tous)))
    return out


def types_presents(m: ModeleChecks) -> list[str]:
    presents = {c.type for c in m.checks}
    return [t for t in TYPES if t in presents]
