"""Lanceur du mod Archipelago de Yo-kai Watch 2 (voir README.md). `logique.py` : sans affichage ; `vue.py` :
fenêtre tkinter ; `demarrage.py` : point d'entrée."""
