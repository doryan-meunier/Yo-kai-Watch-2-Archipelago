"""Installation du mod Archipelago de Yo-kai Watch 2 (bibliothèque standard seulement).

- `rom3ds`    : extraction de code.bin et exheader.bin depuis la ROM déchiffrée du joueur (I1) ;
- `bps`       : décodeur de patchs BPS (partagé avec tools/ap_patch.py) ;
- `installer` : application des patchs, dépôt dans le dossier mods d'Azahar, désinstallation (I2) ;
- `azahar`    : détection d'Azahar, lecture de qt-config.ini, stub GDB (I3).
"""
