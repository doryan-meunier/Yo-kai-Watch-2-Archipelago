# -*- coding: utf-8 -*-
"""Logique de la V1, sans Archipelago (tâche A2) : quelles locations, quels objets, quelles règles.

Ce module ne dépend que de la bibliothèque standard. `__init__.py` traduit le `Plan` en régions, locations et
règles Archipelago ; les tests hors ligne (`archipelago/tests/test_apworld_logique.py`) le vérifient
directement, avec un petit remplissage simulé.

Sources : `archipelago/CONCEPTION.md` §3 à §5, `docs/systemes/archipelago_objets_cles.md` (J1 : voies de don,
verrous, règles anti-blocage R1 à R7) et les JSON de `donnees/` (import A1 de l'ancien mod).

Principe (règle R2 de J1) : **la logique n'exige un objet que si le jeu bloque vraiment sans lui.**
- Objets testés par possession par le jeu (portes à clé, PNJ) : toujours exigés, toujours sûrs.
- Objets dont le verrou est à coder côté jeu (J4) ou à vérifier en jeu (T4) : mélangés et exigés seulement
  si l'option `verrous_actifs` les cite (elle doit décrire le patch réellement installé). Sinon, l'objet
  reste à son emplacement d'origine et la logique ne l'exige pas.
- Herbe ancestrale et Super tournevis, Clé salle du trésor et Poignée étrange : verrous de déclencheur de la V1.1
  (`docs/systemes/archipelago_objets_cles_v11.md` §11 et §13).
- Rangs de montre (V1.1, §14 et §17) : objet PROGRESSIF « Rang de montre » (4 exemplaires : D, C, B, A). Depuis le
  mode « rang réel » (§17, slot_data format 20) l'objet EST le rang de la montre : le jeu monte le vrai rang au nombre
  reçu (1 = D … 4 = A) et les montées de rang de l'histoire et des requêtes ne sont plus que des checks ; tout ce que
  le jeu soumet au rang (portes de montre, requêtes, requêtes clés des chapitres 4, 7 et 9) exige les exemplaires.
  Ancien mode (graines de format <= 19, `rangs_reel=False`) : les verrous de montre exigeaient le rang AP en plus du
  rang réel. 32 coffres dorés (et la Clinique du Crépuscule) deviennent des locations quand ce verrou est actif.
- Vélo (V1.1, §15 et §15 bis) : objet « Vélo » (le bouton vélo et la montée sont refusés tant qu'il n'est pas reçu ;
  mode « vélo réel », format 21 : le recevoir donne vraiment le vélo, la requête qs0009 ne le donne plus) et location
  « Objet-clé : Vélo » (fin de la requête qs0009), ajoutés ensemble quand ce verrou est actif ; aucune location n'exige
  le vélo (même logique dans les deux modes).
"""
from dataclasses import dataclass, field
from typing import Dict, FrozenSet, List, Optional, Set, Tuple

from .amis_criminels import (AMIS, AMIS_PAR_DEFAUT, CRIMINELS, CRIMINELS_CHAPITRE_MIN, CRIMINELS_PAR_DEFAUT,
                             INVITES, INVITES_PAR_DEFAUT, INVITES_PAR_MEDAILLE, MODES_AMIS, MODES_CRIMINELS,
                             PLACES_PAR_OBJET)
from .boutiques import (BOUTIQUES_ARTICLES, BOUTIQUES_PAR_CODE, BOUTIQUES_PAR_DEFAUT, MODES_BOUTIQUES,
                        PRIX_MAX_PAR_DEFAUT, articles_du_mode, chapitre_article, ids_retires, exclu as boutique_exclue)
from .donnees import donnees

# ---------------------------------------------------------------------------
# Noms des jeux (un par langue, mêmes identifiants numériques)
# ---------------------------------------------------------------------------
NOM_JEU = {"fr": "Yo-kai Watch 2", "en": "Yo-kai Watch 2 (English)"}
FAMILLE_JEU = "Yo-kai Watch 2"

# Objet « vitrine » affiché par un coffre dont l'objet n'est pas livré au joueur par ce coffre (objet d'un
# autre monde, argent) : « Important Item 20 », jamais donné par le jeu (J1 §6.1).
HACHAGE_VITRINE = 0xA0531A08

# Texte d'une vitrine : même limite que le bandeau (55 octets UTF-8 utiles, archipelago_boite.md §6bis).
TEXTE_OCTETS_MAX = 55

# Option `objets_evenement` (archipelago_amis_criminels.md §7.4) : activée par défaut (décision de l'humain, 2026-09-29).
OBJETS_EVENEMENT_PAR_DEFAUT = True
# Yo-kai d'évènement à leur emplacement d'origine (archipelago_evenement_invitation.md §9) : dans toute nouvelle graine
# (pas une option du joueur : les trois invitations suivent `invites`, la Capsule favorite `objets_evenement`).
PLACES_PAR_DEFAUT = True

# ---------------------------------------------------------------------------
# Verrous (J1 §0, §3.2, §10 et §11)
# ---------------------------------------------------------------------------
# Le jeu vérifie déjà la possession (condition IsHaveItem) : ne pas donner l'objet suffit [C].
VERROUS_POSSESSION = frozenset({
    "cle_de_derriere", "cle_magnetique_or", "jolie_petite_cle", "jolie_grande_cle",
    "cle_appartement_c_101", "cle_appartement_c_303", "cle_appartement_b_301", "cle_appartement_b_204",
    "huile_de_tendino", "tenue_de_rocker",
    # porte de t105d12 (A-201) : t105g00_trigger n° 68/69 (rangs 76/77 du fichier), IsHaveItem [C] ; clé seulement dans le coffre 216 (Clinique)
    "cle_appartement_a_201",
    # Objets-clés de quête (branche ap/objets-cles-quetes, archipelago_objets_cles_v11.md §16) :
    # - Clé magnétique rouge : console des égouts, t100d00_trigger n° 41 (IsHaveItem) [C] ; porte rouge (flag 1279)
    #   qui s'ouvre aussi de l'autre côté (n° 31, sans objet) : aucune location ne l'exige ;
    # - huit objets du Musée en détresse (quête 40) : remise au conservateur, TALK_CONFIG de t106d31 (IsHaveItem) [C] ;
    #   la quête ne finit qu'avec les dix objets exposés (QUEST_NECESSARY_CONDITION : dix flags d'exposition) [C].
    "cle_magnetique_rouge", "poster_de_film", "bobine_de_film", "bouteille_de_y_cola", "affiche_de_restaurant",
    "louloutre", "pot_canard", "figurine_de_photortue", "robe_de_star",
})
# Objets du Musée en détresse (quête 40) : les dix objets exposés sont exigés [C, t106d31_npc_talk, quest_config].
# La Silhouette de héros n'est pas mélangée (donnée DEUX fois dans la quête 46, retirée entre les deux : une
# substitution par hachage priverait la quête 46 et le musée) ; la Tenue de rocker est un coffre (t201g00).
OBJETS_MUSEE = ("tenue_de_rocker", "poster_de_film", "bobine_de_film", "bouteille_de_y_cola", "affiche_de_restaurant",
                "louloutre", "pot_canard", "figurine_de_photortue", "robe_de_star")

# Verrous à coder côté jeu (J4) ou à confirmer en jeu (T4). Valeurs de l'option `verrous_actifs`.
# mecanisme : description courte ; flag : index de flag bit global lu par l'action (J1 §2.2) quand il est
# connu [C] ; chapitre : chapitre du plafond de phase (g) ; code_jeu : le verrou est appliqué par le CODE du
# patch (le client refuse une partie qui en exige un que le jeu installé n'a pas compilé, boîte §20) ;
# implemente : False = aucun verrou n'existe dans le patch, l'option est acceptée (anciens YAML) mais IGNORÉE
# (objet laissé à sa place, jamais exigé, absent de slot_data). Détail : archipelago_objets_cles.md §13.
VERROUS_A_ACTIVER: Dict[str, dict] = {
    # masque du flag 28 (points de recherche à la loupe : insectes, pêche, et tout ce qui passe par ces points), dès le
    # début, tutoriel du chapitre 1 compris (ap/filet-tutoriel, objets_cles §12.7) : sans le Filet, l'histoire s'arrête
    # en phase 1-50 ; seule location faisable avant : son emplacement (c01 n° 16), la règle « prologue » exige le Filet
    # partout ailleurs
    "filet_a_insectes": {"mecanisme": "masque_flag", "flag": 28, "code_jeu": True},
    # masque du flag 29 (pêche à la loupe) ; aucune séquence d'histoire ne le lit [C]
    "canne_a_peche": {"mecanisme": "masque_flag", "flag": 29, "code_jeu": True},
    # commande 0x3CEF (flag 21, menus de combat), exemptée jusqu'au combat ev06_btl0040 (R1)
    "modele_zero": {"mecanisme": "commande_0x3CEF", "flag": 21, "code_jeu": True},
    # phase 3-40 lue 3-30 : zones de fermeture de l'école actives, suite de l'histoire du chapitre 3 bloquée
    "cles_de_l_ecole": {"mecanisme": "plafond_phase", "chapitre": 3, "code_jeu": True},
    # V1.1 : déclencheur de phase c03_trigger n° 21 ignoré (FUN_00448988) : on entre et on sort de la maison
    # de Coteau fleuri (t103i21) sans la scène ev03_1400 ; suite du chapitre 3 bloquée (objets_cles_v11 §11)
    "herbe_ancestrale": {"mecanisme": "declencheur", "chapitre": 3, "code_jeu": True},
    # V1.1 : c03_trigger n° 27 (2 zones du Quartier des boutiques, t105g00) ignoré : pas d'Heure funeste
    # scénarisée ; suite du chapitre 3 bloquée, rang D (n° 33) retardé (objets_cles_v11 §11)
    "super_tournevis": {"mecanisme": "declencheur", "chapitre": 3, "code_jeu": True},
    # V1.1 : phase 4-50 lue 4-40 (routes et refoulements du Centre-ville actifs) ET c04_trigger n° 14, 15, 17, 18
    # (arrivée au Centre-ville, sur flags) ignorés, jusqu'à l'arrivée ev60_0400 : le Centre-ville reste fermé comme

    # avant la seconde remise d'objets à Maman ; suite du chapitre 4 bloquée (objets_cles_v11 §3, §12)
    "indications_de_maman": {"mecanisme": "plafond_phase_et_declencheur", "chapitre": 4, "code_jeu": True},
    # V1.1 : déclencheur de QUÊTE t102d31 n° 5 (zone du combat de Volteface, quête qs0051 en phase 5) ignoré : la
    # quête 51 ne peut pas finir, ni donc la quête 52 (Misterre) qui l'exige (objets_cles_v11 §13)
    "cle_salle_du_tresor": {"mecanisme": "declencheur_quete", "quete": 51, "code_jeu": True},
    # V1.1 : déclencheur de QUÊTE t105d41 n° 7 (point de la Poignée, qs0057 en phase 9, la nuit) ignoré : la phase
    # reste 9, la route vers Firmain reste fermée ; ni la quête 57 ni la 58 (Ombraptor) ne finissent (v11 §13)
    "poignee_etrange": {"mecanisme": "declencheur_quete", "quete": 57, "code_jeu": True},
    # V1.1 : rangs de montre. Objet PROGRESSIF sans spot (k = 18 dans la boîte, recu[18] = nombre reçu) + modes
    # « portes D » (k = 19, VERROU_RANGS_D_SLOT) et « rang réel » (k = 20, VERROU_RANG_REEL_SLOT, objets_cles_v11 §17) :
    # le jeu monte le rang RÉEL de la montre à min(nombre reçu, A) et ignore les montées de rang de ses scripts
    # (commande 0x364C) ; les verrous de montre (OP_WATCHLOCK_POINT, commande 0x3700) de rang D, C, B, A restent
    # fermés tant que le nombre reçu est inférieur (1 = D … 4 = A). Option indépendante de `objets_cles_melanges`
    # (objets_cles_v11 §5, §14, §17).
    "rangs": {"mecanisme": "verrou_de_montre", "cle_objet": "rang_de_montre", "k": 18, "progressif": True,
              "exemplaires": 4, "code_jeu": True},
    # V1.1 : flags 39 et 40 (bouton vélo du menu terrain : affiché / utilisable) lus 0 et commande 0x3564 (montée)
    # refusée tant que le Vélo n'est pas reçu ; la descente reste permise. Objet sans emplacement ni don dans le jeu
    # (k = 12 dans la boîte, réserve 570..575). Mode « vélo réel » (k = 21, VERROU_VELO_REEL_SLOT, objets_cles_v11
    # §15 bis) : à la réception, le JEU donne vraiment le vélo (flags 39 et 40, objet vélo) et le joueur roule tout de
    # suite ; la requête qs0009 (boutique de vélos de Coteau fleuri) ne le donne plus : c'est seulement un check (et le
    # choix du modèle). Option indépendante de `objets_cles_melanges` (objets_cles_v11 §6, §15, §15 bis).
    "velo": {"mecanisme": "masque_flag_et_commande_0x3564", "flags": [39, 40], "k": 12, "code_jeu": True},
    # Verrou « possession » SANS code de jeu (2026-10-01, décision de l'humain, archipelago_objets_cles.md §14.9) : en
    # phase 2-60, la Crank-a-kai du tutoriel (t102g00, c02_trigger n° 12) ouvre un menu qui n'accepte QUE la Pile ou
    # passe ; sans elle, le jeu ne permet pas d'avancer (vu en jeu par l'humain) : l'histoire s'arrête en 2-60. La pièce
    # reste mélangée et exigée (mêmes règles qu'avec l'ancien verrou k = 1, retiré du patch) ; `code_jeu` faux : le client
    # n'exige rien du build.
    "pile_ou_passe": {"mecanisme": "verifie_en_jeu", "chapitre": 2, "code_jeu": False},
}


def verrous_implementes() -> FrozenSet[str]:
    return frozenset(k for k, v in VERROUS_A_ACTIVER.items() if v.get("implemente", True))


def cle_objet_verrou(verrou: str) -> str:
    """Clé de l'objet qui ouvre ce verrou (la même que celle du verrou, sauf « rangs » : « rang_de_montre »)."""
    return VERROUS_A_ACTIVER[verrou].get("cle_objet", verrou)


# ---------------------------------------------------------------------------
# Rangs de montre (objets_cles_v11 §5 et §14)
# ---------------------------------------------------------------------------
# Rang AP = nombre de « Rang de montre » reçus (0 aucun, 1 D, 2 C, 3 B, 4 A) : un verrou de montre de rang D exige 1
# exemplaire, C 2, B 3, A 4 (objets_cles_v11 §14.8, décision de l'humain : rang D verrouillé aussi). Les verrous S
# (après-jeu) ne sont pas touchés par le mod.
# Mode « rang réel » (décision de l'humain, 2026-10-02, objets_cles_v11 §17 ; LE comportement du verrou « rangs » pour
# toute nouvelle graine) : rang réel de la montre = rang AP (le jeu l'écrit à la réception ; c03 n° 33 et les requêtes
# 25 / 26 / 27 ne le montent plus, ce ne sont que des checks). Tout « rang >= X » du jeu exige EXEMPLAIRES_RANG[X].
# Ancien mode (`rangs_reel=False` : graines de format <= 19, pour le tracker) : le rang réel venait du jeu (D : c03
# n° 33, OBJETS_RANG_D ; C, B, A : requêtes 25, 26, 27) et restait exigé EN PLUS du rang AP (EXEMPLAIRES_RANG_REEL,
# SEUIL_RANG_REEL).
VERROU_RANGS = "rangs"
OBJET_RANG = "rang_de_montre"
EXEMPLAIRES_RANG = {"D": 1, "C": 2, "B": 3, "A": 4}
# Entrée supplémentaire de `slot_data.verrous_actifs` quand le verrou « rangs » est actif (slot_data format 7) : mode
# « portes D » du jeu (k = 19 : rang AP = recu[18], portes D fermées aussi). Un jeu qui ne le compile pas est refusé
# par le client (« Verrous incompatibles ») ; un client antérieur le traite comme un verrou ordinaire (bit 19 posé,
# recu[19] = 0 / 1, ignoré par le jeu) : comportement correct. Sans cette entrée (graine antérieure), le jeu garde
# l'ancien calcul (D + nombre reçu, portes D d'origine), cohérent avec l'ancienne logique à 3 exemplaires.
VERROU_RANGS_D_SLOT = {"cle": "rangs_d", "k": 19, "mecanisme": "verrou_de_montre_mode_portes_d",
                       "cle_objet": "rang_de_montre", "code_jeu": True}
# Troisième entrée (slot_data format 20) : mode « rang réel » du jeu (k = 20 : rang réel de la montre monté à
# min(recu[18], A), montées de rang des scripts ignorées). Un jeu qui ne le compile pas est refusé par le client
# (« Verrous incompatibles ») : la logique de la graine compte sur lui ; un client antérieur le traite comme un verrou
# ordinaire (bit 20 exigé et posé, recu[20] = 0 / 1 ignoré par le jeu) : comportement correct. Sans cette entrée
# (graine antérieure), le jeu garde l'ancien comportement (rang réel donné par l'histoire et les requêtes).
VERROU_RANG_REEL_SLOT = {"cle": "rangs_reel", "k": 20, "mecanisme": "rang_de_montre_reel",
                         "cle_objet": "rang_de_montre", "code_jeu": True}
CLE_RANG_REEL = "rangs_reel"        # présente dans `slot_data.verrous_actifs` : graine en mode « rang réel »
# Seconde entrée du verrou « velo » (slot_data format 21) : mode « vélo réel » du jeu (k = 21 : à la réception du Vélo,
# le jeu pose les flags 39 et 40 et donne l'objet vélo ; avant, l'objet vélo de la boutique de la requête est retiré).
# Un jeu qui ne le compile pas est refusé par le client (« Verrous incompatibles ») : le joueur qui reçoit le Vélo doit
# pouvoir rouler sans faire la requête ; un client antérieur le traite comme un verrou ordinaire (bit 21 exigé et posé,
# recu[21] = 0 / 1 ignoré par le jeu) : comportement correct. Sans cette entrée (graine antérieure), le jeu garde
# l'ancien comportement (autorisation seulement : le vélo vient de la requête). La logique est la même dans les deux
# modes (aucune location n'exige le vélo ; la location reste la fin de la requête).
VERROU_VELO_REEL_SLOT = {"cle": "velo_reel", "k": 21, "mecanisme": "velo_reel", "cle_objet": "velo",
                         "code_jeu": True}
CLE_VELO_REEL = "velo_reel"         # présente dans `slot_data.verrous_actifs` : graine en mode « vélo réel »
# Rang RÉEL (requêtes de rang de t103i21, jamais modifié par le mod) : chapitres terminés avant de pouvoir l'avoir
# (valeurs de l'ancien mod mesurées en jeu, prudentes : C au 6e chapitre, B au 7e, A au 9e ; la requête du rang S est
# d'après-jeu), et exemplaires AP qu'il faut pour FAIRE la requête : celle du rang B passe par des lieux fermés par
# les verrous C de San Fantastico (t121d03, t121d11), celle du rang A par la Clinique du Crépuscule (verrou B de
# t105g00) [C, conditions GetQuestPhase(qs0026 / qs0027) de ces cartes].
# La requête du rang C (quête 25) se fait dans le Manoir (t103d31, t103d35 : combats btl_qs0025_01..03), derrière le
# verrou D de t103g00 [C] : le rang réel C exige 1 exemplaire (objets_cles_v11 §14.8). Rang réel D (histoire, c03 n° 33,
# carte t103i21, hors de toute porte) : 0.
SEUIL_RANG_REEL = {"C": 5, "B": 6, "A": 8}
EXEMPLAIRES_RANG_REEL = {"C": 1, "B": 2, "A": 3}
# Coffres dorés derrière un verrou de montre D..A (index TBox -> rang du verrou) [C pour les verrous et les routes :
# OP_WATCHLOCK_POINT, et zone de la route vers la carte fermée 8 à 14 unités derrière le mur du verrou ; S pour
# l'appartenance d'un coffre à la partie fermée d'une carte, recoupée avec les étiquettes de l'ancien mod, mesurées
# en jeu] :
# - C : 24, 25 (t101d02, route derrière le verrou de t101d01) ; 44, 45 (partie de t102g00 atteinte par les égouts,
#   route derrière le verrou de t100d00) ; 110 (t103d11) et 90 (partie haute de t103g00 atteinte par t103d11) ;
#   359 (t121d03) et 362..370 (t121d11, grotte du littoral), routes derrière les deux verrous de t121g00 ;
# - B : 107 (t103d03) ; 211..215, 217..219, 221 (Clinique du Crépuscule : route t105g00 -> t105d41 derrière le verrou
#   B de t105g00 ; 219 et 221 aussi derrière celui de t105d45) ;
# - A : 179 (t104d11, 3e étage de la tour du commerce, du côté opposé à l'ascenseur) ;
# - D : 113..123 (Manoir t103d31 et t103d35 : coffres de la V1 « Manoir » et « Manoir arrière ») : la seule entrée du
#   Manoir (routes t103g00 -> t103d31 / t103d33, portes du jardin arrière) est dans la partie de t103g00 fermée par le
#   verrou D (mur (61.8, 100.3, -577.8), tout ce qui est au-delà de z = -578) [C pour les routes et les positions ; S
#   fort pour l'unicité du passage : l'ancien mod, mesuré en jeu, exigeait « chapitre 3 + rang D » pour le Manoir]
#   (objets_cles_v11 §14.8). Le verrou D du Quartier des boutiques (t105g00) ne ferme qu'une impasse sans location.
# Ajouts de la couverture (archipelago_couverture.md §3.1, R3 ; positions et routes vérifiées sur le RomFS) :
# - A : 29 (t101d05, Allée sinistre : derrière le verrou A (11.6, 72.5), du côté opposé à l'entrée et au coffre 28) ;
# - B : 220 (t105d45, Clinique, côté de l'arrivée) ; 207 (t105d12, appartement A-201 du Quartier des boutiques : porte
#   IsHaveItem(Clé appartement A-201), t105g00_trigger n° 68 ; la clé n'est que dans le coffre 216 de la Clinique) : le
#   chemin passe par le verrou B.
# Ajout des checks oubliés (archipelago_couverture.md §9) : B : 216 (t105d43, Clinique : routes t105d41 / t105d45 ->
#   t105d43 sans verrou, seule entrée de la Clinique derrière le verrou B de t105g00 [C]) ; son contenu d'origine, la Clé
#   appartement A-201, entre dans le pool (OBJETS_COFFRES_DE_RANG) et le coffre 207 l'exige (COFFRES_OBJETS_SUPPLEMENTAIRES).
# Les coffres 180..185 (tour du commerce) ne sont derrière aucun verrou de montre : leur étiquette « rang C » de
# l'ancien mod ne demande que le rang réel (exclusion -> SEUIL_RANG_REEL, EXEMPLAIRES_RANG_REEL).
COFFRES_VERROU_DE_MONTRE: Dict[int, str] = {
    **{i: "C" for i in (24, 25, 44, 45, 90, 110, 359, 362, 363, 364, 365, 366, 367, 368, 369, 370)},
    **{i: "B" for i in (107, 207, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221)},
    29: "A", 179: "A",
    **{i: "D" for i in range(113, 124)},
}
# Coffres de rang qui ne deviennent JAMAIS des locations (contenu d'origine gardé) : objet exigé par le jeu que rien
# d'autre ne donne (archipelago_logique_audit.md G2-4) :
# - 179 : Clé magnétique bleue, testée par la console de la base secrète des égouts (t100d00_trigger n° 42 et 45,
#   IsHaveItem) [C]. En faire une location supprimerait la seule clé bleue du jeu ; la mettre dans le pool exigerait
#   une règle sur tout ce que sa porte ouvre, inconnu [S] (aucune location connue derrière) : garder le coffre.
# (216, Clinique, Clé appartement A-201 : gardé d'origine par la couverture R3, devenu une location avec les checks oubliés,
#  la clé entrant dans le pool quand le verrou « rangs » est actif : OBJETS_COFFRES_DE_RANG.)
COFFRES_RANG_NON_LOCATIONS: Dict[int, str] = {179: "cle_magnetique_bleue"}
# Objets-clés dont la seule source est un coffre de rang (location seulement avec le verrou « rangs ») : dans le pool
# seulement quand ce verrou est actif ; sinon le coffre garde son contenu d'origine (et la porte qu'ouvre l'objet ne
# ferme aucune location : le coffre 207 n'existe qu'avec le même verrou). Objet -> index TBox du coffre [C].
OBJETS_COFFRES_DE_RANG: Dict[str, int] = {"cle_appartement_a_201": 216}
# Régions entières derrière un verrou de montre (connexion) : la Clinique du Crépuscule (verrou B de t105g00).
REGIONS_VERROU_DE_MONTRE: Dict[str, str] = {"clinique_du_crepuscule": "B"}
EXCLUSIONS_RANG = {"rang_C": "C", "rang_B": "B", "rang_A": "A"}


# ---------------------------------------------------------------------------
# Vélo (objets_cles_v11 §6 et §15)
# ---------------------------------------------------------------------------
# Location « Objet-clé : Vélo » = requête qs0009 terminée (phase 255, lue par le client comme un boss de quête : 4e champ
# de QUEST_CONFIG = 9) [C] : QuestCompleteEx('qs0009') suit l'achat du vélo, la scène ev70_0950 et RunBicycle
# (t103g00_quest n° 8/10), que le verrou soit actif ou non (la montée refusée n'arrête pas le script). Identifiants et
# noms de l'ancien mod. Apparition : GetPhase >= 7-20 (QUEST_CONFIG) ; chemin : maison, gares (train), bureau du
# Centre-ville (t104i53), boutique de vélos (t103g00) ; la phase 6 exige de posséder le Yo-kai Yvantouse
# (QUEST_PHASE -> QUEST_NECESSARY_CONDITION type 2), représenté par le chapitre comme les autres Yo-kai à posséder [S].
# Règle : celle de « Chapitre 7 terminé » (plus stricte que le jeu, jamais moins), comme un boss de quête. Aucune
# location n'exige le vélo : aucune condition de .cfg.bin ne lit les flags 39/40, IsBicycleOn n'est lu que par la
# musique (map_sound) [C] ; la course de vélo (race_menu) fournit ses propres vélos.
VERROU_VELO = "velo"
QUETE_VELO: dict = {"cle": "velo", "id_ap": 59423001, "nom_fr": "Objet-clé : Vélo", "nom_en": "Key Item: Bicycle",
                    "quete": 9, "chapitre": 7, "region": "coteau_fleuri"}


def exemplaires_pour(rang_reel: Optional[str] = None, verrou: Optional[str] = None, reel: bool = True) -> int:
    """Exemplaires de « Rang de montre » exigés : verrou de montre franchi (D 1, C 2, B 3, A 4) et/ou rang de montre
    exigé par le jeu. Mode « rang réel » (`reel`) : le rang X exige EXEMPLAIRES_RANG[X] (D 1, C 2, B 3, A 4) ; ancien
    mode : la requête qui donnait le rang (C : 1 exemplaire, B : 2, A : 3 ; D : histoire, 0)."""
    return max(EXEMPLAIRES_RANG.get(verrou, 0), (EXEMPLAIRES_RANG if reel else EXEMPLAIRES_RANG_REEL).get(rang_reel, 0))


# Jamais mélangés. Vide depuis la V1.1 : la Clé salle du trésor et la Poignée étrange (J1 §7) ont leur verrou de
# déclencheur de quête (objets_cles_v11 §13) et sont mélangées seulement quand il est actif.
NON_MELANGES_V1: FrozenSet[str] = frozenset()

# Coffres qui exigent en plus un objet quand son verrou est actif (index TBox -> objets ; filtrés comme toute règle :
# sans effet quand l'objet n'est pas mélangé). Plus strict que le jeu, jamais moins (objets_cles_v11 §13.4) :
# - 75 « Tunnel abandonné (salle du trésor) - Coffre 02 » (t102d31, (158, 40.6, -461)) : du même côté que la zone du
#   combat de Volteface par rapport à la porte 0x1A0AA0B8 (60, 40, -387), fermée par le jeu à qui n'a pas la Clé
#   salle du trésor (t102d31_trigger n° 20, IsHaveItem) ; accès réel non prouvé [?] : exigence de prudence.
# - 79 « Tunnel abandonné est - Coffre 07 » (t102d32, (-212, 0.3, 159)) : du côté ouest, desservi par le wagon SANS le
#   levier de l'Huile de Tendino (t102d32_trigger n° 8) [S, couverture] ; jamais ouvert dans les sauvegardes de
#   l'humain : Huile exigée par prudence (elle est dans le coffre 78 de la même carte, sans condition).
# - 454..458 « Centre-ville de Granval (géant fantôme) » (t104d33) : route t104i39 -> t104d33 ouverte à partir de la
#   phase 6 de la quête 58 (Ombraptor), jamais refermée (miroir dès la phase 7, y compris après la quête) [C] ; même
#   règle que le boss Ombraptor : quête 57 finie (Poignée étrange), rang A réel, Clinique (verrou B).
# - 207 « Résidence Sérénité (A-201) » (t105d12) : porte IsHaveItem(Clé appartement A-201), t105g00_trigger n° 68/69 [C]
#   (clé dans le pool avec le verrou « rangs », OBJETS_COFFRES_DE_RANG ; le coffre 207 n'existe qu'avec ce verrou).
COFFRES_OBJETS_SUPPLEMENTAIRES: Dict[int, Tuple[str, ...]] = {75: ("cle_salle_du_tresor",), 79: ("huile_de_tendino",),
                                                              207: ("cle_appartement_a_201",),
                                                              **{i: ("poignee_etrange",) for i in range(454, 459)}}
# Coffres de la V1 (sans exclusion de rang) sur le chemin d'une quête qui exige un rang réel et franchit un verrou de
# montre : (rang réel, verrou de montre) -> exemplaires de « Rang de montre » avec le verrou « rangs » (exemplaires_pour).
COFFRES_RANGS_CHEMIN: Dict[int, Tuple[str, str]] = {i: ("A", "B") for i in range(454, 459)}

# Connexions qui exigent en plus des objets (filtrés comme partout : sans effet quand l'objet n'est pas mélangé ou que
# son verrou n'est pas actif) ; surcharge de `regions.json` (import A1, non modifié). archipelago_logique_audit.md :
# - Quartier des boutiques (t105g00, t105d01, t105d22) : refoulé à l'entrée tant que phase <= 3-130 (c03_trigger n° 86/87)
#   [C] ; le verrou de l'Herbe arrête l'histoire à 3-120 : l'Herbe est exigée (G1-1). Les égouts mènent à t105d01
#   (coffre 205) : si ce passage est ouvert plus tôt [?], la règle est seulement plus stricte que le jeu (choix prudent).
#   Clés de l'école : explicites (3-140 > 3-40), au lieu de passer seulement par « Chapitre 2 terminé » (§5).
# - Coteau fleuri (t103g00) : refoulé tant que 30010 <= phase <= 30065 (c03_trigger n° 44/45) [C] ; les Clés arrêtent
#   l'histoire à 3-40 : exigées explicitement (§5).
CONNEXIONS_OBJETS_SUPPLEMENTAIRES: Dict[Tuple[str, str], Tuple[str, ...]] = {
    ("menu", "quartier_des_boutiques"): ("herbe_ancestrale", "cles_de_l_ecole"),
    ("menu", "coteau_fleuri"): ("cles_de_l_ecole",),
    # Mont Sylvestre (« 1 chapitre ») : ouverture dans le chapitre 2 non datée : Pile ou passe exigée par prudence (§14)
    ("les_hauts_de_granval", "mont_sylvestre"): ("pile_ou_passe",),
}

# Chapitres terminés minimaux de coffres dont la zone s'ouvre plus tard que ne le disent les données (index TBox ->
# chapitres ; max avec les données). Plus strict que les données, exact d'après le jeu (archipelago_logique_audit.md) :
# - 1-8, 10, 11 « Les Hauts de Granval » : OP_TBOX_POINT de t101g00, condition GetPhase >= 20010 [C] (G3-1) ;
# - 425-429 « Vieux Mont de l'Ours » : seule entrée t231g00 -> t231d03 refoulée par c05..c09 tant que
#   50010 <= phase <= 90040 [C] (G3-2) ; 8 chapitres = phase >= 9-10, sans verrou d'arrêt jusqu'à 9-50.
# - 9 (couverture) : même carte et même condition que 1-8, 10, 11 [C].
COFFRES_CHAPITRES_MIN: Dict[int, int] = {**{i: 1 for i in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11)},
                                         **{i: 8 for i in (425, 426, 427, 428, 429)}}

# Quand un verrou est actif, « Chapitre N terminé » exige l'objet (en plus des objets critiques repris de
# l'ancien mod, `regions.json` : Clés de l'école pour le chapitre 2, retirées par CRITIQUES_RETIRES ; Canne à pêche pour
# le chapitre 4, gardée). Exigences volontairement PLUS STRICTES que le jeu, jamais moins (objets_cles.md §13.7) :
# - Clés de l'école (chapitre 2, ancien mod) : le jeu bloque en réalité la suite du chapitre 3 (phase 3-40) ;
#   l'exiger dès le chapitre 2 couvre tout ce que les données rangent en « 2 chapitres » mais qui ne s'ouvre
#   qu'après 3-40. Aussi exigées EXPLICITEMENT pour le chapitre 3 (arrêt réel) et sur les connexions de Coteau fleuri
#   et du Quartier des boutiques (CONNEXIONS_OBJETS_SUPPLEMENTAIRES) : même résultat, mais ne dépend plus de
#   l'exigence du chapitre 2 (archipelago_logique_audit.md §5) ;
# - Modèle zéro (chapitre 6) : la commande 0x3CEF est exemptée jusqu'au combat ev06_btl0040 ; exigée pour la
#   fin du chapitre 6 et Lady Démona, par prudence (combats scénarisés suivants [?]).
# - Herbe ancestrale et Super tournevis (chapitre 3, V1.1) : exactes. Sans l'Herbe, la phase 3-120 ne finit pas
#   (ev03_1400) ; sans le Tournevis, la phase 3-150 non plus (ev03_1800) : le chapitre 3 ne peut pas se terminer.
#   Le Tournevis retarde aussi le rang D (c03_trigger n° 33, après le n° 27) : les coffres du Manoir (113..123,
#   derrière le verrou de montre D de t103g00, « 2 chapitres » dans les données) exigent OBJETS_RANG_D (correction
#   de objets_cles_v11 §14.8 : ce verrou ferme bien des coffres de la V1) ; tout le reste qui demande le rang D suit le
#   chapitre 3 et exige déjà « Chapitre 3 terminé ».
# - Indications de Maman (chapitre 4, V1.1) : exactes. Sans elles, la phase 4-50 ne finit pas (ev04_0700 suit
#   l'arrivée ev60_0400) et le Centre-ville reste fermé : la connexion vers `centre_ville_de_granval` (et tout ce qui
#   en dépend : Tour Excellence, Ourcival, San Fantastico, Mont de l'Ours) et le Musée de La Corniche les exigent
#   déjà dans les données (`regions.json`, `coffres.json`) ; tout le reste d'après le chapitre 4 exige « Chapitre 4
#   terminé ». Le don (c04 n° 10-13) précède le verrou : son emplacement ne les exige pas (objets_cles_v11 §12.5).
# - Pile ou passe (chapitre 2, objets_cles §14) : exacte pour la fin du chapitre 2 (l'histoire s'arrête en 2-60). Retirée
#   de « Chapitre 1 terminé » (critique de l'ancien mod, CRITIQUES_RETIRES) : sinon son propre emplacement (2-50,
#   « 1 chapitre ») l'exigerait. Les locations « 1 chapitre » qui ne passent pas par la règle du chapitre 2 l'exigent
#   explicitement (COFFRES_AVANT_TUTORIEL_PILE, CONNEXIONS_OBJETS_SUPPLEMENTAIRES : Mont Sylvestre ; La Corniche dans les
#   données), sauf son emplacement.
# - Canne à pêche (chapitre 4, objets_cles_v11 §18.3 et §19) : exacte pour la fin du chapitre 4. La requête 99 « Pas le
#   temps de pêcher ! » est une requête CLÉ : la phase 4-135 attend la phase 4 de la quête de chapitre 174, dont la phase
#   3 exige les requêtes 5, 29 et 99 finies [C : QUEST_NECESSARY_CONDITION type 9, phase_set_c04]. Ordre de la 99 [C] :
#   phase 2 (vaincre 3 Yo-kai à la loupe d'Ourcival) -> don de la Canne (l'emplacement, t131g00_quest n° 78) -> phase 3
#   (posséder 3 poissons, que seule la pêche donne : aucune boutique ni script, un lot de Crank-a-kai au hasard) -> finie.
#   Sans la Canne reçue (flag 29 lu « Canne reçue »), l'histoire s'arrête donc en 4-135, APRÈS l'emplacement de la Canne
#   (qui ne l'exige pas : pas de règle circulaire). L'ancien mod avait raison (critique du chapitre 4, mesuré en jeu) ;
#   l'audit G4, qui l'avait retirée (« aucune séquence d'histoire ne pêche »), était faux. Plus strict que le jeu pour les
#   locations « du chapitre 4 » d'avant 4-135 (même convention que les Indications), jamais moins. Les coffres « 3
#   chapitres » dont la zone ne s'ouvre qu'après 4-135 l'exigent aussi (COFFRES_APRES_ARRET_CANNE).
CHAPITRE_BLOQUE_PAR = {"indications_de_maman": 4, "modele_zero": 6, "herbe_ancestrale": 3, "super_tournevis": 3,
                       "cles_de_l_ecole": 3, "pile_ou_passe": 2, "canne_a_peche": 4}

# Rangs de montre : exemplaires de « Rang de montre » exigés par « Chapitre N terminé » quand le verrou « rangs » est
# actif (objets_cles_v11 §17.3, audit de la logique). Les REQUÊTES CLÉS de l'histoire dépendent du rang [C :
# QUEST_NECESSARY_CONDITION des quêtes de chapitre 174 / 177 / 179 (type 9 = requête terminée, évaluateur FUN_0041908C) ;
# fins de phase 4-135, 7-20 et 9-60 de phase_set_cNN = phase suivante de la quête de chapitre] :
# - chapitre 7 (7-20) : requête 26 « Obtenons le rang B ! », dont les trois combats sont dans t121d03 et t121d11,
#   derrière les verrous de montre C de San Fantastico : 2 exemplaires ;
# - chapitre 9 (9-60) : requête 21, finie dans t231d05, derrière le verrou de montre A de t231d04 : 4 exemplaires ;
# - chapitre 4 (4-135) : requêtes 29 et 99, visibles seulement au rang réel >= D : rang donné par l'histoire (c03
#   n° 33), aucun exemplaire.
# Comme pour les objets critiques, la règle de « Chapitre N terminé » sert aussi aux locations « du chapitre N »
# (requêtes, boss, Tablo-blabla…) : plus stricte que le jeu pour elles, jamais moins. L'objectif les exige toutes.
# CHAPITRE_RANGS : ancien mode (rang D donné par l'histoire). CHAPITRE_RANGS_REEL : mode « rang réel » (§17.4) : le rang
# D ne vient plus de c03 n° 33 : le chapitre 4 exige 1 exemplaire (requêtes 29 et 99 absentes au rang E).
CHAPITRE_RANGS: Dict[int, int] = {7: 2, 9: 4}
CHAPITRE_RANGS_REEL: Dict[int, int] = {4: 1, 7: 2, 9: 4}
# Mode « rang réel », prudence : au rang E, les Yo-kai errants et de loupe soumis au rang sont absents (SET_PATH_POP
# « rang >= D », WM_PLACEMENT_DATA par rang : seules 7 cartes ont des placements au rang E [S]) ; le jeu d'origine
# garantit le rang D dès 3-190. Un check « Ami » d'une espèce de rang D ou plus (`chapitre` >= AMI_CHAPITRE_RANG_D,
# amis_criminels.py) exige 1 exemplaire (locations exclues : règle du tracker) ; les quêtes à Yo-kai visibles au rang E
# portent `rang="D"` dans QUETES (44, 64, 161). Boutique dont la carte a une porte « rang >= D » (GATE_ENTER_INFO_COND
# de t105i27 [C] ; porte mystère plutôt qu'entrée du bâtiment [S fort, §17.2]) : 1 exemplaire par prudence.
AMI_CHAPITRE_RANG_D = 2
# Mode « rang réel » : coffres « 3 chapitres » dont la zone ne s'ouvre qu'APRÈS l'arrêt 4-135 (requêtes 29 et 99, rang
# D) : 316..322 (Canyon de la cigale, Rochers de face, Mont de l'Ours : route t131g00 -> t131d03 fermée tant que
# phase <= 4-140 [S, archipelago_logique_audit.md]) : rang exigé par l'histoire pour y arriver (index TBox -> rang).
COFFRES_APRES_ARRET_RANG: Dict[int, str] = {i: "D" for i in range(316, 323)}
# Les mêmes coffres (après l'arrêt 4-135, dans les deux modes de rang) exigent la Canne à pêche quand son verrou est
# actif et qu'elle est mélangée : la phase 4-135 ne finit pas sans la requête clé 99, donc sans pêcher (§19).
COFFRES_APRES_ARRET_CANNE = frozenset(range(316, 323))
BOUTIQUES_RANG: Dict[str, str] = {"N013": "D"}

# Objets critiques de l'ancien mod (`regions.json`) retirés de « Chapitre N terminé » (archipelago_logique_audit.md G4) :
# - Canne à pêche (chapitre 4) : N'EST PLUS retirée (ap/canne-reelle, 2026-10-02) : le retrait de l'audit G4 (« aucune
#   séquence d'histoire ne pêche ») était faux, la requête 99 est une requête clé du chapitre 4 (CHAPITRE_BLOQUE_PAR).
# La Modèle zéro (chapitre 6, repaire) reste exigée : un seul combat validé en jeu avec l'ancienne interface, les
# combats scénarisés des chapitres 7 à 10 et Lady Démona ne le sont pas [S fort] (Gros test V1).
# - Pile ou passe (chapitre 1) : exigée à partir de 2-70 seulement (CHAPITRE_BLOQUE_PAR : chapitre 2) ; au chapitre 1, elle
#   rendait la règle de son propre emplacement circulaire (objets_cles §14.4).
# - Clés de l'école (chapitre 2) : données au chapitre 3 (c03_trigger Phase3) et exigées seulement à partir de 3-40 ;
#   désormais portées par CHAPITRE_BLOQUE_PAR (chapitre 3) et les connexions de Coteau fleuri et du Quartier des
#   boutiques (archipelago_logique_audit.md §5 : l'exigence du chapitre 2 était trop stricte ; 2026-10-01).
CRITIQUES_RETIRES: Dict[int, Tuple[str, ...]] = {1: ("pile_ou_passe",), 2: ("cles_de_l_ecole",)}

# Pile ou passe (objets_cles §14) : objet exigé par tout ce qui suit la phase 2-60. Les règles « N chapitres » (N >= 2) et
# celles qui reprennent la règle du chapitre 2 (boutiques, requêtes, Tablo-blabla, amis, check « chapitre 2 terminé ») la
# contiennent déjà ; les coffres « 1 chapitre » l'exigent en plus, sauf ceux que le jeu ouvre dès 2-10 (OP_TBOX_POINT de
# t101g00, GetPhase >= 20010 [C], COFFRES_CHAPITRES_MIN) ; son emplacement (2-50) ne l'exige jamais.
OBJET_PILE = "pile_ou_passe"
COFFRES_AVANT_TUTORIEL_PILE = frozenset(range(1, 12))

# Objets dont dépend le rang D de la montre (donné par c03_trigger n° 33, après les n° 21 et 27) quand leur verrou
# est actif : exigés par toute location derrière un verrou de montre (coffres du Manoir, COFFRES_VERROU_DE_MONTRE ;
# filtrés comme partout). Sans objet en mode « rang réel » (le rang D est le premier « Rang de montre » reçu).
OBJETS_RANG_D = ("herbe_ancestrale", "super_tournevis")

# ---------------------------------------------------------------------------
# Emplacements d'objets-clés (dons d'évènement, CONCEPTION §3.2)
# ---------------------------------------------------------------------------
# bit : bit TBox persistant posé par la substitution (J1 §5, R7) ; chapitres : chapitres terminés avant le
# don (script `cNN_trigger` du chapitre NN : NN − 1) [C] ; dons de quête : chapitre d'apparition de la quête et rang
# de montre exigé (`rang_reel` ; représenté par le chapitre ; avec le verrou « rangs », exemplaires de exemplaires_pour), vérifiés sur le
# RomFS (archipelago_couverture.md R1 : l'ancienne borne « 9 chapitres » ne les mettait en logique qu'au chapitre 10,
# ville bouclée). Aucun ne dépend de son propre objet : la Clé de derrière est donnée à l'entrée de t103d31 (Manoir,
# derrière le verrou D), avant les portes de la Clé et des jolies clés ; la Clé salle du trésor au point de la loupe,
# avant la porte qui la teste ; la Poignée après un combat de t105d45, avant son usage dans t105d41. Ces emplacements ne reçoivent que du
# remplissage quand leur objet est mélangé (`progression_permise`, ancien mod), sauf celui du Filet.
# Bits de check des dons RÉPÉTABLES sans marqueur (cinq PNJ du Musée) : tant que le bit n'est pas posé, le jeu lit l'objet
# d'origine « non possédé » (IsHaveItem), pour que le PNJ donne même si l'objet d'Archipelago est déjà là ; la remise au
# musée attend donc le check du PNJ : la règle de la requête 40 doit dominer celles de ces emplacements (objets_cles_v11
# §19.3, test_capacites_reelles). Mêmes bornes que AP_TBOX_REPETABLE_* (boite.h).
TBOX_REPETABLES = (571, 575)
EMPLACEMENTS: Dict[str, dict] = {
    "filet_a_insectes": {"bit": 558, "chapitres": 0},       # c01_trigger RunCmd_Phase16 [C]
    "pile_ou_passe": {"bit": 559, "chapitres": 1},          # c02_trigger RunCmd_Phase11 [C]
    "cles_de_l_ecole": {"bit": 560, "chapitres": 2},        # c03_trigger RunCmd_Phase3 [C]
    "herbe_ancestrale": {"bit": 561, "chapitres": 2, "apres": ("cles_de_l_ecole",)},   # c03 Phase20 [C]
    # c03 Phase26 [C] : exige ev60_0500 <- ev03_1500 <- ev03_1400 (n° 21, consomme l'Herbe)
    "super_tournevis": {"bit": 562, "chapitres": 2, "apres": ("cles_de_l_ecole", "herbe_ancestrale")},
    # quête 99 (>= 4-135, rang D) à Ourcival (t131g00), atteinte par le train (>= 4-70) : Indications [C] (audit G2-3)
    "canne_a_peche": {"bit": 563, "chapitres": 3, "apres": ("indications_de_maman",), "rang_reel": "D"},
    "modele_zero": {"bit": 564, "chapitres": 5},            # c06_trigger RunCmd_Phase1 [C]
    "indications_de_maman": {"bit": 565, "chapitres": 3},   # c04_trigger RunCmd_Phase10..13 [C]
    # quête 54 (>= 5-10, rang C, quête 53 finie ; comme Didgeai) : don de nuit, phase 3, t103d31_quest_trigger n° 5 [C] ;
    # rangs : verrou D (Manoir) et rang réel C (objets_cles_v11 §14.8)
    "cle_de_derriere": {"bit": 566, "chapitres": 4, "rang_reel": "C", "verrou_montre": "D"},
    # quête 53 (>= 3-10, sans rang) : fin de quête dans les égouts, t100d00_quest_trigger n° 6 [C]
    "cle_magnetique_or": {"bit": 567, "chapitres": 2},
    # quête 51 (>= 6-10, rang C, quête 50 finie) : point de la loupe (Filet), t102d31_quest_trigger n° 4 [C]
    "cle_salle_du_tresor": {"bit": 568, "chapitres": 5, "rang_reel": "C"},
    # quête 57 (>= 8-10, rang A, quête 56 finie ; comme Firmain) : après un combat, t105d45_quest_trigger n° 5 [C] ;
    # Clinique du Crépuscule (verrou B de t105g00)
    "poignee_etrange": {"bit": 569, "chapitres": 7, "rang_reel": "A", "verrou_montre": "B"},
    # -- objets-clés de quête (branche ap/objets-cles-quetes, objets_cles_v11 §16) : dons par 0x3B0D (substitution J3),
    # testés par possession ; emplacements EXCLUS (remplissage seulement), règles prudentes. Détection : bit de la
    # réserve 571..575 pour les dons répétables sans marqueur (PNJ qui redonnent l'objet tant qu'il n'est ni possédé ni
    # exposé), sinon marqueur persistant posé par le même script (`flag` : flag bit global ; `quete` : quête à 255),
    # lu par le client comme un boss (entrée de `boss` de slot_data) ; sans bit, la table des dons de script reçoit
    # l'entrée avec AP_SCRIPT_BIT_AUCUN.
    # t100d00_trigger n° 22 (PNJ des égouts, après les dix vannes) : flag 580 (0xB5438FE3) posé juste avant AddItem [C] ;
    # égouts : même règle que les coffres des égouts
    "cle_magnetique_rouge": {"flag": 580, "chapitres": 2, "apres": ("pile_ou_passe",)},
    # t201g00_quest_trigger n° 107 / 108 / 109 (PNJ de Vieux Granval, AddItemWin, sans condition de quête ; répétables
    # tant que l'objet n'est ni possédé ni exposé) [C] : Vieux Granval (4 chapitres)
    "poster_de_film": {"bit": 571, "chapitres": 4},
    "bobine_de_film": {"bit": 572, "chapitres": 4},
    "bouteille_de_y_cola": {"bit": 573, "chapitres": 4},
    # t104g00_quest_trigger n° 1 (PNJ du Centre-ville, AddItemWin, répétable) [C] : Centre-ville (Indications)
    "affiche_de_restaurant": {"bit": 574, "chapitres": 3, "apres": ("indications_de_maman",)},
    # t105i35_quest_trigger n° 4 (boutique de nuit du Quartier des boutiques, AddItemWin, répétable) [C]
    "louloutre": {"bit": 575, "chapitres": 2, "apres": ("herbe_ancestrale", "cles_de_l_ecole")},
    # t102d03_quest_trigger n° 1 (quête 50, phase 4, la nuit : AddItem, puis phase 5) ; détection à la fin de la quête 50
    # (aucun flag posé ; la quête finit sans l'objet) [C] ; quête 50 : >= 3-10, rang D (après le Tournevis)
    "pot_canard": {"quete": 50, "chapitres": 3, "rang_reel": "D"},
    # t106i02_quest_trigger n° 12 : AddItem puis QuestComplete('qs0048') dans le même script [C] ; quête 48 (rang B)
    "figurine_de_photortue": {"quete": 48, "chapitres": 7, "rang_reel": "B"},
    # t104g00_quest_trigger n° 22 : AddItem puis QuestCompleteEx('qs0065') dans le même script [C] ; quête 65 (rang B)
    "robe_de_star": {"quete": 65, "chapitres": 7, "rang_reel": "B"},
}
# Emplacements détectés sans bit de la réserve (flag ou quête) : pas d'index TBox, bit « aucun » dans la table des
# dons de script (AP_SCRIPT_BIT_AUCUN, boîte §12.1).
BIT_SCRIPT_AUCUN = 0xFFFF

# ---------------------------------------------------------------------------
# Boss d'histoire (docs/systemes/archipelago_boss.md §3.1, §4.1, §5)
# ---------------------------------------------------------------------------
# Check = flag bit global du combat, posé par le moteur à la VICTOIRE seulement (FUN_005A65C4 ->
# FUN_00413464), persistant ; le client le lit dans P (bit i % 8 de l'octet P + 4 + i / 8). Identifiants AP et
# noms de l'ancien mod (compatibilité du tracker) ; Laure et Marge : deux locations, un seul combat (flag 277).
# Règle = celle de « Chapitre N terminé » du chapitre du boss (exacte pour les boss qui terminent un chapitre,
# plus stricte pour les autres). Correction de l'ancien mod : Cyrustre, Fielippine, Maudicko, Ronéan au
# chapitre 10 (pas 9). Région : celle de l'ancien mod quand son accès est déjà impliqué par la règle ; Lady
# Perpétua en Vieux Granval (le Repaire exige 10 chapitres dans les données). Lady Démona = la victoire
# (check envoyé en même temps que l'objectif) : règle de l'objectif, location exclue de la progression.
BOSS_HISTOIRE: List[dict] = [
    {"cle": "grolos", "id_ap": 59420100, "nom_fr": "Boss : Grolos", "nom_en": "Boss: Gutsy Bones",
     "flag": 208, "chapitre": 3, "region": "les_hauts_de_granval"},
    {"cle": "meganyan", "id_ap": 59420101, "nom_fr": "Boss : Méganyan", "nom_en": "Boss: Meganyan",
     "flag": 251, "chapitre": 4, "region": "ourcival"},
    {"cle": "laure", "id_ap": 59420103, "nom_fr": "Boss : Laure", "nom_en": "Boss: Kin",
     "flag": 277, "chapitre": 6, "region": "san_fantastico"},
    {"cle": "marge", "id_ap": 59420104, "nom_fr": "Boss : Marge", "nom_en": "Boss: Gin",
     "flag": 277, "chapitre": 6, "region": "san_fantastico"},
    {"cle": "tourboeillon", "id_ap": 59420105, "nom_fr": "Boss : Tourbœillon", "nom_en": "Boss: Eyeclone",
     "flag": 292, "chapitre": 7, "region": "les_hauts_de_granval"},
    {"cle": "injustin", "id_ap": 59423010, "nom_fr": "Boss : Injustin", "nom_en": "Boss: Unfairy",
     "flag": 333, "chapitre": 9, "region": "vieux_granval"},
    {"cle": "cyrustre", "id_ap": 59423012, "nom_fr": "Boss : Cyrustre", "nom_en": "Boss: Untidy",
     "flag": 348, "chapitre": 10, "region": "vieux_granval"},
    {"cle": "fielippine", "id_ap": 59423011, "nom_fr": "Boss : Fielippine", "nom_en": "Boss: Unkaind",
     "flag": 351, "chapitre": 10, "region": "vieux_granval"},
    {"cle": "maudicko", "id_ap": 59423013, "nom_fr": "Boss : Maudicko", "nom_en": "Boss: Unpleasant",
     "flag": 354, "chapitre": 10, "region": "vieux_granval"},
    {"cle": "ronean", "id_ap": 59423014, "nom_fr": "Boss : Ronéan", "nom_en": "Boss: Unkeen",
     "flag": 358, "chapitre": 10, "region": "vieux_granval"},
    {"cle": "lady_perpetua", "id_ap": 59420106, "nom_fr": "Boss : Lady Perpétua", "nom_en": "Boss: Dame Dedtime",
     "flag": 372, "chapitre": 10, "region": "vieux_granval"},
    {"cle": "lady_demona", "id_ap": 59420107, "nom_fr": "Boss : Lady Démona", "nom_en": "Boss: Dame Demona",
     "flag": 377, "chapitre": 10, "region": "repaire_de_lady_demona", "victoire": True},
]

# ---------------------------------------------------------------------------
# Boss de quête (docs/systemes/archipelago_boss.md §3.2, §10)
# ---------------------------------------------------------------------------
# Check = quête terminée : phase 255, octet Q + 4 + n du bloc des quêtes Q = *(*0x00815244 + 0x10) (lu par le
# client, aucun changement du jeu), n = 4e champ de QUEST_CONFIG (nom « qs%04d ») [C] ; 255 n'est posé qu'après la
# victoire contre le boss (déclencheur 78, ou rapport conditionné par une phase que seule la victoire donne) [C,
# §10.2], sauf Firmain [S fort : drapeau temporaire générique entre la victoire et le rapport].
# chapitre = max(chapitre d'apparition de la quête, chapitre où le rang de montre exigé s'obtient : C dès 4-10,
# B dès 7-20, A dès 8-10, quêtes 25/26/27 de t103i21 [C]) ; règle = celle de « Chapitre N terminé » (plus stricte
# que le jeu, jamais moins) + objets testés par possession, ou verrouillés par le patch, sur le chemin de la quête
# et des quêtes qu'elle exige finies (`objets`, filtrés comme partout : un objet non mélangé est donné par la quête
# elle-même et n'est pas exigé ; Clé salle du trésor pour les quêtes 51 et 52, Poignée étrange pour les quêtes 57
# et 58, verrous de déclencheur de quête de la V1.1, objets_cles_v11 §13). Rangs : le chapitre représente le rang
# RÉEL (`rang_reel`) ; avec le verrou « rangs » (V1.1, objets_cles_v11 §14), la règle exige aussi les exemplaires de
# « Rang de montre » du rang réel (requête de rang C : 1, B : 2, A : 3) et des verrous de montre sur le chemin de la quête
# (`verrou_montre` : Clinique du Crépuscule, verrou B de t105g00, pour les quêtes 57 et 58 ; t231d05, derrière le
# verrou A de t231d04, pour la quête 21) [C, conditions GetQuestPhase des cartes fermées]. Identifiants et noms de
# l'ancien mod.
# Tromplœil : donjon des portails (quête 6 finie + progression du donjon, ancien mod : 100 globes de portail) non
# modélisable : location EXCLUE (remplissage seulement), règle prudente du chapitre 4.
BOSS_QUETES: List[dict] = [
    {"cle": "barbefrousse", "id_ap": 59420102, "nom_fr": "Boss : Barbefrousse", "nom_en": "Boss: Cap'n Crash",
     "quete": 16, "chapitre": 6, "region": "san_fantastico"},                   # quête d'histoire, phase == 6-40
    {"cle": "didgeai", "id_ap": 59423002, "nom_fr": "Boss : Didgeai", "nom_en": "Boss: Chirpster",
     "quete": 54, "chapitre": 5, "region": "coteau_fleuri",                     # >= 5-10, rang C, quête 53
     "objets": ("cle_de_derriere", "jolie_petite_cle", "jolie_grande_cle"),      # portes de t103g00 (IsHaveItem)
     "rang_reel": "C"},
    {"cle": "sabroclair", "id_ap": 59423003, "nom_fr": "Boss : Sabroclair", "nom_en": "Boss: Phantasmurai",
     "quete": 7, "chapitre": 8, "region": "la_corniche", "rang_reel": "B"},    # >= 8-10, rang B
    {"cle": "ombraptor", "id_ap": 59423004, "nom_fr": "Boss : Ombraptor", "nom_en": "Boss: Massiface",
     "quete": 58, "chapitre": 9, "region": "centre_ville_de_granval",          # >= 9-10, rang A, quête 57
     "objets": ("poignee_etrange",),                                            # quête 57 finie (QUEST_CONFIG)
     "rang_reel": "A", "verrou_montre": "B"},                                   # quête 57 : Clinique
    {"cle": "inamygal", "id_ap": 59423005, "nom_fr": "Boss : Inamygal", "nom_en": "Boss: Tarantutor",
     "quete": 56, "chapitre": 6, "region": "les_hauts_de_granval",             # >= 6-60, rang C
     "rang_reel": "C"},
    {"cle": "volteface", "id_ap": 59423006, "nom_fr": "Boss : Volteface", "nom_en": "Boss: Duwheel",
     "quete": 51, "chapitre": 6, "region": "mont_sylvestre",                    # >= 6-10, rang C, quête 50
     "objets": ("cle_salle_du_tresor",), "rang_reel": "C"},                     # verrou t102d31 n° 5 (v11 §13)
    {"cle": "misterre", "id_ap": 59423007, "nom_fr": "Boss : Misterre", "nom_en": "Boss: Dromp",
     "quete": 52, "chapitre": 8, "region": "mont_sylvestre",                    # >= 8-10, rang A, quête 51
     "objets": ("huile_de_tendino", "cle_salle_du_tresor"),                     # t102d32 (IsHaveItem) ; quête 51 finie
     "rang_reel": "A"},
    {"cle": "firmain", "id_ap": 59423008, "nom_fr": "Boss : Firmain", "nom_en": "Boss: Hans Full",
     "quete": 57, "chapitre": 8, "region": "quartier_des_boutiques",            # >= 8-10, rang A, quête 56
     "objets": ("poignee_etrange",),                                            # verrou t105d41 n° 7 (v11 §13)
     "rang_reel": "A", "verrou_montre": "B"},                                   # Clinique (t105g00, verrou B)
    {"cle": "demophage", "id_ap": 59423009, "nom_fr": "Boss : Démophage", "nom_en": "Boss: Demuncher",
     "quete": 21, "chapitre": 9, "region": "vieil_ourcival",                    # phase == 9-60 ; acceptée dans t231d04,
     "rang_reel": "A", "verrou_montre": "A"},                                   # finie dans t231d05 (verrou A)
    # quête 80 : QUEST_CONFIG exige aussi GetGlobalBitFlag(2103) == 1 = « Yo-kai appelé » du Tablo-blabla n° 8
    # (TERRITORY_INFO T7 de territory_0.01j, Coteau fleuri) : posséder ET appeler un Yo-kai précis, non modélisable
    # [C] : location EXCLUE (remplissage seulement ; archipelago_tablos.md, archipelago_logique_audit.md)
    {"cle": "crocho", "id_ap": 59423015, "nom_fr": "Boss : Crocho", "nom_en": "Boss: Sproink",
     "quete": 80, "chapitre": 7, "region": "coteau_fleuri", "rang_reel": "B",  # >= 7-10, rang B
     "exclue": True},
    {"cle": "tromploeil", "id_ap": 59423016, "nom_fr": "Boss : Tromplœil", "nom_en": "Boss: Eyephoon",
     "quete": 8, "chapitre": 4, "region": "la_corniche", "exclue": True,        # donjon des portails
     "objets": ("canne_a_peche",)},     # règle de l'ancien mod gardée (aussi exigée par le chapitre 4, §19)
]

# ---------------------------------------------------------------------------
# Boss du mélange qui n'étaient pas des checks (docs/systemes/archipelago_boss.md §11 ; demande de l'humain du
# 2026-10-09 : « mets tous les boss qui sont dans le mélange »)
# ---------------------------------------------------------------------------
# Les 23 locations ci-dessus viennent de l'ancien mod ; la table du mélange des boss (client/rando_boss.py) a 6 autres
# boss d'AVANT la fin du jeu (les 23 boss d'après-jeu ou du réseau caché, HORS_PERIMETRE, et les deux requêtes de
# transfert de données, Triptyk q108 / Carpitaine q113, ne sont pas des checks). Mode « tous » de l'option `boss`
# seulement : les modes existants gardent exactement leurs locations. Identifiants nouveaux (59423017.., plage 3000-3099
# « évènements détectés par flag » de l'ancien mod, libre au-delà de 3016) ; noms saisis à la main (règle 6).
# - Fumella (place 0x925152B3, MÉLANGÉE : boss sans script) : combat de la requête CLÉ 12 du chapitre 5 (phase ==
#   5-110, exigée par la quête de chapitre qm0005 : QUEST_NECESSARY_CONDITION type 9) ; flag bit global 1208 du hachage
#   de la rencontre, posé par le moteur seul à la victoire (jamais écrit par un script) [C] ; règle du chapitre 5.
# - Draconfus (0x80F13DB5, figé) et Faux Kappa (0xABDC6E76, figé) : combats des requêtes CLÉS 15 et 17 du chapitre 6
#   (phase == 6-40, type 9 de qm0006), sans flag de combat : check = quête à 255, comme Barbefrousse (requête 16 de la
#   même série). Requête 15 : la victoire (t107i01 n° 5, type 78) donne la phase 5, que seul un dialogue en phase 5
#   mène à 6 puis un autre en phase 6 à 255 ; requête 17 : la victoire (t131g00 n° 24 / 25, type 78) termine la quête
#   [C]. Règle du chapitre 6 (5 chapitres + Modèle zéro).
# - Sabrille (0x5F48F264, figée, étape 9-20, flag 327) et Anguigne (0x1C292F01, figée, étape 10-20, flag 341) : combats
#   d'histoire ; flag écrit par le moteur et par le script de victoire seulement, condition de fin de l'étape
#   (phase_set_c09 / c10), jamais remis à 0 [C] ; règles des chapitres 9 et 10.
# - Taprice (0xBDE7A020, MÉLANGÉ, classe 2) : fin du Tunnel sans fin (t131d33). Aucun flag de ce hachage ; la victoire
#   (t131d33_trigger n° 6, type 78) pose l'octet global de progression du tunnel (catégorie 6, index 73, hachage
#   0x8920FFE7 : P + 0x144 + 73) à 6 ; il vaut 0..5 avant (une arrivée au bout du tunnel par valeur), puis ne fait que
#   croître (7..20, 255) : check = octet >= 6 (entrée {location, octet, seuil} de `boss`, client à jour exigé par les
#   n° 22 et 64 de `fonctions_exigees`) [C]. Entrée du tunnel : point de recherche de t131g00 (GetPhase >= 4-160, une
#   fois par JOUR DU JEU : flag 2528 remis à 0 par le changement de jour, pas par l'horloge réelle) ; il faut cinq
#   traversées complètes avant le combat : LONG, location EXCLUE et marquée (PORTAIL_TUNNEL), règle de 4 chapitres
#   terminés (plus stricte que 4-160).
# Le check suit la PLACE (hachage de la rencontre) quel que soit le boss qui l'occupe : les marqueurs viennent tous du
# moteur ou des déclencheurs 78 de ce hachage (archipelago_rando_boss.md §2.4).
BOSS_MELANGE: List[dict] = [
    {"cle": "fumella", "id_ap": 59423017, "nom_fr": "Boss : Fumella", "nom_en": "Boss: Badsmella",
     "flag": 1208, "chapitre": 5, "region": "vieux_granval"},
    {"cle": "draconfus", "id_ap": 59423018, "nom_fr": "Boss : Draconfus", "nom_en": "Boss: Draaagin",
     "quete": 15, "chapitre": 6, "region": "ourcival"},
    {"cle": "faux_kappa", "id_ap": 59423019, "nom_fr": "Boss : Faux Kappa", "nom_en": "Boss: Faux Kappa",
     "quete": 17, "chapitre": 6, "region": "ourcival"},
    {"cle": "sabrille", "id_ap": 59423020, "nom_fr": "Boss : Sabrille", "nom_en": "Boss: Ray O'Light",
     "flag": 327, "chapitre": 9, "region": "vieux_granval"},
    {"cle": "anguigne", "id_ap": 59423021, "nom_fr": "Boss : Anguigne", "nom_en": "Boss: Loiter",
     "flag": 341, "chapitre": 10, "region": "vieux_granval"},
    {"cle": "taprice", "id_ap": 59423022, "nom_fr": "Boss : Taprice", "nom_en": "Boss: Mallice",
     "octet": 73, "seuil": 6, "chapitre": 5, "region": "ourcival", "exclue": True},
]
TOUS_LES_BOSS: List[dict] = BOSS_HISTOIRE + BOSS_QUETES + BOSS_MELANGE

# Valeurs de l'option `boss` (options.py) : modes qui ajoutent des locations de boss. « tous » = histoire_et_quetes +
# BOSS_MELANGE ; les trois premiers modes n'ont pas changé (plans identiques à ceux d'avant).
MODES_BOSS = ("aucun", "histoire", "histoire_et_quetes", "tous")
BOSS_PAR_DEFAUT = "histoire"

# ---------------------------------------------------------------------------
# Tablo-blabla (docs/systemes/archipelago_tablos.md)
# ---------------------------------------------------------------------------
# Check = flag bit global « Yo-kai appelé » (champ +0 de TERRITORY_INFO, territory_0.01j) : décision de l'humain, le
# check part quand le Yo-kai du panneau est APPELÉ (NazoNazoMenu_AskToCall, qui exige de le POSSÉDER), pas à la seule
# bonne réponse (flag « résolu », +8). Flag persistant, jamais effacé, lu par le client dans P (comme les boss).
# Posséder un Yo-kai précis n'est pas modélisable (amitié aléatoire) : les locations sont EXCLUES (remplissage
# seulement), sauf le n° 3 : la fin de la phase 10-45 exige ce flag (phase_set_c10 DATA_ITEM[10, 45] :
# GetGlobalBitFlag(2089) == 1 ; la condition d'une phase est sa condition de FIN) [C] : quiconque finit le chapitre 10 a
# appelé ce Yo-kai ; règle du chapitre 10 (comme Cyrustre… : check au plus tard à 10-45, avant la fin du chapitre).
# Identifiants de l'ancien mod (59422300 + n − 1, numéros du guide) ; noms SANS la réponse (règle 6 : lieux saisis à la
# main). `chapitre` = chapitre dont on prend la règle « Chapitre N terminé » (N − 1 chapitres finis : accès au lieu du
# panneau, archipelago_tablos.md §5.2, borne la plus tardive) ; `apres_jeu` : panneau jamais créé (TABLOS_NON_CREES) ;
# `objets` : objets testés sur le chemin (filtrés comme partout) ; `verrou_montre` : verrou de montre
# franchi (verrou « rangs », grotte du littoral t121d11 derrière le verrou C de t121g00).
TABLOS: List[dict] = [
    {"n": 1, "flag": 2087, "chapitre": 2, "region": "les_hauts_de_granval",
     "lieu_fr": "Les Hauts de Granval (Tout pour tous)", "lieu_en": "Uptown Springdale (Everymart)"},
    {"n": 2, "flag": 2088, "chapitre": 2, "region": "les_hauts_de_granval",
     "lieu_fr": "Les Hauts de Granval (Troc safari)", "lieu_en": "Uptown Springdale (trading shop)"},
    {"n": 3, "flag": 2089, "chapitre": 10, "region": "les_hauts_de_granval", "progression": True,
     "lieu_fr": "Les Hauts de Granval (Centre associatif)", "lieu_en": "Uptown Springdale (community center)"},
    {"n": 4, "flag": 2095, "chapitre": 8, "region": "tunnel_abandonne", "objets": ("huile_de_tendino",),
     "lieu_fr": "Tunnel abandonné (est)", "lieu_en": "Abandoned Tunnel (east)"},
    {"n": 5, "flag": 2096, "chapitre": 8, "region": "tunnel_abandonne",
     "lieu_fr": "Tunnel abandonné (ouest)", "lieu_en": "Abandoned Tunnel (west)"},
    {"n": 6, "flag": 2097, "chapitre": 6, "region": "mont_sylvestre",
     "lieu_fr": "Mont Sylvestre (sommet)", "lieu_en": "Mt. Wildwood (summit)"},
    {"n": 7, "flag": 2098, "chapitre": 6, "region": "mont_sylvestre",
     "lieu_fr": "Mont Sylvestre (sommet)", "lieu_en": "Mt. Wildwood (summit)"},
    {"n": 8, "flag": 2103, "chapitre": 3, "region": "coteau_fleuri",
     "lieu_fr": "Coteau fleuri (sources chaudes)", "lieu_en": "Blossom Heights (hot springs)"},
    {"n": 9, "flag": 2111, "chapitre": 4, "region": "centre_ville_de_granval",
     "lieu_fr": "Centre-ville de Granval (chantier)", "lieu_en": "Downtown Springdale (construction site)"},
    {"n": 10, "flag": 2112, "chapitre": 4, "region": "centre_ville_de_granval",
     "lieu_fr": "Centre-ville de Granval (intérieur)", "lieu_en": "Downtown Springdale (indoors)"},
    {"n": 11, "flag": 2113, "chapitre": 4, "region": "centre_ville_de_granval",
     "lieu_fr": "Centre-ville de Granval (Tour de commerce)", "lieu_en": "Downtown Springdale (trade tower)"},
    {"n": 12, "flag": 2119, "chapitre": 3, "region": "quartier_des_boutiques",
     "lieu_fr": "Quartier des boutiques", "lieu_en": "Shopper's Row"},
    {"n": 13, "flag": 2127, "chapitre": 6, "region": "la_corniche",
     "lieu_fr": "La Corniche (salle des portails, rez-de-chaussée)", "lieu_en": "Breezy Hills (portal hall, ground)"},
    {"n": 14, "flag": 2128, "chapitre": 6, "region": "la_corniche",
     "lieu_fr": "La Corniche (salle des portails, 1er)", "lieu_en": "Breezy Hills (portal hall, 1st)"},
    {"n": 15, "flag": 2129, "chapitre": 6, "region": "la_corniche",
     "lieu_fr": "La Corniche (salle des portails, 2e)", "lieu_en": "Breezy Hills (portal hall, 2nd)"},
    {"n": 16, "flag": 2130, "chapitre": 2, "region": "la_corniche",
     "lieu_fr": "La Corniche (maison des Roch)", "lieu_en": "Breezy Hills (house)"},
    {"n": 17, "flag": 2138, "chapitre": 4, "region": "tour_excellence",
     "lieu_fr": "Tour Excellence", "lieu_en": "Excellent Tower"},
    {"n": 18, "flag": 2140, "chapitre": 4, "region": "san_fantastico",
     "lieu_fr": "San Fantastico (route de la gare)", "lieu_en": "San Fantastico (station road)"},
    {"n": 19, "flag": 2146, "chapitre": 4, "region": "san_fantastico",
     "lieu_fr": "San Fantastico (grotte saline)", "lieu_en": "San Fantastico (salt cave)"},
    {"n": 20, "flag": 2150, "chapitre": 6, "region": "san_fantastico", "objets": ("modele_zero",),
     "verrou_montre": "C",
     "lieu_fr": "San Fantastico (grotte du littoral, 1er)", "lieu_en": "San Fantastico (shore cave, 1st)"},
    {"n": 21, "flag": 2152, "chapitre": 6, "region": "san_fantastico", "objets": ("modele_zero",),
     "verrou_montre": "C",
     "lieu_fr": "San Fantastico (grotte du littoral, 2e)", "lieu_en": "San Fantastico (shore cave, 2nd)"},
    {"n": 22, "flag": 2154, "chapitre": 6, "region": "san_fantastico", "objets": ("modele_zero",),
     "verrou_montre": "C",
     "lieu_fr": "San Fantastico (grotte du littoral, 3e)", "lieu_en": "San Fantastico (shore cave, 3rd)"},
    # n° 23 : panneau sur t100s21, gare terminus de la ligne 0 (train_config) ; train sans condition depuis la gare
    # t104i61 du Centre-ville, ouvert dès l'arrivée au Centre-ville (après l'arrêt 4-50 des Indications de Maman), et
    # depuis t103g00 dès 4-70 [C] ; règle : 3 chapitres + Indications (celle du Centre-ville) ; fermé au chapitre 10
    # (Hauts de Granval seulement), rouvert après la victoire (archipelago_couverture.md R1)
    {"n": 23, "flag": 2142, "chapitre": 4, "region": "centre_ville_de_granval", "objets": ("indications_de_maman",),
     "lieu_fr": "Train (gare à confirmer)", "lieu_en": "Train (station to be confirmed)"},
    # n° 24 : Yo-kai World (t001d42), après-jeu (Clé du Yo-kai World : quête 73, phase >= 11-10) [C] : JAMAIS créé
    # (identifiant réservé, TABLOS_NON_CREES) : même exclu, il recevrait un objet d'un autre monde derrière la victoire
    {"n": 24, "flag": 2144, "chapitre": "apres_jeu", "region": "vieux_granval", "apres_jeu": True,
     "lieu_fr": "Yo-kai World", "lieu_en": "Yo-kai World"},
    {"n": 25, "flag": 2156, "chapitre": 5, "region": "vieux_granval",
     "lieu_fr": "Vieux Granval", "lieu_en": "Old Springdale"},
    {"n": 26, "flag": 2158, "chapitre": 5, "region": "vieux_granval",
     "lieu_fr": "Vieux Granval", "lieu_en": "Old Springdale"},
]
TABLO_ID_BASE = 59422300
for _t in TABLOS:
    _t["id_ap"] = TABLO_ID_BASE + _t["n"] - 1
    _t["nom_fr"] = "Tablo-blabla n°%02d : %s" % (_t["n"], _t["lieu_fr"])
    _t["nom_en"] = "Baffle Board #%02d: %s" % (_t["n"], _t["lieu_en"])
# Panneaux créés comme locations (tous sauf l'après-jeu) ; identifiants réservés, jamais des locations (comme
# QUETES_NON_CREEES) : n° 24 (Yo-kai World, archipelago_couverture.md R1).
TABLOS_CREES: List[dict] = [_t for _t in TABLOS if not _t.get("apres_jeu")]
TABLOS_NON_CREES: Dict[int, int] = {_t["id_ap"]: _t["n"] for _t in TABLOS if _t.get("apres_jeu")}

# Valeurs de l'option `tablos` (options.py). « tous » par défaut : 25 locations exclues (remplissage seulement, aucun
# risque de blocage même si le joueur n'appelle jamais leur Yo-kai) et le n° 3, garanti par l'histoire.
MODES_TABLOS = ("aucun", "tous")
TABLOS_PAR_DEFAUT = "tous"

# ---------------------------------------------------------------------------
# Requêtes et services (docs/systemes/archipelago_quetes.md §4, branche ap/quetes)
# ---------------------------------------------------------------------------
# Check = quête terminée : phase 255, octet Q + 4 + n du bloc des quêtes (lu par le client, comme les boss de quête),
# n = 4e champ de QUEST_CONFIG [C]. Décision de l'humain (option b) : la récompense d'objet de la quête est REMPLACÉE
# par l'objet Archipelago dans l'écran de résultat (jeu v5, table « récompenses de quête » de la boîte) ; l'argent et
# l'expérience restent. Identifiants de l'ancien mod (QUEST_OFFSET 200, requêtes de rang RANK_OFFSET 50) et 9 nouveaux
# (59420277..285) ; noms FR / EN de l'ancien mod (saisis à la main, règle 6).
# `chapitre` N = max(chapitre d'apparition, chapitre où le rang de montre réel exigé s'obtient : C dès 4-10, B dès
# 7-20, A dès 8-10 [C, QUEST_CONFIG des requêtes 25..27], N des quêtes exigées finies) ; règle = celle de « Chapitre N
# terminé » + objets testés sur le chemin (filtrés comme partout) ; `rang` = rang de montre réel exigé (représenté par
# le chapitre ; avec le verrou « rangs », exemplaires de « Rang de montre » de exemplaires_pour) ; `montre` = verrou
# de montre franchi sur le chemin (verrou « rangs ») ; `region` : région de l'ancien mod (celle du boss pour une
# quête de boss), « menu » quand elle est inconnue (la règle du chapitre implique déjà les accès de l'histoire).
# Exclues (remplissage seulement) : n° 8 (donjon des portails, = Tromplœil), n° 80 (exige le Yo-kai du Tablo-blabla
# n° 8 appelé, flag 2103 : non modélisable, = Crocho, archipelago_logique_audit.md) et les 10 services (option,
# phase 255 remise à 0 par le tirage des services, archipelago_quetes.md §2.5). Non créées (identifiants réservés) :
# n° 112, 113, 114 (SaveCopyFlag : transfert de données jamais fait, §2.6) et n° 28 (rang S, après-jeu).
QUETES: List[dict] = []


def _q(n, id_ap, fr, en, chapitre, region, rang=None, objets=(), montre=None, exclue=False, service=False,
       prefixe=True):
    QUETES.append({
        "n": n, "id_ap": id_ap, "chapitre": chapitre, "region": region, "rang_reel": rang, "objets": tuple(objets),
        "verrou_montre": montre, "exclue": exclue or service, "service": service,
        "nom_fr": ("Service : " if service else "Requête : ") * prefixe + fr,
        "nom_en": ("Service: " if service else "Request: ") * prefixe + en})


# `rang` "D" [C, QUEST_CONFIG : GetWatchRank >= D] : 0 exemplaire dans l'ancien mode (rang D de l'histoire), 1 en mode
# « rang réel ». Prudence (mode « rang réel ») : les quêtes 44, 64 et le service 161, visibles au rang E dès le chapitre 3,
# exigent un Yo-kai (QUEST_NECESSARY_CONDITION type 2 / 1) dont la présence au rang E n'est pas prouvée : "D" aussi.
_CLES_T103G00 = ("cle_de_derriere", "jolie_petite_cle", "jolie_grande_cle")   # portes de Coteau fleuri (IsHaveItem)
_q(1, 59420200, "Spécialiste des cigales", "A Cicada Professional", 2, "mont_sylvestre")
_q(2, 59420202, "Ça attire les clients !", "Customer Attraction!", 2, "les_hauts_de_granval")
_q(3, 59420204, "Officiellement officiel !", "Officially Official!", 3, "les_hauts_de_granval")
_q(4, 59420205, "Bam boum ! Fusion !", "Bam-Boom! Fusing!", 3, "coteau_fleuri")
_q(5, 59420214, "Secrets de l'Âmechimie", "Secrets of Soulcery", 4, "ourcival")
_q(6, 59420206, "Les portails mystère", "The Gates of Whimsy", 3, "la_corniche")
_q(7, 59420257, "Une armure sinistre", "Eerie, Roving Armor", 8, "la_corniche", "B")
_q(8, 59420226, "Le portail final", "The Final Gate", 4, "la_corniche", objets=("canne_a_peche",), exclue=True)
_q(9, 59420244, "Sur les traces de Papa", "Retrace Dad's Steps", 7, "les_hauts_de_granval")
_q(10, 59420218, "Pièce Au Phil du temps", "Timers & More's Part", 5, "vieil_ourcival")
_q(11, 59420219, "Pièce sanctuaire", "The Shrine's Part", 5, "vieux_granval")
_q(12, 59420220, "Pièce ferronnerie", "The Ironworks' Part", 5, "vieux_granval")
_q(13, 59420221, "Trouvons Parasolal !", "Find Pallysol!", 6, "ourcival")
_q(14, 59420222, "Trouvons Lulutin !", "Find Gnomey!", 6, "ourcival")
_q(15, 59420223, "Trouvons Métaureaulog !", "Find Predictabull!", 6, "ourcival")
_q(16, 59420224, "Trouvons Sirénée !", "Find Mermaidyn!", 6, "san_fantastico")
_q(17, 59420225, "Trouvons Faux Kappa !", "Find Faux Kappa!", 6, "ourcival")
_q(18, 59420243, "Le secret de Jibanyan", "Jibanyan's Secret", 7, "les_hauts_de_granval")
_q(19, 59420260, "Épreuves de Nyada IV", "Nyada's Trials IV", 9, "vieil_ourcival")
_q(20, 59420261, "Épreuves de Nyada V", "Nyada's Trials V", 9, "vieil_ourcival")
_q(21, 59420262, "Épreuves de Nyada VI", "Nyada's Trials VI", 9, "vieil_ourcival", "A", montre="A")
# requêtes de rang (t103i21) : sans préfixe, comme l'ancien mod ; C passe par le Manoir (verrou D de t103g00), B par les
# verrous C de San Fantastico, A par la Clinique du Crépuscule (verrou B) [C, objets_cles_v11 §14, §14.8]
_q(25, 59420050, "Obtenons le rang C !", "Go for Rank C!", 4, "coteau_fleuri", "D", montre="D", prefixe=False)
_q(26, 59420051, "Obtenons le rang B !", "Go for Rank B!", 7, "coteau_fleuri", "C", montre="C", prefixe=False)
_q(27, 59420052, "Obtenons le rang A !", "Go for Rank A!", 8, "coteau_fleuri", "B", montre="B", prefixe=False)
_q(29, 59420216, "Vrai cache-cache", "True Hide-and-Seek", 4, "ourcival", "D")
_q(30, 59420237, "Super cache-cache", "Super Hide-and-Seek", 6, "san_fantastico", "D")
_q(31, 59420258, "Méga cache-cache", "Ultra Hide-and-Seek", 8, "les_hauts_de_granval", "B")
_q(32, 59420277, "Cache-cache expert", "Expert Hide-and-Seek", 9, "mont_sylvestre", "A")
_q(33, 59420250, "C-1 Grand Prix", "C-1 Grand Prix", 8, "les_hauts_de_granval", "C")
_q(34, 59420256, "C-1 Grand Prix A", "C-1 Grand Prix A", 8, "san_fantastico", "B")
_q(35, 59420278, "C-1 Grand Prix S", "C-1 Grand Prix S", 9, "ourcival", "A")
# quête 40 : les dix objets exposés sont exigés (QUEST_NECESSARY_CONDITION de la phase 2 : dix flags d'exposition, posés
# à la remise de chaque objet, TALK_CONFIG de t106d31 : IsHaveItem) [C] ; la Silhouette de héros ne vient que de la
# quête 46 (>= 9-10, rang A, quêtes 45 et 49 finies), la Robe de star de la quête 65 (rang B), la Figurine de la quête 48
# (rang B) : chapitre 9 et rang A (correction de l'ancienne règle « 5 chapitres », objets_cles_v11 §16.3)
_q(40, 59420203, "Musée en détresse", "Collection Correction", 9, "quartier_des_boutiques", "A", objets=OBJETS_MUSEE)
_q(41, 59420235, "Voyage de l'envoûtement", "Inspirited Away", 5, "mont_sylvestre", "C")
_q(42, 59420265, "La faim justifie le moyen", "Dinner on Hold", 8, "les_hauts_de_granval", "B")
# quête 44 : exige de POSSÉDER Sumochi (QUEST_NECESSARY_CONDITION type 2). Sauvage seulement en salle de portail, MAIS lot
# de la Pièce rouge du Crank-a-kai du présent (5 %, dès le chapitre 2-3) : NON exclue, non marquée (revue
# archipelago_portails_tardifs.md §8). Les quêtes 45 (qs0044 == 255) et 46 (qs0045 == 255) en héritent, la 40 aussi.
_q(44, 59420207, "Super Balaise : l'origine", "Bear Boy: Origins", 3, "coteau_fleuri", "D")
_q(45, 59420241, "Super Balaise : le retour", "The Bear Boy Returns", 6, "les_hauts_de_granval", "C")
_q(46, 59420279, "Super Méga Balaise", "Ultimate Bear Boy", 9, "les_hauts_de_granval", "A")
_q(47, 59420208, "Soirée chaotique", "Hangout Havoc", 3, "coteau_fleuri")
_q(48, 59420254, "Jouets d'antan", "Time and Toys", 8, "vieux_granval", "B")
_q(49, 59420264, "Qui est cette fille", "Who's That Girl", 9, "centre_ville_de_granval", "A")
_q(50, 59420209, "Chasseurs de trésors 1", "Treasure Hunters Pt. 1", 3, "mont_sylvestre", "D")
_q(51, 59420242, "Chasseurs de trésors 2", "Treasure Hunters Pt. 2", 6, "mont_sylvestre", "C",
   objets=("cle_salle_du_tresor",))
_q(52, 59420259, "Chasseurs de trésors 3", "Treasure Hunters Pt. 3", 8, "mont_sylvestre", "A",
   objets=("cle_salle_du_tresor", "huile_de_tendino"))
_q(53, 59420210, "La base secrète", "The Secret Base", 3, "la_corniche")
_q(54, 59420234, "Chasse nocturne", "Gone Haunting", 5, "coteau_fleuri", "C", objets=_CLES_T103G00)
_q(55, 59420245, "Triangle amoureux", "The Heartthrobs", 8, "quartier_des_boutiques", "C", objets=_CLES_T103G00)
_q(56, 59420239, "Ectoplasmes à l'école", "Ghost Club at School", 6, "les_hauts_de_granval", "C")
_q(57, 59420266, "La clinique hantée", "The Haunted Hospital", 8, "quartier_des_boutiques", "A",
   objets=("poignee_etrange",), montre="B")
_q(58, 59420280, "Le géant fantôme", "The Phantom Giant", 9, "centre_ville_de_granval", "A",
   objets=("poignee_etrange",), montre="B")
_q(59, 59420281, "Devoirs d'été - 1re partie", "Independent Study, Pt. 1", 5, "menu", "D")
_q(60, 59420282, "Devoirs d'été - 2e partie", "Independent Study, Pt. 2", 8, "menu", "B")
_q(62, 59420227, "Prix de Gastronomie", "Gourmet Grand Prix", 5, "les_hauts_de_granval", "D")
_q(64, 59420211, "Nouveau look", "Makeover Takeover", 3, "quartier_des_boutiques", "D")
_q(65, 59420246, "Un look trop sophistiqué", "Too Much Makeover", 8, "tour_excellence", "B")
_q(66, 59420213, "La star de Granval 1", "Springdale Star Pt. 1", 4, "les_hauts_de_granval", "C")
_q(67, 59420263, "La star de Granval 2", "Springdale Star Pt. 2", 8, "tour_excellence", "A")
_q(68, 59420201, "Courage, Max !", "Matt, Don't Give Up!", 2, "les_hauts_de_granval")
_q(69, 59420252, "Coup de bluff", "A Card-Carrying Liar", 8, "quartier_des_boutiques", "C")    # exige la 71 (N 8)
_q(71, 59420251, "Un super fan-club", "Catchy Fandom", 8, "centre_ville_de_granval", "D")
_q(78, 59420247, "La reine des cigales", "King of the Cicadas", 7, "mont_sylvestre", "B")
_q(80, 59420248, "Les sources de l'amitié", "A Steamy Friendship", 7, "coteau_fleuri", "B", exclue=True)
_q(82, 59420228, "Un amour perdu", "Long Lost Love", 5, "vieux_granval", "D")
_q(83, 59420249, "Je veux grandir", "I Just Wanna Grow Up", 8, "centre_ville_de_granval", "C")
_q(85, 59420236, "Virée en mer !", "Take to the Sea!", 6, "san_fantastico", "D", objets=("canne_a_peche",))
_q(86, 59420217, "Le meilleur scarabée", "Which Beetle's Better", 5, "vieil_ourcival", "D")
_q(87, 59420230, "Blues du déménagement", "Moving Blues", 5, "vieux_granval", "D")
_q(88, 59420253, "Querelles gourmandes", "Foodie Feuds", 8, "vieux_granval", "B")
_q(89, 59420229, "Votre mascotte locale", "Your Local Mascot", 6, "ourcival", "C")
_q(90, 59420238, "Tous à bord", "All Aboard", 6, "tour_excellence", "D")
_q(98, 59420283, "Le tango du trio", "Trying Tangle Tango", 8, "menu", "B")
_q(99, 59420215, "Pas le temps de pêcher !", "No Time For Fishin'!", 4, "ourcival", "D", objets=("canne_a_peche",))
_q(100, 59420284, "Quel charmeur !", "A Real Charmer", 6, "menu", "C")
_q(104, 59420231, "Oden de l'âme 1", "Oden of the Soul Pt. 1", 4, "ourcival", "D")
_q(105, 59420232, "Oden de l'âme 2", "Oden of the Soul Pt. 2", 4, "ourcival", "D")
_q(106, 59420233, "Oden de l'âme 3", "Oden of the Soul Pt. 3", 4, "ourcival", "D")
_q(125, 59420285, "Le casting rêvé d'Irréal", "Directator's All-Star Cast", 4, "menu", "D")
_q(151, 59420267, "Sous un soleil de plomb", "Stuck in the Heat", 2, "les_hauts_de_granval", service=True)
_q(152, 59420268, "Le ventre vide", "Running on Empty", 3, "quartier_des_boutiques", service=True)
_q(153, 59420270, "Une envie de bonbons", "Sweet Satisfaction", 4, "coteau_fleuri", service=True)
_q(154, 59420272, "Espiègleries", "School Pranks", 5, "quartier_des_boutiques", "D", service=True)
_q(155, 59420274, "À la chasse aux insectes !", "Bug Hunting", 6, "mont_sylvestre", "C", service=True)
_q(161, 59420269, "Que de balivernes", "A Likely Story", 3, "quartier_des_boutiques", "D", service=True)
_q(162, 59420271, "La malade imaginaire", "Overstuffed Head", 4, "centre_ville_de_granval", "D", service=True)
_q(163, 59420273, "Un entraînement de star", "Popular Training", 5, "vieil_ourcival", "D", service=True)
_q(164, 59420275, "Un matou en détresse", "Fat Cat's Favor", 6, "san_fantastico", "C", service=True)
_q(166, 59420276, "Coup de foudre", "Struck with Love", 8, "ourcival", "B", service=True)
# Services d'avant l'après-jeu absents de la liste de l'ancien mod (checks oubliés, archipelago_couverture.md §9) :
# nouveaux identifiants 59420286.. (après les 9 requêtes ajoutées), noms FR / EN repris des données de l'ancien mod
# (quest_hashes.json, i18n_en.json) ; conditions de QUEST_CONFIG [C] ; région inconnue : « menu ».
_q(156, 59420286, "Ne pas jouer le jeu", "Gaming the System", 7, "menu", "C", service=True)       # >= 7-10, rang C
_q(157, 59420287, "Cherche coach invisible", "Leading from Behind", 8, "menu", "B", service=True)  # >= 8-10, rang B
_q(158, 59420288, "Vive la technologie", "Tasteful Technology", 9, "menu", "B", service=True)      # >= 9-10, rang B
_q(165, 59420289, "Une vision d'horreur", "A Frightful Sight", 7, "menu", "C", service=True)       # >= 7-10, rang C
_q(167, 59420290, "Ménage spirituel", "Spiritual Cleansing", 9, "menu", "B", service=True)         # >= 9-10, rang B
_q(168, 59420291, "Parlez-vous le chien ?", "A Ruff Translation", 9, "menu", "A", service=True)    # >= 9-10, rang A
# Identifiants réservés, jamais des locations (archipelago_quetes.md §4.2) : requêtes inaccessibles sans transfert de
# données (112, 113, 114) et rang S (28, après-jeu).
QUETES_NON_CREEES: Dict[int, int] = {59420212: 112, 59420240: 113, 59420255: 114, 59420053: 28}
QUETES_PAR_NUMERO: Dict[int, dict] = {q["n"]: q for q in QUETES}

# Valeurs de l'option `quetes` (options.py). « requetes » par défaut : 74 requêtes pouvant recevoir de la progression
# (+ 2 exclues), détection par la phase 255 (même lecture que les boss de quête, persistante pour les requêtes),
# récompenses d'origine sans effet sur la logique (consommables et équipements). Services : option (exclus).
MODES_QUETES = ("aucune", "requetes", "requetes_et_services")
QUETES_PAR_DEFAUT = "requetes"

# ---------------------------------------------------------------------------
# Checks « Chapitre N terminé » (docs/systemes/archipelago_couverture.md §3.7, R4)
# ---------------------------------------------------------------------------
# Check = quête de chapitre terminée : les quêtes 171..180 (genre 1 de QUEST_CONFIG) sont les 10 chapitres, la phase
# 255 marque le chapitre fini [C : sauvegardes de l'humain, chapitre 5 -> 171..174 à 255, histoire finie -> 171..180] ;
# lue par le client comme un boss de quête (octet Q + 4 + n du bloc des quêtes, entrée {location, quete} de `boss`),
# aucun changement du jeu. Chapitres 1 à 9 seulement : la fin du chapitre 10 est la victoire (Lady Démona). Identifiants
# de l'ancien mod (« Chapitre N : … » = 59420000 + N − 1, envoyé quand le compteur de chapitre passe à N + 1 : même
# chapitre N) ; noms saisis à la main (pas les titres des chapitres). Règle = celle de l'évènement « Chapitre N
# terminé » (les évènements restent : ces locations sont EN PLUS, dans la région du chapitre).
CHAPITRE_QUETE_BASE = 170
CHAPITRES_CHECKS: List[dict] = [
    {"n": _n, "id_ap": 59420000 + _n - 1, "quete": CHAPITRE_QUETE_BASE + _n,
     "nom_fr": "Histoire : chapitre %d terminé" % _n, "nom_en": "Story: Chapter %d complete" % _n}
    for _n in range(1, 10)]
CHAPITRES_CHECKS_PAR_DEFAUT = True

# Check « Montée de rang : D » (checks oubliés, archipelago_couverture.md §9 ; identifiant et noms de l'ancien mod) : le
# rang D est donné par c03_trigger n° 33 (RunCmd_Phase33 : RunkUp puis RunEvent ev03_2300) ; le flag « évènement vu »
# de ev03_2300 (flag bit global 201, crc32 0x8F9CADA5 de flag_config) est posé par la scène jouée juste après la montée,
# jamais effacé (lu par c03_trigger n° 34 / 35) [C ; sauvegardes : 0 en 3-150, 1 en 3-190]. Lu par le client comme un
# boss d'histoire (entrée {location, flag} de `boss`), aucun changement du jeu. Avec l'option `chapitres` (checks
# d'histoire). Règle = celle de « Chapitre 3 terminé » (2 chapitres + Clés de l'école, Herbe, Tournevis : le n° 33 suit
# les n° 21 et 27, OBJETS_RANG_D) : exacte pour les objets, plus stricte d'un demi-chapitre, jamais moins. Genre
# « rang » (pas « histoire » : sa clé n'est pas un numéro de chapitre). C, B, A : doublons des requêtes de rang (même
# instant que leur fin), S : après-jeu : non créés.
RANG_D_CHECK: dict = {"cle": "rang_d", "id_ap": 59420054, "nom_fr": "Montée de rang : D", "nom_en": "Rank Up: D",
                      "flag": 201, "chapitre": 3, "region": "coteau_fleuri"}

# Coffres dorés du donjon des portails (La Corniche, t106d46 .. t106d62 ; index TBox 444-453, identifiants de l'ancien
# mod 59421230..239) : entrée refusée tant que la quête 6 n'est pas finie (t106d33_trigger n° 1, GetQuestPhase(qs0006)
# < 255), puis portes internes ouvertes avec des globes de portail (t106d41 n° 1-5) ; aucune condition de phase ni
# d'après-jeu sur les routes, les salles et les coffres [C]. Le coût en globes n'est pas modélisable (comme Tromplœil) :
# locations EXCLUES (remplissage seulement), règle de la requête 6 (checks oubliés, archipelago_couverture.md §9).
EXCLUSION_PORTAILS = "zone_portails"
QUETE_PORTAILS = 6

# Checks « tardifs » des portails mystères (docs/systemes/archipelago_portails_tardifs.md ; demande de l'humain : « longs à
# avoir »). Le mod n'a pas d'autre catégorie « tardif » que la location EXCLUE (remplissage seulement : jamais d'objet
# de progression) : ces checks sont exclus ET marqués (`LocationPlan.portail`) pour le tracker du lanceur.
# - PORTAIL_DONJON : donjon des portails de La Corniche (t106d41..) : portes payées en globes de portail, qui ne
#   viennent que du coffre de fin d'une salle de portail (quelques-uns par salle, `_tbox_gate`) et de la boutique N036 : des
#   dizaines de portails quelconques (10 coffres, Tromplœil, requête 8, Tablo-blabla n° 13 à 15) ;
# - PORTAIL_SALLE : exige UNE salle précise parmi les 45 de GATE_ENTER_INFO, tirée au sort à chaque portail
#   (FUN_0064E7B4) : boutique N036 (vendeur de la version « portail » de t104i23) ;
# - PORTAIL_CRANK : espèce sauvage seulement en salle de portail (Sumochi : gymnase t101i59 ; Alfoncéo : t103i31) mais
#   aussi lot de la Pièce rouge du Crank-a-kai (Sumochi 5 % au présent, Alfoncéo 4 % au passé) : long, pas impossible
#   (Tablo-blabla n° 9, amis Sumochi / Darumastar / Alfoncéo, déjà exclus ; PAS les requêtes 44 à 46 et 40, qui restent
#   comme avant) ;
# Non marquée : la requête 6 (son portail est scénarisé : salle fixée par la commande 0x3699('t101i21'), t106g00 n° 39).
# Règle : au moins celle de « Chapitre CHAPITRE_PORTAILS terminé » : les portails apparaissent (random_event, groupe du
# flag 2484) dès la requête 6 finie (>= 3-95) ou la phase 3-131, sauf de 4-35 à la fin du chapitre 4, pendant la
# tempête (flag 62, 7-40..7-70) et le siège (flag 63, 10-20..10-150) [C]. Boutique N036 : salle à condition
# GetPhase >= 4-50, donc chapitre 5 (boutiques.chapitre_article).
PORTAIL_DONJON = "donjon"
PORTAIL_SALLE = "salle"
PORTAIL_CRANK = "crank"
# PORTAIL_REQUETES : check qui exige TOUTES les requêtes (Pandanoko), dont « Le portail final » (donjon) : long pour cette
# raison, pas parce qu'il exigerait une salle précise.
PORTAIL_REQUETES = "requetes"
# PORTAIL_TUNNEL : même catégorie « tardif » (exclue + marquée pour le tracker), sans portail mystère : boss du bout du
# Tunnel sans fin (Taprice), cinq traversées complètes à raison d'une entrée par jour du jeu.
PORTAIL_TUNNEL = "tunnel"
PORTAILS = (PORTAIL_DONJON, PORTAIL_SALLE, PORTAIL_CRANK, PORTAIL_REQUETES, PORTAIL_TUNNEL)
CHAPITRE_PORTAILS = 3
TABLOS_PORTAILS: Dict[int, str] = {9: PORTAIL_CRANK, 13: PORTAIL_DONJON, 14: PORTAIL_DONJON, 15: PORTAIL_DONJON}
QUETES_PORTAILS: Dict[int, str] = {8: PORTAIL_DONJON}
BOSS_PORTAILS: Dict[str, str] = {"tromploeil": PORTAIL_DONJON, "taprice": PORTAIL_TUNNEL}
TAG_BOUTIQUE_PORTAILS = "x_portails"

# Bouclage du chapitre 10 (archipelago_couverture.md §2.3) : de 10-10 à la fin du chapitre 10, la ville est fermée
# (refoulements de c10_trigger) ; une location dont la règle exige au moins CHAPITRES_BOUCLAGE chapitres terminés est
# « du chapitre 10 » (histoire du chapitre 10), toute autre doit être faite avant (ou après la victoire). Aucune location
# hors de l'histoire du chapitre 10 ne doit avoir une telle règle (tests : CHAPITRE_10_JUSTIFIEES).
CHAPITRES_BOUCLAGE = 9
# Locations justifiées à 9 chapitres terminés (identifiants AP) : boss du chapitre 10 (Cyrustre, Fielippine, Maudicko,
# Ronéan, Lady Perpétua ; Lady Démona = la victoire), Tablo-blabla n° 3 (appel imposé à 10-45) et coffre 373 « Vieux
# Hauts de Granval (retour Ch10) » (t201g00 : zone du décor du chapitre 10, blocs de t201g00_mesh selon ev10_1100 /
# ev10_1400 / ev10_1700 ; accès avant le chapitre 10 non prouvé [?] : règle de l'ancien mod, mesurée en jeu, gardée
# jusqu'à l'essai du Gros test V1).
# + « Boss : Anguigne » (59423021, mode « tous » de `boss` : combat de l'étape 10-20).
CHAPITRE_10_JUSTIFIEES: FrozenSet[int] = frozenset({59423012, 59423011, 59423013, 59423014, 59420106, 59420107,
                                                    59422302, 59421192, 59423021})

REGION_ORIGINE = "menu"
# Classification d'un objet d'évènement cité par la règle du check « Ami » de son Yo-kai (location exclue) : progression
# pour qu'Archipelago évalue la règle, sans équilibrage (il n'ouvre rien d'autre). `__init__.CLASSIFICATIONS`.
CLASSE_PROGRESSION_SANS_EQUILIBRAGE = "progression_sans_equilibrage"
DERNIER_CHAPITRE = 10       # la fin du chapitre 10 est la victoire (Lady Démona)

NOMS_EVENEMENT_CHAPITRE = {"fr": "Chapitre {} terminé", "en": "Chapter {} complete"}
NOMS_GROUPES = {
    "fr": {"objet_cle": "Objets-clés", "consommable": "Consommables", "argent": "Argent",
           "coffres": "Coffres dorés", "emplacements": "Objets-clés (emplacements)", "boss": "Boss",
           "boss_quetes": "Boss de quête", "boss_melange": "Boss du mélange (ajoutés)",
           "rang": "Rangs de montre", "capacite": "Capacités",
           "tablos": "Tablo-blabla", "requetes": "Requêtes", "services": "Services", "histoire": "Histoire",
           "amis": "Amis", "criminels": "Yo-criminels", "evenement": "Objets d'évènement",
           "boutiques": "Boutiques", "invitation": "Invitations"},
    "en": {"objet_cle": "Key Items", "consommable": "Consumables", "argent": "Money",
           "coffres": "Golden Chests", "emplacements": "Key Items (locations)", "boss": "Bosses",
           "boss_quetes": "Quest Bosses", "boss_melange": "Shuffle Bosses (added)",
           "rang": "Watch Ranks", "capacite": "Abilities",
           "tablos": "Baffle Boards", "requetes": "Requests", "services": "Services", "histoire": "Story",
           "amis": "Friends", "criminels": "Yo-criminals", "evenement": "Event Items", "boutiques": "Shops",
           "invitation": "Invitations"},
}


def nom_evenement_chapitre(n: int, langue: str) -> str:
    return NOMS_EVENEMENT_CHAPITRE[langue].format(n)


# ---------------------------------------------------------------------------
# Tables fixes (indépendantes des options) : noms et identifiants
# ---------------------------------------------------------------------------
def coffres_v1() -> List[dict]:
    return [c for c in donnees().coffres if "exclusion" not in c]


def coffres_rangs() -> List[dict]:
    """Coffres exclus de la V1 pour un rang de montre (rang_C/B/A) : locations quand le verrou « rangs » est actif
    (sauf COFFRES_RANG_NON_LOCATIONS)."""
    return [c for c in donnees().coffres
            if c.get("exclusion") in EXCLUSIONS_RANG and c["index_tbox"] not in COFFRES_RANG_NON_LOCATIONS]


def coffres_portails() -> List[dict]:
    """Coffres du donjon des portails : locations exclues (remplissage seulement), règle de la requête 6."""
    return [c for c in donnees().coffres if c.get("exclusion") == EXCLUSION_PORTAILS]


def coffres_possibles() -> List[dict]:
    """Tous les coffres qui peuvent être des locations (la table des noms ne dépend pas des options)."""
    return coffres_v1() + coffres_rangs() + coffres_portails()


def regions_v1(rangs: bool = False) -> List[dict]:
    """Régions de la V1 ; avec le verrou « rangs », aussi celles qui sont derrière un verrou de montre (Clinique)."""
    return [r for r in donnees().regions
            if "exclusion" not in r or (rangs and r["cle"] in REGIONS_VERROU_DE_MONTRE)]


def nom_objet(cle: str, langue: str) -> str:
    return donnees().objets_par_cle[cle]["nom_" + langue]


def table_objets(langue: str) -> Dict[str, int]:
    """nom → identifiant AP, pour tous les objets (le paquet de données ne dépend pas des options)."""
    return {o["nom_" + langue]: o["id_ap"] for o in donnees().objets}


def table_locations(langue: str) -> Dict[str, int]:
    t = {c["nom_" + langue]: c["id_ap"] for c in coffres_possibles()}
    t.update({e["nom_" + langue]: e["id_ap"] for e in donnees().emplacements})
    t.update({b["nom_" + langue]: b["id_ap"] for b in TOUS_LES_BOSS})
    t[QUETE_VELO["nom_" + langue]] = QUETE_VELO["id_ap"]
    t.update({x["nom_" + langue]: x["id_ap"] for x in TABLOS_CREES})
    t.update({q["nom_" + langue]: q["id_ap"] for q in QUETES})
    t.update({c["nom_" + langue]: c["id_ap"] for c in CHAPITRES_CHECKS})
    t[RANG_D_CHECK["nom_" + langue]] = RANG_D_CHECK["id_ap"]
    t.update({a["nom_" + langue]: a["id_ap"] for a in AMIS})
    t.update({a["nom_" + langue]: a["id_ap"] for a in INVITES})
    t.update({c["nom_" + langue]: c["id_ap"] for c in CRIMINELS})
    t.update({a["nom_" + langue]: a["id_ap"] for a in BOUTIQUES_ARTICLES})
    return t


def groupes_objets(langue: str) -> Dict[str, Set[str]]:
    g: Dict[str, Set[str]] = {}
    for o in donnees().objets:
        g.setdefault(NOMS_GROUPES[langue][o["famille"]], set()).add(o["nom_" + langue])
    return g


def region_ami(a: dict) -> Optional[str]:
    """Région d'un check « Ami » lié à un lieu (amis_criminels.py) : ami d'histoire = région de l'évènement « Chapitre N
    terminé », ami de requête = région de la requête, ami d'évènement = région de la carte du combat ; None : sans
    région (espèce sauvage, évolution, fusion : lieux selon le mélange calculé chez le joueur)."""
    if a["origine"] == "histoire":
        return next(ch["region"] for ch in donnees().chapitres if ch["numero"] == a["chapitre"])
    if a["origine"] == "requete":
        return QUETES_PAR_NUMERO[a["quete"]]["region"]
    if a["origine"] in ("evenement", "place") or "base_invite" in a:   # évolution d'un invité : région de l'Auberge
        return a["region"]
    if a["origine"] == "fusion_objet":                                  # région de la source de l'objet de fusion
        return a["region"]
    return None


def groupes_locations(langue: str) -> Dict[str, Set[str]]:
    noms_regions = {r["cle"]: r["nom_" + langue] for r in donnees().regions}
    g: Dict[str, Set[str]] = {NOMS_GROUPES[langue]["coffres"]: set(), NOMS_GROUPES[langue]["emplacements"]: set()}
    for c in coffres_possibles():
        g[NOMS_GROUPES[langue]["coffres"]].add(c["nom_" + langue])
        g.setdefault(noms_regions[c["region"]], set()).add(c["nom_" + langue])
    for e in donnees().emplacements:
        g[NOMS_GROUPES[langue]["emplacements"]].add(e["nom_" + langue])
    g[NOMS_GROUPES[langue]["emplacements"]].add(QUETE_VELO["nom_" + langue])
    g.setdefault(noms_regions[QUETE_VELO["region"]], set()).add(QUETE_VELO["nom_" + langue])
    g[NOMS_GROUPES[langue]["boss"]] = {b["nom_" + langue] for b in TOUS_LES_BOSS}
    g[NOMS_GROUPES[langue]["boss_quetes"]] = {b["nom_" + langue] for b in BOSS_QUETES}
    g[NOMS_GROUPES[langue]["boss_melange"]] = {b["nom_" + langue] for b in BOSS_MELANGE}
    for b in TOUS_LES_BOSS:
        g.setdefault(noms_regions[b["region"]], set()).add(b["nom_" + langue])
    g[NOMS_GROUPES[langue]["tablos"]] = {x["nom_" + langue] for x in TABLOS_CREES}
    for x in TABLOS_CREES:
        g.setdefault(noms_regions[x["region"]], set()).add(x["nom_" + langue])
    g[NOMS_GROUPES[langue]["requetes"]] = {q["nom_" + langue] for q in QUETES if not q["service"]}
    g[NOMS_GROUPES[langue]["services"]] = {q["nom_" + langue] for q in QUETES if q["service"]}
    for q in QUETES:
        g.setdefault(noms_regions[q["region"]], set()).add(q["nom_" + langue])
    regions_chapitres = {ch["numero"]: ch["region"] for ch in donnees().chapitres}
    g[NOMS_GROUPES[langue]["histoire"]] = {c["nom_" + langue] for c in CHAPITRES_CHECKS} | {RANG_D_CHECK["nom_" + langue]}
    for c in CHAPITRES_CHECKS:
        g.setdefault(noms_regions[regions_chapitres[c["n"]]], set()).add(c["nom_" + langue])
    g.setdefault(noms_regions[RANG_D_CHECK["region"]], set()).add(RANG_D_CHECK["nom_" + langue])
    g[NOMS_GROUPES[langue]["amis"]] = {a["nom_" + langue] for a in AMIS}     # sans région (lieux selon le mélange),
    for a in AMIS:                                                 # sauf amis d'histoire, de requête et d'évènement
        region = region_ami(a)
        if region is not None:
            g.setdefault(noms_regions[region], set()).add(a["nom_" + langue])
    for a in INVITES:                                              # invités de l'Auberge : dans leur région seulement
        g.setdefault(noms_regions[a["region"]], set()).add(a["nom_" + langue])
    g[NOMS_GROUPES[langue]["criminels"]] = {c["nom_" + langue] for c in CRIMINELS}
    g[NOMS_GROUPES[langue]["boutiques"]] = {a["nom_" + langue] for a in BOUTIQUES_ARTICLES}
    for a in BOUTIQUES_ARTICLES:
        g.setdefault(noms_regions[BOUTIQUES_PAR_CODE[a["boutique"]]["region"]], set()).add(a["nom_" + langue])
    return g


# ---------------------------------------------------------------------------
# Plan d'une graine (dépend des options)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Regle:
    chapitres: int = 0                          # nombre de chapitres terminés (évènement « Chapitre N terminé »)
    objets: Tuple[str, ...] = ()                # clés d'objets exigés
    rangs: int = 0                              # exemplaires de « Rang de montre » exigés (verrou « rangs » actif)


@dataclass
class LocationPlan:
    nom: str
    id_ap: Optional[int]                        # None : évènement (chapitre, objectif)
    region: str                                 # clé de région
    regle: Regle
    genre: str                                  # "coffre", "emplacement", "boss", "quete", "tablo", "requete", "rang",
    #                                             "ami", "criminel", "boutique", "invite" (invité de l'Auberge),
    #                                             "histoire" (check « chapitre N terminé »), "chapitre" (évènement),
    #                                             "objectif"
    prologue: bool = True                       # exige aussi le Filet quand le Filet est exigé
    exclue: bool = False                        # remplissage seulement (LocationProgressType.EXCLUDED)
    portail: Optional[str] = None               # check « tardif » des portails mystères (PORTAILS) : toujours exclue
    verrou: Optional[str] = None                # objet (clé) placé d'office ici, à son emplacement d'origine
    evenement: Optional[str] = None             # nom de l'objet d'évènement placé ici
    cle: Optional[str] = None                   # emplacement : clé de l'objet d'origine ; chapitre : numéro
    index_tbox: Optional[int] = None            # coffre : index TBox ; emplacement : bit TBox du check
    flag: Optional[int] = None                  # boss d'histoire : index du flag bit global posé à la victoire ;
    #                                             Tablo-blabla : flag « Yo-kai appelé »
    quete: Optional[int] = None                 # boss de quête, « quete », « requete » : numéro de la quête (phase 255
    #                                             = terminée)
    octet: Optional[int] = None                 # boss (Taprice) : index d'un octet global de catégorie 6 (P + 0x144 + i) ;
    seuil: Optional[int] = None                 # check quand l'octet atteint ce seuil (valeur qui ne décroît jamais)
    service: bool = False                       # « requete » : service (genre 3 de QUEST_CONFIG, 255 transitoire)
    medaille: Optional[int] = None              # « ami », « invite » : n° du Médaillium (bit « ami » de P+0x44C / P+0x604)
    medailles: Tuple[int, ...] = ()             # « ami » : tous les n° qui valent le check (Ultramax N ou K), sinon vide
    etapes: Optional[int] = None                # « criminel » : nombre d'étapes (arrêté : octet P+0x2D0+n >= etapes)
    boutique: Optional[str] = None              # « boutique » : code N0xx de la boutique (fichier shop_shpN0xx)
    entrees: Tuple[int, ...] = ()               # « boutique » : rang(s) de l'entrée SHOP_CONFIG_INFO de l'article dans
    #                                             son fichier (hachage lu dans la ROM du joueur par le client)
    nb_entrees: Optional[int] = None            # « boutique » : nombre d'entrées du fichier (contrôle de la ROM)
    bit: Optional[int] = None                   # « boutique » : bit persistant « premier achat fait » (boite.h)


@dataclass
class Plan:
    langue: str
    regions: List[Tuple[str, str]]                              # (clé, nom)
    connexions: List[Tuple[str, str, Regle]]
    locations: List[LocationPlan]
    pool_objets_cles: List[str]                                 # objets-clés mélangés (clés)
    exiges: FrozenSet[str]                                      # objets cités par au moins une règle
    melanges: FrozenSet[str]                                    # objets d'emplacements mélangés
    verrous_actifs: Tuple[str, ...]
    boss: str = BOSS_PAR_DEFAUT                                 # mode de l'option `boss`
    rangs: int = 0                                              # exemplaires de « Rang de montre » dans le pool
    rangs_reel: bool = False                                    # verrou « rangs » en mode « rang réel » (§17)
    velo: bool = False                                          # verrou « velo » actif (objet et location ajoutés)
    tablos: str = TABLOS_PAR_DEFAUT                             # mode de l'option `tablos`
    quetes: str = QUETES_PAR_DEFAUT                             # mode de l'option `quetes`
    chapitres: bool = CHAPITRES_CHECKS_PAR_DEFAUT               # option `chapitres` : checks « chapitre N terminé »
    amis: str = AMIS_PAR_DEFAUT                                 # mode de l'option `amis`
    criminels: str = CRIMINELS_PAR_DEFAUT                       # mode de l'option `yo_criminels`
    objets_evenement: bool = False                              # option `objets_evenement` : objets des Yo-kai d'évènement
    invites: bool = False                                       # option `invites` : invitations dans le pool et checks
                                                                # « Ami : <invité> » (archipelago_invites.md §15)
    armees: bool = False                                        # checks « Ami » des 16 des armées (mélange des Yo-kai
                                                                # par rencontre, archipelago_amis_criminels.md §11)
    boutiques: str = BOUTIQUES_PAR_DEFAUT                       # mode de l'option `boutiques`
    boutiques_prix_max: int = PRIX_MAX_PAR_DEFAUT               # option `boutiques_prix_max` (classe de prix)
    classification: Dict[str, str] = field(default_factory=dict)
    nb_remplissage: int = 0
    objet_prologue: Optional[str] = None                        # le Filet, s'il est exigé en logique

    @property
    def filet_en_sphere_0(self) -> bool:
        """Vrai si le Filet est mélangé et exigé : il doit être atteignable avant tout le reste (§5.1)."""
        return self.objet_prologue is not None and self.objet_prologue in self.melanges

    @property
    def pile_en_sphere_2(self) -> bool:
        """Vrai si la Pile ou passe est mélangée et son verrou actif : elle doit être atteignable avec les Filets
        et les évènements du chapitre 1 (sphère 3 au plus du parcours, objets_cles §14.8), comme le Filet l'est sans
        rien (§12.7)."""
        return OBJET_PILE in self.melanges and OBJET_PILE in self.verrous_actifs

    def location(self, nom: str) -> LocationPlan:
        for loc in self.locations:
            if loc.nom == nom:
                return loc
        raise KeyError(nom)


def normaliser_boss(boss) -> str:
    """Option `boss` : nom du mode, ou booléen (True = histoire)."""
    if boss is True:
        return "histoire"
    if boss is False or boss is None:
        return "aucun"
    if boss not in MODES_BOSS:
        raise ValueError(f"mode de boss inconnu : {boss!r}")
    return boss


def normaliser_tablos(tablos) -> str:
    """Option `tablos` : nom du mode, ou booléen (True = tous)."""
    if tablos is True:
        return "tous"
    if tablos is False or tablos is None:
        return "aucun"
    if tablos not in MODES_TABLOS:
        raise ValueError(f"mode de Tablo-blabla inconnu : {tablos!r}")
    return tablos


def normaliser_quetes(quetes) -> str:
    """Option `quetes` : nom du mode, ou booléen (True = requetes)."""
    if quetes is True:
        return "requetes"
    if quetes is False or quetes is None:
        return "aucune"
    if quetes not in MODES_QUETES:
        raise ValueError(f"mode de quêtes inconnu : {quetes!r}")
    return quetes


def normaliser_amis(amis) -> str:
    """Option `amis` : nom du mode, ou booléen (True = tous)."""
    if amis is True:
        return "tous"
    if amis is False or amis is None:
        return "aucun"
    if amis not in MODES_AMIS:
        raise ValueError(f"mode d'amis inconnu : {amis!r}")
    return amis


def normaliser_criminels(criminels) -> str:
    """Option `yo_criminels` : nom du mode, ou booléen (True = tous)."""
    if criminels is True:
        return "tous"
    if criminels is False or criminels is None:
        return "aucun"
    if criminels not in MODES_CRIMINELS:
        raise ValueError(f"mode de Yo-criminels inconnu : {criminels!r}")
    return criminels


def normaliser_boutiques(boutiques) -> str:
    """Option `boutiques` : nom du mode, ou booléen (True = principales)."""
    if boutiques is True:
        return "principales"
    if boutiques is False or boutiques is None:
        return "aucune"
    if boutiques not in MODES_BOUTIQUES:
        raise ValueError(f"mode de boutiques inconnu : {boutiques!r}")
    return boutiques


def normaliser_options(objets_cles_melanges=True, verrous_actifs=()) -> Tuple[bool, FrozenSet[str]]:
    v = frozenset(verrous_actifs)
    inconnus = v - set(VERROUS_A_ACTIVER)
    if inconnus:
        raise ValueError(f"verrous inconnus : {sorted(inconnus)}")
    # verrou sans implémentation dans le patch : ignoré (règle R2 : la logique n'exige que les verrous réels)
    return bool(objets_cles_melanges), v & verrous_implementes()


def construire_plan(langue: str = "fr", objets_cles_melanges: bool = True, verrous_actifs=(),
                    boss=BOSS_PAR_DEFAUT, tablos=TABLOS_PAR_DEFAUT, quetes=QUETES_PAR_DEFAUT,
                    chapitres=CHAPITRES_CHECKS_PAR_DEFAUT, amis=AMIS_PAR_DEFAUT,
                    yo_criminels=CRIMINELS_PAR_DEFAUT, objets_evenement=OBJETS_EVENEMENT_PAR_DEFAUT,
                    boutiques=BOUTIQUES_PAR_DEFAUT, boutiques_prix_max=PRIX_MAX_PAR_DEFAUT,
                    rangs_reel: bool = True, invites: bool = INVITES_PAR_DEFAUT,
                    boutiques_retirees: bool = True, places: bool = PLACES_PAR_DEFAUT,
                    armees: bool = False) -> Plan:
    """Construit le plan d'une graine pour ces options (pur, déterministe). `rangs_reel` : sémantique du verrou
    « rangs » (sans effet s'il est inactif) : True = mode « rang réel » (toute nouvelle graine), False = ancien mode
    (graine de format <= 19 : le tracker du lanceur le lit dans `slot_data.verrous_actifs`). `places` : Yo-kai
    d'évènement à leur emplacement d'origine (3 invitations et « Capsule favorite » dans le pool, leurs locations) :
    True pour toute nouvelle graine ; False = graine générée avant (le tracker le lit dans slot_data : pas de liste
    `evenement_places`), dont le pool n'a pas ces objets. `armees` : la graine garantit un lieu normal aux 16 Yo-kai
    des armées (`amis_criminels.armees_garanties` : mélange des Yo-kai par rencontre, version >= 4) : leurs checks
    « Ami » existent alors, avec l'option `amis` = tous (False par défaut : ni l'APWorld sans ce mélange, ni une graine
    générée avant)."""
    if langue not in NOM_JEU:
        raise ValueError(langue)
    d = donnees()
    melanges_opt, actifs = normaliser_options(objets_cles_melanges, verrous_actifs)
    mode_boss = normaliser_boss(boss)
    mode_tablos = normaliser_tablos(tablos)
    mode_quetes = normaliser_quetes(quetes)
    mode_amis = normaliser_amis(amis)
    mode_criminels = normaliser_criminels(yo_criminels)
    mode_boutiques = normaliser_boutiques(boutiques)
    prix_max = int(boutiques_prix_max)
    # Rangs de montre (V1.1) : objet progressif, indépendant de `objets_cles_melanges` (ce n'est pas un don d'évènement)
    rangs = VERROU_RANGS in actifs
    exemplaires = VERROUS_A_ACTIVER[VERROU_RANGS]["exemplaires"] if rangs else 0
    reel = rangs and bool(rangs_reel)           # mode « rang réel » : rang de la montre = exemplaires reçus
    chapitre_rangs = (CHAPITRE_RANGS_REEL if reel else CHAPITRE_RANGS) if rangs else {}
    # rang D donné par l'histoire (c03 n° 33, après l'Herbe et le Tournevis) : sauf en mode « rang réel »
    objets_rang_d = () if reel else OBJETS_RANG_D
    # Vélo (V1.1) : objet sans emplacement d'évènement, indépendant de `objets_cles_melanges` (comme les rangs)
    velo = VERROU_VELO in actifs

    def rangs_exiges(rang_reel=None, verrou=None) -> int:
        return exemplaires_pour(rang_reel, verrou, reel) if rangs else 0

    objets_emplacements = {e["objet"] for e in d.emplacements}
    objets_cles = [o["cle"] for o in d.objets if o["famille"] == "objet_cle"]
    # toujours mélangés (coffres), sauf un objet dont le seul coffre n'est une location qu'avec le verrou « rangs »
    dans_coffres = [k for k in objets_cles if k not in objets_emplacements
                    and (k not in OBJETS_COFFRES_DE_RANG or rangs)]

    # Objets d'emplacement mélangés
    melanges = set()
    if melanges_opt:
        for k in objets_emplacements:
            if k in NON_MELANGES_V1:
                continue
            if k in VERROUS_POSSESSION or k in actifs:
                melanges.add(k)

    # Objets que la logique peut exiger : verrou garanti (possession), ou verrou actif ET objet mélangé.
    # Un objet laissé à son emplacement d'origine est donné par l'histoire au moment où elle en a besoin :
    # l'exiger n'apporterait rien et créerait des boucles (Clés de l'école données au chapitre 3 mais
    # « critiques » pour le chapitre 2 dans l'ancien mod).
    exigibles = set(VERROUS_POSSESSION) | {k for k in melanges if k in actifs}

    def filtre(objets) -> Tuple[str, ...]:
        return tuple(sorted(k for k in objets if k in exigibles))

    prologue = d.objet_prologue if d.objet_prologue in exigibles else None

    # -- régions et connexions ----------------------------------------------------------------------------
    regions_ok = {r["cle"] for r in regions_v1(rangs)}
    regions = [(r["cle"], r["nom_" + langue]) for r in regions_v1(rangs)]
    connexions = []
    for c in d.connexions:
        if c["source"] in regions_ok and c["cible"] in regions_ok:
            objets = tuple(c["regle"]["objets"]) + CONNEXIONS_OBJETS_SUPPLEMENTAIRES.get((c["source"], c["cible"]), ())
            connexions.append((c["source"], c["cible"],
                               Regle(c["regle"]["chapitres_termines"], filtre(objets),
                                     rangs_exiges(verrou=REGIONS_VERROU_DE_MONTRE.get(c["cible"])))))

    locations: List[LocationPlan] = []

    # -- coffres dorés --------------------------------------------------------------------------------------
    # Coffres derrière un verrou de montre (Manoir : verrou D) : rang réel D (OBJETS_RANG_D, avec ou sans le verrou
    # « rangs » ; sans objet en mode « rang réel ») et, avec le verrou « rangs », les exemplaires du verrou.
    for c in coffres_v1():
        montre = COFFRES_VERROU_DE_MONTRE.get(c["index_tbox"])
        ch = max(c["regle"]["chapitres_termines"], COFFRES_CHAPITRES_MIN.get(c["index_tbox"], 0))
        locations.append(LocationPlan(
            nom=c["nom_" + langue], id_ap=c["id_ap"], region=c["region"],
            regle=Regle(ch,
                        filtre(tuple(c["regle"]["objets"]) + COFFRES_OBJETS_SUPPLEMENTAIRES.get(c["index_tbox"], ())
                               + (objets_rang_d if montre else ())
                               + (("canne_a_peche",) if c["index_tbox"] in COFFRES_APRES_ARRET_CANNE else ())
                               + ((OBJET_PILE,) if ch == 1 and c["index_tbox"] not in COFFRES_AVANT_TUTORIEL_PILE
                                  else ())),
                        max(rangs_exiges(verrou=montre),
                            rangs_exiges(*COFFRES_RANGS_CHEMIN.get(c["index_tbox"], (None, None))),
                            rangs_exiges(COFFRES_APRES_ARRET_RANG.get(c["index_tbox"])) if reel else 0)),
            genre="coffre", index_tbox=c["index_tbox"]))

    # -- coffres derrière un verrou de montre ou un rang réel (V1.1, verrou « rangs » actif) ------------------------
    # Chapitres : ceux de l'ancien mod (mesurés avec un rang réel ramené au rang AP, comme le mode « rang réel ») ;
    # ancien mode : au moins le seuil du rang réel ; exemplaires : verrou de montre du coffre et/ou rang exigé
    # (exemplaires_pour).
    if rangs:
        for c in coffres_rangs():
            rang_reel = EXCLUSIONS_RANG[c["exclusion"]]
            locations.append(LocationPlan(
                nom=c["nom_" + langue], id_ap=c["id_ap"], region=c["region"],
                regle=Regle(max(c["regle"]["chapitres_termines"], 0 if reel else SEUIL_RANG_REEL[rang_reel]),
                            filtre(tuple(c["regle"]["objets"])
                                   + COFFRES_OBJETS_SUPPLEMENTAIRES.get(c["index_tbox"], ())),
                            rangs_exiges(rang_reel, COFFRES_VERROU_DE_MONTRE.get(c["index_tbox"]))),
                genre="coffre", index_tbox=c["index_tbox"]))

    # -- emplacements d'objets-clés -------------------------------------------------------------------------
    for e in d.emplacements:
        k = e["objet"]
        info = EMPLACEMENTS[k]
        est_melange = k in melanges
        locations.append(LocationPlan(
            nom=e["nom_" + langue], id_ap=e["id_ap"], region=REGION_ORIGINE,
            regle=Regle(info["chapitres"], filtre(info.get("apres", ())),
                        rangs_exiges(info.get("rang_reel"), info.get("verrou_montre"))),
            genre="emplacement", prologue=(k != d.objet_prologue),
            exclue=est_melange and not e["progression_permise"],
            verrou=None if est_melange else k, cle=k, index_tbox=info.get("bit"),
            flag=info.get("flag"), quete=info.get("quete")))

    # -- chapitres (évènements) -----------------------------------------------------------------------------
    critiques: Dict[int, Set[str]] = {}
    for ch in d.chapitres:
        critiques.setdefault(ch["numero"], set()).update(ch["objets_critiques"])
    for n, retires in CRITIQUES_RETIRES.items():
        critiques.get(n, set()).difference_update(retires)
    for k, n in CHAPITRE_BLOQUE_PAR.items():
        critiques.setdefault(n, set()).add(k)
    regle_chapitre: Dict[int, Regle] = {}
    for ch in d.chapitres:
        n = ch["numero"]
        if n > DERNIER_CHAPITRE:
            continue    # « chapitre 11 » = après la victoire
        if ch["region"] not in regions_ok:
            raise ValueError(f"chapitre {n} dans une région exclue")
        nom = nom_evenement_chapitre(n, langue)
        regle_chapitre[n] = Regle(ch["chapitres_termines"], filtre(critiques.get(n, ())),
                                  chapitre_rangs.get(n, 0))
        locations.append(LocationPlan(
            nom=nom, id_ap=None, region=ch["region"], regle=regle_chapitre[n],
            genre="chapitre", evenement=nom, cle=str(n)))

    # -- objectif -------------------------------------------------------------------------------------------
    obj = d.objectif
    regle_objectif = Regle(obj["regle"]["chapitres_termines"], filtre(obj["regle"]["objets"]),
                           max(chapitre_rangs.values(), default=0))
    locations.append(LocationPlan(
        nom=obj["nom_" + langue], id_ap=None, region=obj["region"], regle=regle_objectif,
        genre="objectif", evenement=obj["nom_" + langue], cle=obj["cle"]))

    # -- boss d'histoire (règle du chapitre du boss ; Lady Démona : objectif, exclue) ----------------------------
    if mode_boss != "aucun":
        for b in BOSS_HISTOIRE:
            if b["region"] not in regions_ok:
                raise ValueError(f"boss {b['cle']} dans une région exclue")
            victoire = bool(b.get("victoire"))
            locations.append(LocationPlan(
                nom=b["nom_" + langue], id_ap=b["id_ap"], region=b["region"],
                regle=regle_objectif if victoire else regle_chapitre[b["chapitre"]],
                genre="boss", exclue=victoire, cle=b["cle"], flag=b["flag"]))

    # -- boss de quête (règle du chapitre + objets du chemin de la quête ; Tromplœil : exclu) --------------------
    if mode_boss in ("histoire_et_quetes", "tous"):
        for b in BOSS_QUETES:
            if b["region"] not in regions_ok:
                raise ValueError(f"boss {b['cle']} dans une région exclue")
            r = regle_chapitre[b["chapitre"]]
            regle = Regle(r.chapitres, tuple(sorted(set(r.objets) | set(filtre(b.get("objets", ()))))),
                          max(r.rangs, rangs_exiges(b.get("rang_reel"), b.get("verrou_montre"))))
            locations.append(LocationPlan(
                nom=b["nom_" + langue], id_ap=b["id_ap"], region=b["region"], regle=regle,
                genre="boss", exclue=bool(b.get("exclue")), portail=BOSS_PORTAILS.get(b["cle"]), cle=b["cle"],
                quete=b["quete"]))

    # -- boss du mélange ajoutés (mode « tous » : règle du chapitre du combat ; Taprice : exclu, marqué « tunnel ») --
    if mode_boss == "tous":
        for b in BOSS_MELANGE:
            if b["region"] not in regions_ok:
                raise ValueError(f"boss {b['cle']} dans une région exclue")
            locations.append(LocationPlan(
                nom=b["nom_" + langue], id_ap=b["id_ap"], region=b["region"], regle=regle_chapitre[b["chapitre"]],
                genre="boss", exclue=bool(b.get("exclue")), portail=BOSS_PORTAILS.get(b["cle"]), cle=b["cle"],
                flag=b.get("flag"), quete=b.get("quete"), octet=b.get("octet"), seuil=b.get("seuil")))

    # -- Vélo (V1.1) : fin de la requête qs0009 (règle du chapitre 7, comme un boss de quête) ------------------------
    if velo:
        if QUETE_VELO["region"] not in regions_ok:
            raise ValueError("location du Vélo dans une région exclue")
        locations.append(LocationPlan(
            nom=QUETE_VELO["nom_" + langue], id_ap=QUETE_VELO["id_ap"], region=QUETE_VELO["region"],
            regle=regle_chapitre[QUETE_VELO["chapitre"]], genre="quete", cle=QUETE_VELO["cle"],
            quete=QUETE_VELO["quete"]))

    # -- Tablo-blabla : flag « Yo-kai appelé » ; exclus sauf le n° 3 (imposé par la phase 10-45) -----------------------
    if mode_tablos == "tous":
        for x in TABLOS_CREES:
            if x["region"] not in regions_ok:
                raise ValueError(f"Tablo-blabla n° {x['n']} dans une région exclue")
            r = regle_chapitre[x["chapitre"]]
            regle = Regle(r.chapitres, tuple(sorted(set(r.objets) | set(filtre(x.get("objets", ()))))),
                          max(r.rangs, rangs_exiges(verrou=x.get("verrou_montre"))))
            locations.append(LocationPlan(
                nom=x["nom_" + langue], id_ap=x["id_ap"], region=x["region"], regle=regle, genre="tablo",
                exclue=not x.get("progression"), portail=TABLOS_PORTAILS.get(x["n"]), cle=str(x["n"]),
                flag=x["flag"]))

    # -- requêtes et services : quête terminée (phase 255) ; règle du chapitre N + objets du chemin ----------------
    def regle_quete(q: dict) -> Regle:
        r = regle_chapitre[q["chapitre"]]
        return Regle(r.chapitres, tuple(sorted(set(r.objets) | set(filtre(q["objets"])))),
                     max(r.rangs, rangs_exiges(q["rang_reel"], q["verrou_montre"])))

    if mode_quetes != "aucune":
        for q in QUETES:
            if q["service"] and mode_quetes != "requetes_et_services":
                continue
            if q["region"] not in regions_ok:
                raise ValueError(f"quête n° {q['n']} dans une région exclue")
            locations.append(LocationPlan(
                nom=q["nom_" + langue], id_ap=q["id_ap"], region=q["region"], regle=regle_quete(q), genre="requete",
                exclue=q["exclue"], portail=QUETES_PORTAILS.get(q["n"]), cle=str(q["n"]), quete=q["n"],
                service=q["service"]))

    # -- checks « Chapitre N terminé » (1 à 9) : quête de chapitre 170 + N terminée ; règle de l'évènement ---------------
    regions_chapitres = {ch["numero"]: ch["region"] for ch in d.chapitres}
    if chapitres:
        for c in CHAPITRES_CHECKS:
            locations.append(LocationPlan(
                nom=c["nom_" + langue], id_ap=c["id_ap"], region=regions_chapitres[c["n"]],
                regle=regle_chapitre[c["n"]], genre="histoire", cle=str(c["n"]), quete=c["quete"]))
        # « Montée de rang : D » : flag « évènement vu » de ev03_2300 (lu comme un boss d'histoire)
        r = RANG_D_CHECK
        if r["region"] not in regions_ok:
            raise ValueError("Montée de rang : D dans une région exclue")
        locations.append(LocationPlan(
            nom=r["nom_" + langue], id_ap=r["id_ap"], region=r["region"], regle=regle_chapitre[r["chapitre"]],
            genre="rang", cle=r["cle"], flag=r["flag"]))

    # -- coffres du donjon des portails : exclus (coût en globes non modélisable), règle de la requête 6 --------------
    q6 = QUETES_PAR_NUMERO[QUETE_PORTAILS]
    r6 = regle_chapitre[q6["chapitre"]]
    for c in coffres_portails():
        if c["region"] not in regions_ok:
            raise ValueError(f"coffre {c['index_tbox']} dans une région exclue")
        locations.append(LocationPlan(
            nom=c["nom_" + langue], id_ap=c["id_ap"], region=c["region"],
            regle=r6,
            genre="coffre", exclue=True, portail=PORTAIL_DONJON, index_tbox=c["index_tbox"]))

    # -- amis : bit « ami » du Médaillium (amis_criminels.py) ------------------------------------------------------
    # - espèce sauvage, évolution, fusion : exclus (lieux selon le mélange calculé chez le joueur, amitié aléatoire) ;
    # - fusion avec objet (FUSIONS_OBJET, archipelago_amis_criminels.md §10) : exclue, règle du chapitre (au moins un
    #   après la base, et celui de la source de l'objet), dans la région de la source de l'objet ;
    # - les 16 des armées (origine « armee », §11) : exclus, seulement si `armees` (mélange des Yo-kai par rencontre) ;
    # - ami d'histoire (don automatique d'un déclencheur de phase) : NON exclu, règle et région de l'évènement
    #   « Chapitre N terminé » du chapitre du don ;
    # - ami de requête (don du script de la requête) : règle, région et exclusion de la requête ;
    # - ami d'évènement : plus bas (après le pool : seulement si son objet y est).
    if mode_amis == "tous":
        for a in AMIS:
            if a["origine"] in ("evenement", "place") or "base_invite" in a:   # plus bas (selon le pool et `invites`)
                continue
            if a["origine"] == "armee" and not armees:      # seulement si le mélange de la graine les place (§11)
                continue
            region, exclue = region_ami(a) or REGION_ORIGINE, True
            if a["origine"] == "histoire":
                r, exclue = regle_chapitre[a["chapitre"]], False
            elif a["origine"] == "requete":
                q = QUETES_PAR_NUMERO[a["quete"]]
                r, exclue = regle_quete(q), q["exclue"]
            else:
                r = regle_chapitre[a["chapitre"]]
                if reel and a["chapitre"] >= AMI_CHAPITRE_RANG_D:
                    r = Regle(r.chapitres, r.objets, max(r.rangs, EXEMPLAIRES_RANG["D"]))
                if a.get("quete") is not None:      # fusion avec objet donné par le script d'une requête (Tendino)
                    rq = regle_quete(QUETES_PAR_NUMERO[a["quete"]])
                    r = Regle(max(r.chapitres, rq.chapitres), tuple(sorted(set(r.objets) | set(rq.objets))),
                              max(r.rangs, rq.rangs))
            if region not in regions_ok:
                raise ValueError(f"ami n° {a['medaille']} dans une région exclue")
            locations.append(LocationPlan(
                nom=a["nom_" + langue], id_ap=a["id_ap"], region=region, regle=r,
                genre="ami", exclue=exclue, portail=a.get("portail") if exclue else None, cle=str(a["medaille"]),
                medaille=a["medaille"]))

    # -- invités de l'Auberge des voyageurs (amis_criminels.py INVITES, archipelago_invites.md §14) : genre « invite »,
    # hors de l'option `amis`. Déclencheur « requetes » = toutes les locations de genre « requete » de la graine
    # cochées ; sans requêtes : ni invité ni location. EXCLUS ; règle = conjonction des règles de ces requêtes
    # (chapitres et rangs : maximum ; objets : union), dans la région de l'Auberge (son accès s'ajoute par la
    # connexion).
    requetes = [loc for loc in locations if loc.genre == "requete"]
    for a in INVITES:
        if a["declencheur"] != "requetes" or not requetes:
            continue
        if a["region"] not in regions_ok:
            raise ValueError(f"invité n° {a['medaille']} dans une région exclue")
        r0 = regle_chapitre[a["chapitre"]]
        r = Regle(max([r0.chapitres] + [x.regle.chapitres for x in requetes]),
                  tuple(sorted(set(r0.objets).union(*(x.regle.objets for x in requetes)))),
                  max([r0.rangs] + [x.regle.rangs for x in requetes]))
        locations.append(LocationPlan(
            nom=a["nom_" + langue], id_ap=a["id_ap"], region=a["region"], regle=r,
            genre="invite", exclue=True, cle=str(a["medaille"]), medaille=a["medaille"],
            # toutes les requêtes, donc aussi celles des portails mystères (la plus longue : le donjon, requête 8)
            portail=PORTAIL_REQUETES if any(x.portail for x in requetes) else None))

    # -- Yo-criminels : octet `wantedNN` (étapes gagnées) ; LIBRES avec le patch (fonction 24, limites.cpp) : le jeu
    # propose toujours le premier non arrêté de ORDRE_CRIMINELS (par chapitre puis numéro) : NON exclus ; règle du
    # chapitre du criminel, au moins CRIMINELS_CHAPITRE_MIN (les 5 cartes du tirage de l'emplacement) ; tous ceux qui
    # le précèdent dans l'ordre ont une règle inférieure ou égale (archipelago_amis_criminels.md §6.4) --------------
    if mode_criminels == "tous":
        for c in CRIMINELS:
            if c["region"] not in regions_ok:
                raise ValueError(f"Yo-criminel n° {c['n']} dans une région exclue")
            locations.append(LocationPlan(
                nom=c["nom_" + langue], id_ap=c["id_ap"], region=c["region"],
                regle=regle_chapitre[max(c["chapitre"], CRIMINELS_CHAPITRE_MIN)],
                genre="criminel", exclue=False, cle=str(c["n"]), etapes=c["etapes"]))

    # -- boutiques : premier achat d'un article (bit persistant, jeu v9) ; règle de la région de la carte + chapitre de
    # l'article (au moins un chapitre terminé ; 6-10, quête 62, portes de carte : boutiques.py) ; exclues : hors du
    # périmètre principal (mode « toutes ») ou plus chères que `boutiques_prix_max` (attente d'argent)
    for a in articles_du_mode(mode_boutiques, boutiques_retirees):
        b = a["boutique"]
        region = BOUTIQUES_PAR_CODE[b]["region"]
        if region not in regions_ok:
            raise ValueError(f"boutique {b} dans une région exclue")
        r = regle_chapitre[chapitre_article(a)]
        if reel and b in BOUTIQUES_RANG:
            r = Regle(r.chapitres, r.objets, max(r.rangs, EXEMPLAIRES_RANG[BOUTIQUES_RANG[b]]))
        locations.append(LocationPlan(
            nom=a["nom_" + langue], id_ap=a["id_ap"], region=region, regle=r,
            genre="boutique", exclue=boutique_exclue(a, prix_max),
            portail=PORTAIL_SALLE if a["tag"] == TAG_BOUTIQUE_PORTAILS else None, cle="%s/%d" % (b, a["n"]), boutique=b,
            entrees=a["entrees"], nb_entrees=BOUTIQUES_PAR_CODE[b]["nb_entrees"], bit=a["bit"]))

    # -- objets ---------------------------------------------------------------------------------------------
    pool = sorted(dans_coffres) + sorted(melanges) + [OBJET_RANG] * exemplaires + ([VERROU_VELO] if velo else [])
    cites = set()
    for _, _, r in connexions:
        cites.update(r.objets)
    for loc in locations:
        cites.update(loc.regle.objets)
    if prologue:
        cites.add(prologue)

    classification = {}
    for o in d.objets:
        k = o["cle"]
        if o["famille"] == "objet_cle":
            classification[k] = "progression" if k in cites else "utile"
        else:
            classification[k] = o["classification"]

    nb_verrouilles = sum(1 for loc in locations if loc.verrou)
    nb_locations = sum(1 for loc in locations if loc.id_ap is not None)
    # Objets des Yo-kai d'évènement (option `objets_evenement`, archipelago_amis_criminels.md §7.4) : un exemplaire de
    # chacun, à la place du remplissage (dans la limite des places libres). « Utiles » (jamais de progression) tant
    # qu'aucune règle ne les cite ; seule la règle du check « Ami » de LEUR Yo-kai peut en citer un (ci-dessous).
    evenement = [o["cle"] for o in d.objets if o["famille"] == "evenement"
                 and (places or o["cle"] not in PLACES_PAR_OBJET)] if objets_evenement else []
    evenement = evenement[:max(0, nb_locations - nb_verrouilles - len(pool))]
    if cites & set(evenement):
        raise ValueError("objet d'évènement exigé par une règle")
    pool += evenement

    # -- amis d'évènement (archipelago_amis_criminels.md §8.3) : EXCLUS (amitié au hasard) ; créés seulement si l'objet
    # du Yo-kai est dans le pool ; règle = l'objet + la règle de « Chapitre N terminé », dans la région de la carte du
    # combat. Pour qu'Archipelago puisse évaluer cette règle, l'objet cité devient « progression sans équilibrage »
    # (un objet « utile » n'entre jamais dans l'état d'Archipelago : la location serait inatteignable et la
    # génération refusée) ; une location exclue ne reçoit jamais de progression : l'objet d'un Yo-kai n'est donc jamais
    # placé sur un check « Ami » d'évènement (ni le sien, ni un autre). Chaque location ajoute une place de remplissage.
    if mode_amis == "tous":
        for a in AMIS:
            if a["origine"] != "evenement" or a["objet"] not in evenement:
                continue
            if a["region"] not in regions_ok:
                raise ValueError(f"ami n° {a['medaille']} dans une région exclue")
            r = regle_chapitre[a["chapitre"]]
            locations.append(LocationPlan(
                nom=a["nom_" + langue], id_ap=a["id_ap"], region=a["region"],
                regle=Regle(r.chapitres, tuple(sorted(set(r.objets) | {a["objet"]})), r.rangs),
                genre="ami", exclue=True, cle=str(a["medaille"]), medaille=a["medaille"],
                medailles=tuple(a.get("medailles", ()))))
            classification[a["objet"]] = CLASSE_PROGRESSION_SANS_EQUILIBRAGE
            cites.add(a["objet"])
            nb_locations += 1
    # -- invités de l'Auberge à INVITATION (option `invites`, archipelago_invites.md §15) : un objet « Invitation :
    # <nom> » et une location « Ami : <nom> » par invité (+30 objets, +30 locations : pool équilibré). Location EXCLUE
    # (amitié au taux du jeu) ; règle = l'invitation + la règle de « Chapitre N terminé » dans la région de l'Auberge
    # (son accès s'ajoute par la connexion). Même raison que les objets d'évènement : l'objet cité par une règle doit
    # être de progression pour qu'Archipelago l'évalue ; « sans équilibrage » puisqu'il n'ouvre qu'une location exclue.
    invitations = []
    if invites:
        for a in INVITES:
            if a["declencheur"] != "objet":
                continue
            if a["region"] not in regions_ok:
                raise ValueError(f"invité n° {a['medaille']} dans une région exclue")
            r = regle_chapitre[a["chapitre"]]
            locations.append(LocationPlan(
                nom=a["nom_" + langue], id_ap=a["id_ap"], region=a["region"],
                regle=Regle(r.chapitres, tuple(sorted(set(r.objets) | {a["objet"]})), r.rangs),
                genre="invite", exclue=True, cle=str(a["medaille"]), medaille=a["medaille"]))
            classification[a["objet"]] = CLASSE_PROGRESSION_SANS_EQUILIBRAGE
            cites.add(a["objet"])
            invitations.append(a["objet"])
            nb_locations += 1
        # Yo-kai d'évènement à leur emplacement d'origine (amis_criminels.py, origine « place » ;
        # archipelago_evenement_invitation.md §9) : même schéma (objet « Invitation : <nom> », location « Ami : <nom> »
        # EXCLUE, règle = l'invitation + « Chapitre N terminé » dans la région de la carte du PNJ), mais location de
        # genre « ami » (liste `amis` de slot_data : le Yo-kai n'est pas un invité de l'Auberge).
        for a in AMIS:
            if a["origine"] != "place" or not places:
                continue
            if a["region"] not in regions_ok:
                raise ValueError(f"ami n° {a['medaille']} dans une région exclue")
            r = regle_chapitre[a["chapitre"]]
            locations.append(LocationPlan(
                nom=a["nom_" + langue], id_ap=a["id_ap"], region=a["region"],
                regle=Regle(r.chapitres, tuple(sorted(set(r.objets) | {a["objet"]})), r.rangs),
                genre="ami", exclue=True, cle=str(a["medaille"]), medaille=a["medaille"]))
            classification[a["objet"]] = CLASSE_PROGRESSION_SANS_EQUILIBRAGE
            cites.add(a["objet"])
            invitations.append(a["objet"])
            nb_locations += 1
        pool += invitations
        # Évolutions par niveau des invités de l'Auberge (amis_criminels.EVOLUTIONS_INVITES, archipelago_amis_criminels.md
        # §9) : check « Ami » EXCLU de l'espèce évoluée, avec l'option `amis` = tous ; règle = l'invitation de la BASE +
        # « Chapitre N terminé » (un chapitre après la base), dans la région de l'Auberge ; aucun objet de plus (une
        # place de remplissage chacun).
        if mode_amis == "tous":
            for a in AMIS:
                base = INVITES_PAR_MEDAILLE.get(a.get("base_invite"))
                if base is None or base["objet"] not in invitations:
                    continue
                r = regle_chapitre[a["chapitre"]]
                locations.append(LocationPlan(
                    nom=a["nom_" + langue], id_ap=a["id_ap"], region=a["region"],
                    regle=Regle(r.chapitres, tuple(sorted(set(r.objets) | {base["objet"]})), r.rangs),
                    genre="ami", exclue=True, cle=str(a["medaille"]), medaille=a["medaille"]))
                nb_locations += 1
    nb_remplissage = nb_locations - nb_verrouilles - len(pool)
    if nb_remplissage < 0:
        raise ValueError("plus d'objets que de locations")

    return Plan(langue=langue, regions=regions, connexions=connexions, locations=locations,
                pool_objets_cles=pool, exiges=frozenset(cites), melanges=frozenset(melanges),
                verrous_actifs=tuple(sorted(actifs)), boss=mode_boss, rangs=exemplaires, rangs_reel=reel, velo=velo,
                tablos=mode_tablos, quetes=mode_quetes, chapitres=bool(chapitres), amis=mode_amis, criminels=mode_criminels,
                objets_evenement=bool(evenement), invites=bool(invitations),
                armees=bool(armees) and mode_amis == "tous", boutiques=mode_boutiques,
                boutiques_prix_max=prix_max,
                classification=classification, nb_remplissage=nb_remplissage, objet_prologue=prologue)


def remplissage_possible() -> Tuple[List[str], List[str]]:
    """(consommables, argent) : clés des objets de remplissage."""
    d = donnees()
    conso = [o["cle"] for o in d.objets if o["famille"] == "consommable"]
    argent = [o["cle"] for o in d.objets if o["famille"] == "argent"]
    return conso, argent
