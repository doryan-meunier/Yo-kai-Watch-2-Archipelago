"""Cœur de synchronisation serveur Archipelago <-> boîte aux lettres du jeu (tâche C3, CONCEPTION §8.1, option B).

Le client est invisible : la configuration se saisit dans le LANCEUR seulement (config.json ; décision de
l'humain du 2026-09-28 : l'écran « Archipelago » de l'écran titre est en lecture seule) ; le jeu affiche l'état
(§5.2 : écran Archipelago et bandeau). Ce module :
1. surveille config.json (saisie du lanceur, sans GDB : révision de connexion, reconnexion si elle change quelque
   chose) et publie la configuration courante dans la zone « état » (serveur, slot, `connu` : jamais le mot de
   passe) ; la configuration qu'un jeu d'une version antérieure écrirait encore (zone J, claviers) est ignorée ;
2. se connecte au serveur (`ap_reseau.ClientAP`) et publie l'état : non configuré / connexion / connecté /
   erreur (+ message court en français) / déconnecté ;
3. dons : liste `ReceivedItems` -> file de dons (numéro = index AP + 1 ; « déjà livré » = compteur de la
   sauvegarde) ; notifications courtes (≤ 28 caractères, bandeau mono-ligne) ;
4. checks : journal (coffres ouverts, dons d'objets-clés substitués) et relecture des bits persistants
   (P+0x3C4 : coffres, spots 558..569 ; flags bit globaux de P+4 : boss d'histoire vaincus, posés par le jeu à
   la victoire seulement ; phases de quête de Q = *(*0x815244 + 0x10) : boss de quête, quête terminée (255)
   seulement après la victoire, docs/systemes/archipelago_boss.md ; flags « Yo-kai appelé » des Tablo-blabla,
   docs/systemes/archipelago_tablos.md ; octets `wantedNN` des Yo-criminels arrêtés, dans le même paquet ; bits « ami »
   du Médaillium, lus avec le suivi du tracker (5ter), docs/systemes/archipelago_amis_criminels.md) -> LocationChecks ;
5. tables (slot_data de l'APWorld, format 1 ; LocationScouts en repli) : coffres par index (objet de ce
   monde = vrai objet ; sinon vitrine), noms de vitrine par étiquette « <objet> (pour <joueur>) » (J5), dons
   de script des spots d'objets-clés (J3), verrous actifs et objets reçus (J4), récompenses de quête (boîte v5 :
   l'écran de résultat d'une requête montre l'objet AP à la place des objets de la quête, archipelago_quetes.md §8) ;
5bis. randomizer de Yo-kai (boîte v6, docs/systemes/archipelago_rando_yokai.md) : mélange σ calculé depuis la graine
   de `slot_data["rando_yokai"]` et la base locale `yokai_local.json` (générée depuis la ROM du joueur, jamais
   distribuée ; empreinte différente de la référence : mélange refusé), écrit dans la boîte seulement pour la
   sauvegarde liée (sinon `valide` = 0 : le jeu retire le mélange), `rando_yokai.json` pour le tracker du lanceur ;
5quater. randomizer des boss (boîte v7, docs/systemes/archipelago_rando_boss.md §9) : tables B / N calculées depuis la
   graine de `slot_data["rando_boss"]` et la base locale (format 4), écrites pour la sauvegarde liée seulement (même
   protocole que 5bis), `rando_boss.json` pour le tracker du lanceur ;
5ter. suivi pour le tracker du lanceur (sauvegarde liée seulement, avec ou sans randomizer) : `medaillium.json` (« vu »
   et « ami » du Médaillium, une lecture groupée P+0x40C..0x643) et `progression.json` (chapitre, pas, phase, rang de
   montre réel, après-jeu), toutes les PERIODE_MEDAILLIUM secondes ou dès que la progression publiée change ; en-tête
   relu après les données (écartées si la partie a changé) ; base locale d'un format antérieur régénérée depuis la
   ROM (une fois par session) ;
6. victoire (en-tête `progression` : flag « partie terminée », ou chapitre ≥ 11) -> CLIENT_GOAL, une fois, et
   seulement si elle survient APRÈS la liaison de la sauvegarde ; verrous (J4) : le jeu publie la liste des
   verrous COMPILÉS dans son build (boîte v4, zone des verrous +4) ; une partie dont `slot_data.verrous_actifs`
   exige un verrou absent est refusée (état « Verrous incompatibles » : rien n'est lié, livré ni envoyé, car la
   logique de la graine compterait sur un blocage que le jeu ne fait pas) ;
7. LIAISON de la sauvegarde (boîte v4, docs/systemes/archipelago_boite.md §11.2-§11.3) : le client n'adopte
   JAMAIS une sauvegarde qu'il n'a pas liée à cette partie AP. Seule une sauvegarde dont l'identifiant
   (P+0x3BC) vaut `ident_partie` est « liée » : elle seule reçoit des dons, envoie des checks et la victoire, et
   voit les tables (coffres, dons de script, verrous). Liaison automatique d'une partie NEUVE seulement
   (`raison_non_neuve`) : une partie Archipelago = une sauvegarde NEUVE (décision de l'humain du 2026-09-28,
   option (b) : la liaison manuelle d'une sauvegarde existante n'existe plus ; le client n'écrit jamais de clé
   manuelle). Une sauvegarde liée À LA MAIN par une version antérieure (clé bit 15) reste liée, règle G1-2 (décision de l'humain) : les checks DÉJÀ
   faits dans cette sauvegarde (coffres, spots, boss, quêtes, Tablo-blabla) sont envoyés, une fois ; la VICTOIRE
   jamais par cet effet : l'instantané (`RegistreLiaisons`, fichier `liaisons.json` du dossier du client) garde les
   bits de victoire déjà présents, et seule une victoire apparue APRÈS la liaison compte (une sauvegarde déjà finie
   ne fait jamais gagner la partie). Instantané d'exclusion restant : sauvegarde liée par un client v3 (clé 0) ;
8. resynchronisation complète après un relancement du jeu (nouvelle instance de la boîte) ou du client ;
9. suivi des checks pour l'onglet « Checks » du lanceur (`checks_local.py`) : `checks.json` (locations de la graine,
   faites, contenu des FAITES seulement, indices du serveur, objets reçus et expéditeurs, options du plan), réécrit
   seulement quand il change, sur évènement réseau (aucune lecture GDB) ; spoiler log `.txt` écrit seulement sur
   demande du lanceur (`spoiler_demande.json`, surveillé avec config.json), depuis les LocationScouts de TOUTES les
   locations du slot ;
10. discussion du serveur pour l'onglet « Discussion » du lanceur (`chat_local.py`) : chaque PrintJSON (couleurs résolues)
   et les évènements de connexion sont ajoutés à `messages.jsonl` (borné, rotation) ; les messages et commandes « !… »
   saisis dans le lanceur (`chat_commandes.json`, surveillé toutes les PERIODE_CHAT s) sont envoyés par Say, une fois,
   seulement par le client de la session visée et s'il est connecté. Fichiers locaux seulement : aucun paquet GDB.
   Sous-onglet « Indices » (`indices_local.py`) : indices du slot (clé `_read_hints_{team}_{slot}`, Get + SetNotify)
   écrits dans `indices.json` à chaque changement ; une commande du lanceur peut porter une action UpdateHint
   (priorité d'un indice), validée puis envoyée.
11. fenêtre « objet obtenu » des checks sans affichage dans le jeu (`anim_objet.py`, archipelago_boite.md §27) : chaque
   check envoyé d'une location « sans affichage » (boss, fins de chapitre, Montée de rang, Vélo, Tablo-blabla ; toujours
   actif, sans option) est mis dans la file ApAnim du jeu (sauvegarde liée, fonction 29 compilée), 8 places au plus ;
   le jeu les montre une par une au moment sûr du terrain. En-tête de la file lu seulement pendant qu'il y a du travail.

Le transport est abstrait : `PontGdb` (réel ou faux stub) et `ClientAP` (réel ou faux serveur) ; tout est
testable hors ligne (archipelago/tests/test_synchro.py).
"""
from __future__ import annotations

import asyncio
import collections
import contextlib
import copy
import json
import logging
import secrets
import struct
import sys
import time
import zlib
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Callable, Iterable

try:
    from . import boite_protocole as bp
    from . import chat_local as ch
    from . import deathlink as dl
    from . import anim_objet as ao
    from . import checks_local as ck
    from . import indices_local as il
    from . import lieu_local as ll
    from . import boite_v3 as v3
    from . import rando_yokai as rando
    from . import rando_boss as rboss
    from .ap_reseau import ClientAP, ObjetReseau, RefusConnexion
    from .boite import Boite, BoiteAbsente, EntreeCoffre, Entete, FilePleine, ObjetADonner
    from .config_locale import ConfigLocale, StockageConfig
    from .gdb import AccesRefuse, ArretNonConfirme, Deconnecte, DelaiDepasse, ErreurGdb, PontGdb
except ImportError:                                          # pragma: no cover - selon le mode d'import
    import boite_protocole as bp                            # type: ignore[no-redef]
    import chat_local as ch                                 # type: ignore[no-redef]
    import deathlink as dl                                  # type: ignore[no-redef]
    import anim_objet as ao                                 # type: ignore[no-redef]
    import checks_local as ck                               # type: ignore[no-redef]
    import indices_local as il                              # type: ignore[no-redef]
    import lieu_local as ll                                 # type: ignore[no-redef]
    import boite_v3 as v3                                   # type: ignore[no-redef]
    import rando_yokai as rando                             # type: ignore[no-redef]
    import rando_boss as rboss                              # type: ignore[no-redef]
    from ap_reseau import ClientAP, ObjetReseau, RefusConnexion  # type: ignore[no-redef]
    from boite import (Boite, BoiteAbsente, EntreeCoffre, Entete,  # type: ignore[no-redef]
                       FilePleine, ObjetADonner)
    from config_locale import ConfigLocale, StockageConfig  # type: ignore[no-redef]
    from gdb import (AccesRefuse, ArretNonConfirme, Deconnecte,  # type: ignore[no-redef]
                     DelaiDepasse, ErreurGdb, PontGdb)

DOSSIER_DONNEES = Path(__file__).resolve().parents[1] / "apworld" / "yokaiwatch2" / "donnees"
FORMAT_SLOT_DATA = 23           # format de slot_data de l'APWorld compris par ce client (2 : boss, 3 : quêtes, 4 : rangs,
#                                 5 : Tablo-blabla, 6 : requêtes et services, 7 : rang D verrouillé, mode k = 19,
#                                 8 : chapitres terminés, liste `avant_chapitre_10`, 9 : `rando_yokai`, 10 : `rando_boss`,
#                                 11 : `amis` et `criminels`,
#                                 12 : `death_link`,
#                                 13 : objets-clés de quête, emplacements sans bit (SCRIPT_BIT_AUCUN) détectés par `boss`,
#                                 14 : `fonctions_exigees`, 15 : `boutiques`, 16 : `bingo_kai_infini`,
#                                 17 : boutiques sans hachages, lus dans la ROM du joueur,
#                                 18 : `objets_evenement`, pour le tracker seulement,
#                                 19 : modes « par rencontre » de `rando_yokai`, 20 : rang de montre réel, mode k = 20,
#                                 21 : vélo réel, mode k = 21, 22 : réservé à ap/boss-adaptes (sauté),
#                                 23 : version du mélange des Yo-kai, `rando_yokai.mode` = « <mode>#2 » ; puis
#                                      « <mode>#3 » (lieu normal garanti, §21) et « <mode>#4 » (espèces
#                                      invitées, §22), sans changement de format)
# Fréquence de lecture (archipelago_boite.md §23) : chaque paquet GDB est traité par l'émulateur entre deux tranches
# d'exécution et chaque arrêt fige le jeu. Tour de base : UN paquet (l'en-tête de la boîte, 0x100 octets) ; tout le reste
# est lu sur évènement publié dans l'en-tête (journal, spots, passage sur le terrain, chapitre / pas, progression,
# sauvegarde, dons reçus du serveur), plus un filet de sécurité rare ; aucun arrêt sauf
# pour écrire, écritures d'un tour groupées dans un seul arrêt. Option `lecture` de config.json.
REGIMES_LECTURE = {
    "economique": {"periode": 1.0, "filet": 60.0},      # défaut
    "normale": {"periode": 0.5, "filet": 15.0},
}
LECTURE_DEFAUT = "economique"
PERIODE_MEDAILLIUM = 60.0       # s : filet de relecture du Médaillium (tracker) ; sinon sur changement de terrain / progression
TOURS_TRACKER_MIN = 10          # tours : relecture du Médaillium au plus une fois par 10 tours sur simple changement de terrain
TOURS_ATTENTE = 2               # tours : relecture de l'en-tête du mélange pendant le retrait d'un ancien mélange
TOURS_ACQUITTEMENT = 30         # tours : `journal_lu` écrit au plus tard (sinon avec la prochaine écriture)
FACTEUR_LECTURES_ARRETEES = 3   # stub qui ne sert pas les lectures jeu en marche (chaque lecture arrête le jeu) : tours ×3
PERIODE_BILAN = 300.0           # s : bilan de la charge GDB dans le journal du client
PERIODE_CHAT = 0.25            # s : surveillance de chat_commandes.json (messages saisis dans le lanceur ; fichier local)
PERIODE_CONFIG = 1.0            # s : surveillance de config.json (saisie du lanceur ; fichier local, aucun paquet GDB)
ESSAIS_RELECTURE = 3            # relecture des bits écartée (partie ou Q changés pendant la lecture) : réessais immédiats
ATTENTE_RETRAIT_RANDO = 120.0   # s : attente maximale du retrait d'un ancien mélange avant d'écrire le nouveau
NOTIF_MAX_CAR = 28              # bandeau mono-ligne (~29 caractères larges visibles, E9C)
JOUEUR_MAX_CAR = 10
RESUME_AU_DELA = 3              # plus de dons que ça dans un même relevé : un résumé au lieu du détail
TYPES_DON = {"objet": bp.DON_OBJET, "argent": bp.DON_ARGENT, "yokai": bp.DON_YOKAI,
             "aucun": 0}   # objet AP sans objet du jeu (Rang de montre) : déposé en type 0, ignoré par le jeu

MESSAGES = {                       # message court de l'état (≤ 20 caractères : écran Archipelago, lecture seule)
    "non_configure": "Non configuré",
    "connexion": "Connexion...",
    "connecte": "Connecté",
    "deconnecte": "Reconnexion...",
    "injoignable": "Serveur injoignable",
    "non_liee": "Sauvegarde non liée",
    "autre": "Autre partie AP",
    "jeu_ancien": "Jeu à mettre à jour",
    "liaison": "Liaison...",
    "verrous_incompatibles": "Verrous manquants",
}
NOTIF_SAUVEGARDE = {               # notification(s) du bandeau, une fois par sauvegarde chargée (≤ 28 caractères)
    # une partie Archipelago = une sauvegarde neuve (2026-09-28, option (b)) : le dire au joueur
    "non_liee": ("Sauvegarde non liée à AP", "Lancez une nouvelle partie"),
    "autre": "Autre partie AP : bloquée",
    "jeu_ancien": "Jeu à mettre à jour (AP)",
    "verrous_incompatibles": "Verrous incompatibles (AP)",
}
VICTOIRE = bp.PROGRESSION_VICTOIRE | bp.PROGRESSION_APRES_JEU
# Bouclage du chapitre 10 (docs/systemes/archipelago_couverture.md §2.3) : de 10-10 à la fin du chapitre 10, la ville
# est fermée. Dernière phase de promenade libre avant : 9-80 (90080, jusqu'à l'entrée dans les Plaines Plinpot t200d00 ;
# ensuite boss, scènes et passage automatique à 10-10 [C, phase_set_c09 / c09_trigger n° 11-13]). Dès 9-80 (et donc à
# l'entrée du chapitre 10 pour une sauvegarde liée plus tard), s'il reste des checks hors du chapitre 10 (slot_data
# `avant_chapitre_10`), bandeau d'avertissement, une fois par sauvegarde liée (drapeau `alerte_ch10` de l'instantané
# de liaison). Textes saisis par nous (pas du jeu), une ligne de bandeau chacun (≤ NOTIF_MAX_CAR) ; {n} = nombre de
# checks restants.
SEUIL_ALERTE_CH10 = (9, 80)      # (chapitre, pas de scénario) : phase 9-80
ALERTE_CHAPITRE_10 = {
    "fr": ("Ville bouclée au chap. 10", "{n} checks à faire avant", "ou après la victoire"),
    "en": ("Town locks down in ch. 10", "{n} checks to do before", "or after the victory"),
}
FICHIER_LIAISONS = "liaisons.json"
FICHIER_INVITES = "invites.json"    # invités de l'Auberge des voyageurs : état pour le tracker de Yo-kai du lanceur
FORMAT_INVITES = 1
ERREURS_REFUS = [  # (erreur Archipelago, code §5.2, message court)
    ("InvalidSlot", v3.ERR_SLOT, "Slot inconnu"),
    ("InvalidPassword", v3.ERR_MDP, "Mot de passe refusé"),
    ("IncompatibleVersion", v3.ERR_VERSION, "Version incompatible"),
    ("InvalidGame", v3.ERR_JEU, "Mauvais jeu"),
]


# ================================================================================================ textes
def _car(texte: str, n: int) -> str:
    return texte if len(texte) <= n else texte[:max(0, n - 3)].rstrip() + "..."


def texte_court(principal: str, suffixe: str = "", max_car: int = NOTIF_MAX_CAR,
                max_largeur: int = bp.NOTIF_LARGEUR) -> str:
    """« principal + suffixe » en une ligne : au plus `max_car` caractères et `max_largeur` demi-unités (règle
    du bandeau, boite_protocole.largeur) ; c'est `principal` qui est raccourci (« ... »), le suffixe reste."""
    principal = " ".join(principal.split())
    suffixe = " ".join(suffixe.split()) if suffixe.strip() else ""
    if suffixe:
        suffixe = " " + suffixe
    n = len(principal)
    while n > 0:
        t = (principal if n == len(principal) else principal[:max(0, n - 3)].rstrip() + "...") + suffixe
        if len(t) <= max_car and bp.largeur(t) <= max_largeur:
            return t
        n -= 1
    return _car(suffixe.strip(), max_car)


def texte_recu(objet: str, joueur: str | None, quantite: int = 1) -> str:
    q = f" x{quantite}" if quantite > 1 else ""
    if joueur:
        return texte_court(f"Reçu : {objet}{q}", f"({_car(joueur, JOUEUR_MAX_CAR)})")
    return texte_court(f"Reçu : {objet}{q}")


def texte_envoye(objet: str, joueur: str) -> str:
    return texte_court(f"Envoyé : {objet}", f"({_car(joueur, JOUEUR_MAX_CAR)})")


def nom_vitrine(objet: str, joueur: str | None) -> str:
    """Nom affiché par un coffre qui contient l'objet d'un autre monde (décision 3 de l'humain)."""
    return f"{objet} (pour {joueur})" if joueur else objet


def ident_partie_par_defaut(graine: str, team: int, slot: int) -> int:
    """Identifiant de partie si slot_data n'en a pas : même formule que l'APWorld (`slot_data.ident_partie` :
    CRC-32 de « graine:slot », non nul). L'équipe n'y entre pas (comme dans l'APWorld)."""
    return zlib.crc32(f"{graine}:{slot}".encode("utf-8")) & 0xFFFFFFFF or 1


def _entier(v: Any) -> int:
    return int(v, 0) if isinstance(v, str) else int(v)


# ================================================================================================ catalogue
# Verrous dont le code a été RETIRÉ du jeu : jamais exigés du build ni écrits dans `actifs`, même si une graine plus
# ancienne les déclare `code_jeu: True`. Pile ou passe (k = 1) : verrou de déclencheur des graines du 2026-09-30 au
# 2026-10-01, retiré (décision de l'humain : la Crank-a-kai du tutoriel n'accepte que la pièce, le jeu bloque de
# lui-même ; archipelago_objets_cles.md §14.9).
VERROUS_SANS_CODE = frozenset({"pile_ou_passe"})


def verrou_code_jeu(v: dict) -> bool:
    """Vrai si ce verrou de `slot_data.verrous_actifs` doit être appliqué par le CODE du jeu (masque de flag,
    commande 0x3CEF, plafond de phase, déclencheur) : objet mélangé (sinon il reste à sa place et le jeu le donne
    lui-même), verrou dont le code existe encore (VERROUS_SANS_CODE : Pile ou passe) et mécanisme autre que « vérifié
    en jeu ». Champ explicite `code_jeu` de l'APWorld s'il est présent."""
    if not v.get("melange", True) or v.get("cle") in VERROUS_SANS_CODE:
        return False
    return bool(v.get("code_jeu", v.get("mecanisme") != "verifie_en_jeu"))


@dataclass
class Contenu:
    """Ce qu'une location montre dans le jeu (slot_data format 1 : {propre, hachage, texte})."""
    propre: bool
    hachage: int
    texte: str | None = None


@dataclass
class Emplacement:
    """Emplacement d'objet-clé (spot) : don de script substitué (J3)."""
    location: int
    bit: int
    hachage_origine: int = 0
    objet_origine: int = 0
    substituer: bool = True


@dataclass
class Recompense:
    """Requête ou service de la graine (slot_data format 6) : location, n° de quête (phase 255 = terminée), service
    (255 transitoire : remis à 0 par le tirage des services, archipelago_quetes.md §2.5)."""
    location: int
    quete: int
    service: bool = False


def _installation_boutiques():
    """Module `archipelago/installation/boutiques.py` (distribué avec le client, comme `installation/rencontres.py`)."""
    racine = Path(__file__).resolve().parents[1]          # archipelago/
    if str(racine) not in sys.path:
        sys.path.insert(0, str(racine))
    from installation import boutiques as ib               # noqa: E402
    return ib


@dataclass
class Boutique:
    """Article de boutique de la graine : location, hachage(s) de l'article (clé du jeu), bit persistant « premier achat
    fait » (octets de flags globaux, boite.h AP_BOUTIQUE_OCTETS). Format 17 : `slot_data` ne donne que le code de la
    boutique et le rang de ses entrées ; `articles` est lu dans la ROM du joueur (`installation/boutiques.py`,
    `boutiques_local.json`), vide tant que ce n'est pas fait. Format 15/16 : `articles` venait de `slot_data`."""
    location: int
    articles: tuple[int, ...]
    bit: int
    boutique: str | None = None
    entrees: tuple[int, ...] = ()
    nb_entrees: int | None = None


@dataclass(frozen=True)
class Invite:
    """Invité de l'Auberge des voyageurs (slot_data `invites`, docs/systemes/archipelago_invites.md §14 et §15) : Yo-kai
    que le jeu fait apparaître à l'Auberge quand le client le DÉCLARE. `declencheur` « requetes » (Pandanoko) : toutes
    les `locations` (les requêtes-checks de la graine) sont cochées côté serveur ; « objet » (les 30 invités à
    invitation) : l'objet Archipelago `objet` (« Invitation : <nom> ») a été reçu. Check « Ami » = `location`, envoyé
    quand le bit « ami » du n° `medaille` est posé (`_verifier_amis`, lecture groupée du Médaillium)."""
    location: int
    medaille: int                     # n° du Médaillium (bit « ami »)
    param: int                        # hachage CHARA_PARAM de l'espèce
    declencheur: str
    locations: frozenset[int]
    objet: int = 0                    # déclencheur « objet » : identifiant AP de l'invitation


@dataclass
class Catalogue:
    """Ce que le client doit savoir de ses objets et locations : objet AP -> don ; location de coffre -> index
    TBox ; spots ; verrous. Chargé depuis les données versionnées de l'APWorld, puis remplacé par `slot_data`
    (format 1 de l'APWorld, `archipelago/apworld/README.md` ; les anciennes clés proposées par C3 restent lues)."""
    objets: dict[int, ObjetADonner] = field(default_factory=dict)
    noms: dict[int, str] = field(default_factory=dict)
    cles: dict[str, int] = field(default_factory=dict)             # clé de l'objet -> identifiant AP
    # objet AP « sans objet du jeu » (don « aucun ») qui a pourtant un objet du jeu FACULTATIF, ajouté au RomFS du
    # joueur par l'installation (invitations, archipelago_invites.md §16) : identifiant AP -> hachage. Décidé ici, par
    # le client, pour toute graine (ancienne ou non : `slot_data` dit « aucun ») ; un jeu sans ces objets ignore le don
    objets_du_jeu: dict[int, int] = field(default_factory=dict)
    coffres: dict[int, int] = field(default_factory=dict)          # location -> index TBox
    hachages_tbox: dict[int, int] = field(default_factory=dict)    # location -> hachage (v2, facultatif)
    spots: dict[int, int] = field(default_factory=dict)            # bit TBox (558..) -> location
    contenus: dict[int, Contenu] = field(default_factory=dict)     # location -> contenu (slot_data)
    emplacements: dict[int, Emplacement] = field(default_factory=dict)   # location -> spot (slot_data)
    verrous: dict[int, int] = field(default_factory=dict)          # k (bit - 558) -> objet AP qui l'ouvre
    boss: dict[int, int] = field(default_factory=dict)             # location -> flag bit global (slot_data)
    quetes: dict[int, int] = field(default_factory=dict)           # location -> n° de quête (boss de quête)
    tablos: dict[int, int] = field(default_factory=dict)           # location -> flag « Yo-kai appelé » (Tablo-blabla)
    amis: dict[int, int] = field(default_factory=dict)             # location -> n° du Médaillium (bit « ami »)
    amis_paires: list[tuple[int, int]] = field(default_factory=list)   # (location, n°) : tous les n° d'une location
    criminels: dict[int, tuple[int, int]] = field(default_factory=dict)  # location -> (n° du criminel, étapes)
    # fonctions du patch exigées par la graine (format 14 : bits 24.. de ApVerrous::compiles, ex. Yo-criminels libres)
    fonctions: set[int] = field(default_factory=set)
    # invités de l'Auberge des voyageurs (slot_data `invites`, format 23 et plus) : vide pour une graine sans invité
    invites: list[Invite] = field(default_factory=list)
    fonctions_etendues: set[int] = field(default_factory=set)   # n° >= 32 de `fonctions_exigees`
    # Yo-kai d'évènement à leur emplacement d'origine (slot_data `evenement_places`) : bit de ApPnj::ev_declares ->
    # identifiant AP de l'objet qui fait apparaître le Yo-kai ; vide pour une graine antérieure (rien n'est écrit)
    evenement_places: dict[int, int] = field(default_factory=dict)
    recompenses: dict[int, Recompense] = field(default_factory=dict)  # location -> requête / service (format 6)
    boutiques: dict[int, Boutique] = field(default_factory=dict)   # location -> article de boutique (format 15)
    quetes_boss: set[int] = field(default_factory=set)             # n° de quête des entrées `quete` de `boss`
    # locations hors du chapitre 10 (slot_data format 8) : bandeau d'avertissement à l'entrée du chapitre 10
    avant_chapitre_10: set[int] = field(default_factory=set)
    # randomizer de Yo-kai (slot_data format 9 ; modes par rencontre : format 19) : {"mode": "par_rang" | "total" |
    # "par_rencontre_rang" | "par_rencontre_total", "graine": 31 bits}, None sinon
    rando_yokai: dict | None = None
    rando_yokai_inconnu: str | None = None  # mode de slot_data que ce client ne sait pas lire (APWorld plus récent)
    # randomizer des boss (slot_data format 10) : {"mode": "meme_classe" | "total", "graine": 31 bits}, None sinon
    rando_boss: dict | None = None
    death_link: bool = False           # option DeathLink du slot (format 12)
    bingo_kai_infini: bool = False     # option « Bingo-kai infini » (format 16) : bit 27 de `actifs` (boîte, §20)
    # (seulement les verrous que le JEU doit appliquer : objet mélangé, mécanisme codé dans le jeu)
    vitrine: int = v3.VITRINE
    politique_reessai: bool = True
    langue: str = "fr"
    ident_partie: int | None = None
    format_slot_data: int = 0

    @classmethod
    def charger(cls, dossier: Path | None = None) -> "Catalogue":
        d = Path(dossier) if dossier else DOSSIER_DONNEES
        c = cls()
        try:
            objets = json.loads((d / "objets.json").read_text(encoding="utf-8"))["objets"]
            coffres = json.loads((d / "coffres.json").read_text(encoding="utf-8"))["coffres"]
            spots = json.loads((d / "emplacements_objets_cles.json").read_text(encoding="utf-8"))["emplacements"]
        except (OSError, ValueError, KeyError) as e:
            logging.getLogger("ykw2ap.synchro").warning("Données de l'APWorld illisibles (%s) : catalogue vide", e)
            return c
        for o in objets:
            t = TYPES_DON.get(o.get("don", "objet"), bp.DON_OBJET)
            q = int(o.get("montant", 1)) if t == bp.DON_ARGENT else int(o.get("quantite", 1))
            c.objets[int(o["id_ap"])] = ObjetADonner(t, _entier(o.get("hachage", 0)) & 0xFFFFFFFF, q)
            c.noms[int(o["id_ap"])] = o.get("nom_fr", "")
            c.cles[o.get("cle")] = int(o["id_ap"])
            # (`inventaire` faux : invitation sans objet du jeu, ex. Yo-kai d'évènement à leur emplacement d'origine)
            if o.get("famille") == "invitation" and t == 0 and str(o.get("cle", "")).isascii() \
                    and o.get("inventaire", True):
                c.objets_du_jeu[int(o["id_ap"])] = bp.hachage_invitation(o["cle"])
        for x in coffres:
            c.coffres[int(x["id_ap"])] = int(x["index_tbox"])
        for s in spots:
            bit = v3.SPOTS_PAR_DEFAUT.get(s.get("objet"))
            if bit is not None:
                c.spots[bit] = int(s["id_ap"])
        return c

    @staticmethod
    def _don(o: dict) -> ObjetADonner:
        t = TYPES_DON.get(o.get("type", o.get("don", "objet")), bp.DON_OBJET)
        q = _entier(o.get("montant", o.get("quantite", 1)))
        return ObjetADonner(t, _entier(o.get("hachage", 0)) & 0xFFFFFFFF, q)

    def appliquer_slot_data(self, sd: dict) -> None:
        """slot_data format 1 (APWorld) : ident_partie, langue_notifications, politique_reessai
        ("reessayer"/"ignorer"), verrous_actifs [{objet, cle, hachage, ...}], hachage_vitrine,
        coffres [{index_tbox, location, propre, hachage, texte}], emplacements [{location, objet_origine,
        hachage_origine, bit_tbox, substituer, propre, hachage, texte}], dons {id: {type, hachage, quantite |
        montant}}. Lus aussi (proposition C3) : coffres en identifiants seuls, spots_objets_cles, objets,
        quantites, vitrine, politique_reessai booléen."""
        if not isinstance(sd, dict):
            return
        self.format_slot_data = int(sd.get("format", 0) or 0)
        if sd.get("ident_partie"):
            self.ident_partie = _entier(sd["ident_partie"]) & 0xFFFFFFFF or None
        if isinstance(sd.get("coffres"), list):
            gardes: dict[int, int] = {}
            for x in sd["coffres"]:
                if isinstance(x, dict):
                    loc = _entier(x["location"])
                    idx = _entier(x.get("index_tbox", self.coffres.get(loc, -1)))
                    if x.get("hachage_tbox"):
                        self.hachages_tbox[loc] = _entier(x["hachage_tbox"]) & 0xFFFFFFFF
                    if "hachage" in x:
                        self.contenus[loc] = Contenu(bool(x.get("propre")), _entier(x["hachage"]) & 0xFFFFFFFF,
                                                     x.get("texte"))
                else:
                    loc = _entier(x)
                    idx = self.coffres.get(loc, -1)
                if 0 <= idx < bp.TBOX_NOMBRE and idx not in v3.BITS_RESERVES:
                    gardes[loc] = idx
            self.coffres = gardes
        if isinstance(sd.get("emplacements"), list):
            self.spots, self.emplacements = {}, {}
            for x in sd["emplacements"]:
                loc, bit = _entier(x["location"]), _entier(x["bit_tbox"])
                if bit in v3.BITS_RESERVES:
                    self.spots[bit] = loc
                elif bit != bp.SCRIPT_BIT_AUCUN:
                    continue
                # format 13 : objet-clé de quête sans bit (SCRIPT_BIT_AUCUN) : substitution du don seulement, le check
                # est détecté par son entrée de `boss` (flag bit global ou quête à 255)
                self.emplacements[loc] = Emplacement(loc, bit, _entier(x.get("hachage_origine", 0)) & 0xFFFFFFFF,
                                                     _entier(x.get("objet_origine", 0)), bool(x.get("substituer", True)))
                if "hachage" in x:
                    self.contenus[loc] = Contenu(bool(x.get("propre")), _entier(x["hachage"]) & 0xFFFFFFFF,
                                                 x.get("texte"))
        if isinstance(sd.get("boss"), list):
            # boss d'histoire (format 2) : check = flag bit global posé à la victoire ; boss de quête (format 3) :
            # check = phase de la quête à 255 (terminée) ; seulement ceux de la graine
            self.boss, self.quetes, self.quetes_boss = {}, {}, set()
            for x in sd["boss"]:
                if not isinstance(x, dict) or "location" not in x:
                    continue
                if "flag" in x:
                    f = _entier(x["flag"])
                    if 0 <= f <= bp.FLAG_GLOBAL_MAX:
                        self.boss[_entier(x["location"])] = f
                elif "quete" in x:
                    n = _entier(x["quete"])
                    if 0 <= n < bp.NB_QUETES:
                        self.quetes[_entier(x["location"])] = n
                        self.quetes_boss.add(n)
                elif "octet" in x and "seuil" in x:
                    # boss détecté par un octet global qui ne décroît jamais (Taprice : progression du Tunnel sans
                    # fin >= 6, archipelago_boss.md §11) : pseudo-flag rangé avec les flags de boss
                    o, s = _entier(x["octet"]), _entier(x["seuil"])
                    if bp.boss_octet_valide(o, s):
                        self.boss[_entier(x["location"])] = bp.boss_octet_pseudo(o, s)
        if isinstance(sd.get("tablos"), list):
            # Tablo-blabla (format 5) : check = flag bit global « Yo-kai appelé » (archipelago_tablos.md §9)
            self.tablos = {}
            for x in sd["tablos"]:
                if isinstance(x, dict) and "location" in x and "flag" in x:
                    f = _entier(x["flag"])
                    if 0 <= f <= bp.FLAG_GLOBAL_MAX:
                        self.tablos[_entier(x["location"])] = f
        if isinstance(sd.get("amis"), list):
            # amis (format 11) : check = bit « ami » du Médaillium (P+0x44C | P+0x604), n° du Médaillium 1..511
            # une location peut avoir plusieurs n° (Ultramax N / K : l'un OU l'autre) : `amis` garde le premier,
            # `amis_paires` les a tous ; seules les locations de CETTE liste sont envoyées (graine plus ancienne : ses
            # 196 amis seulement)
            self.amis, self.amis_paires = {}, []
            for x in sd["amis"]:
                if isinstance(x, dict) and "location" in x and "medaille" in x:
                    n = _entier(x["medaille"])
                    if 0 < n < rando.TAILLE_MEDAILLIUM * 8:
                        self.amis.setdefault(_entier(x["location"]), n)
                        self.amis_paires.append((_entier(x["location"]), n))
        if isinstance(sd.get("criminels"), list):
            # Yo-criminels (format 11) : check = octet `wantedNN` (P + 0x2D0 + n) >= nombre d'étapes
            self.criminels = {}
            for x in sd["criminels"]:
                if isinstance(x, dict) and "location" in x and "numero" in x:
                    n, e = _entier(x["numero"]), _entier(x.get("etapes", 1))
                    if 1 <= n <= bp.NB_CRIMINELS and e >= 1:
                        self.criminels[_entier(x["location"])] = (n, e)
        if isinstance(sd.get("fonctions_exigees"), list):
            # fonctions du patch (format 14) : bits de `compiles` que le jeu doit publier (inconnu : exigé quand même,
            # la partie sera refusée par un jeu qui ne le publie pas)
            self.fonctions = {_entier(x) for x in sd["fonctions_exigees"] if 0 <= _entier(x) < 31}
            # fonctions ÉTENDUES (n° >= 32 : bits de ApPnj::fonctions, boite_protocole) ; le n° 22 qui les accompagne
            # (jamais publié : refus d'un client plus ancien) reste dans `fonctions` et est retiré à la vérification
            self.fonctions_etendues = {_entier(x) for x in sd["fonctions_exigees"]
                                       if _entier(x) >= bp.FONCTION_ETENDUE_BASE}
        if isinstance(sd.get("evenement_places"), list):
            self.evenement_places = {}
            for x in sd["evenement_places"]:
                if isinstance(x, dict) and "bit" in x and "objet" in x and 0 <= _entier(x["bit"]) < bp.EV_NOMBRE \
                        and _entier(x["objet"]) > 0:
                    self.evenement_places[_entier(x["bit"])] = _entier(x["objet"])
        if isinstance(sd.get("invites"), list):
            # invités de l'Auberge des voyageurs : le jeu ne montre que ceux que le client déclare ; une graine sans
            # ce champ (toute graine antérieure) n'en a aucun : rien n'est jamais écrit dans la zone des invités
            self.invites = []
            for x in sd["invites"][:bp.CAP_INVITES]:
                if isinstance(x, dict) and all(k in x for k in ("location", "medaille", "param")) \
                        and isinstance(x.get("locations"), list):
                    n = _entier(x["medaille"])
                    if 0 < n < rando.TAILLE_MEDAILLIUM * 8:
                        self.invites.append(Invite(_entier(x["location"]), n, _entier(x["param"]) & 0xFFFFFFFF,
                                                   str(x.get("declencheur", "")),
                                                   frozenset(_entier(l) for l in x["locations"]),
                                                   _entier(x.get("objet", 0))))
        if isinstance(sd.get("quetes"), list):
            # requêtes et services (format 6) : check = phase 255 (même lecture que les boss de quête) ; contenu =
            # ce que l'écran de résultat montre à la place de la récompense (table des récompenses, boîte v5)
            for loc in list(self.recompenses):
                self.quetes.pop(loc, None)
            self.recompenses = {}
            for x in sd["quetes"]:
                if not isinstance(x, dict) or "location" not in x or "quete" not in x:
                    continue
                n, loc = _entier(x["quete"]), _entier(x["location"])
                if not 0 <= n < bp.NB_QUETES:
                    continue
                self.quetes[loc] = n
                self.recompenses[loc] = Recompense(loc, n, bool(x.get("service")))
                if "hachage" in x:
                    self.contenus[loc] = Contenu(bool(x.get("propre")), _entier(x["hachage"]) & 0xFFFFFFFF,
                                                 x.get("texte"))
        if isinstance(sd.get("boutiques"), list):
            # boutiques (format 15) : check = bit persistant « premier achat fait » (ou évènement ACHAT) ; contenu =
            # ce que la boutique montre à la place de l'article jusqu'au premier achat (table des boutiques, jeu v9)
            self.boutiques = {}
            for x in sd["boutiques"]:
                if not isinstance(x, dict) or "location" not in x or "bit" not in x:
                    continue
                loc, bit = _entier(x["location"]), _entier(x["bit"])
                if not 0 <= bit < bp.BOUTIQUE_BITS:
                    continue
                # format 17 : code de la boutique + rangs des entrées (hachage lu dans la ROM du joueur) ; format 15/16
                # (graine plus ancienne) : hachages donnés par slot_data, encore acceptés
                code, ents = x.get("boutique"), x.get("entrees")
                if isinstance(code, str) and isinstance(ents, list) and ents:
                    nb = x.get("nb_entrees")
                    self.boutiques[loc] = Boutique(loc, (), bit, code, tuple(_entier(e) for e in ents),
                                                   _entier(nb) if nb is not None else None)
                else:
                    arts = tuple(_entier(a) & 0xFFFFFFFF for a in (x.get("articles") or []) if _entier(a))
                    if not arts:
                        continue
                    self.boutiques[loc] = Boutique(loc, arts, bit)
                if "hachage" in x:
                    self.contenus[loc] = Contenu(bool(x.get("propre")), _entier(x["hachage"]) & 0xFFFFFFFF,
                                                 x.get("texte"))
        sp = sd.get("spots_objets_cles")
        if isinstance(sp, dict):
            self.spots = {_entier(k): _entier(v) for k, v in sp.items()}
        elif isinstance(sp, list):
            self.spots = {_entier(x["bit"]): _entier(x["location"]) for x in sp if isinstance(x, dict)}
        for cle_dons in ("dons", "objets"):
            for k, o in (sd.get(cle_dons) or {}).items():
                if isinstance(o, dict):
                    self.objets[_entier(k)] = self._don(o)
        for k, q in (sd.get("quantites") or {}).items():
            k = _entier(k)
            if k in self.objets:
                o = self.objets[k]
                self.objets[k] = ObjetADonner(o.type, o.hash, _entier(q))
        if isinstance(sd.get("verrous_actifs"), list):
            self.verrous = {}
            for v in sd["verrous_actifs"]:
                if not isinstance(v, dict) or not verrou_code_jeu(v):
                    continue
                objet = _entier(v.get("objet", self.cles.get(v.get("cle"), 0)))
                if isinstance(v.get("k"), int) and 0 <= v["k"] < bp.CAP_VERROUS:
                    k = v["k"]                           # verrou sans spot (rangs de montre : k = 18, progressif)
                else:
                    bit = v3.SPOTS_PAR_DEFAUT.get(v.get("cle"))
                    k = None if bit is None else bit - bp.TBOX_SPOT_PREMIER
                if k is not None and objet:
                    self.verrous[k] = objet
        for cle_v in ("hachage_vitrine", "vitrine"):
            if sd.get(cle_v):
                self.vitrine = _entier(sd[cle_v]) & 0xFFFFFFFF
        if "politique_reessai" in sd:
            p = sd["politique_reessai"]
            self.politique_reessai = p != "ignorer" if isinstance(p, str) else bool(p)
        if sd.get("langue_notifications") in ("fr", "en"):
            self.langue = sd["langue_notifications"]
        if isinstance(sd.get("avant_chapitre_10"), list):
            self.avant_chapitre_10 = {_entier(x) for x in sd["avant_chapitre_10"]}
        ry = sd.get("rando_yokai")
        # la VERSION du mélange vient de la graine (« <mode>#<n> », sans suffixe = 1 : graines d'avant le format 23,
        # même calcul qu'avant, archipelago_rando_yokai.md §20) ; version inconnue : gardée telle quelle, refusée au
        # calcul (jamais un autre algorithme à la place)
        mv = rando.mode_et_version(ry.get("mode")) if isinstance(ry, dict) else None
        if isinstance(ry, dict):
            self.rando_yokai_inconnu = None
        if mv is not None and mv[0] != "aucun":
            self.rando_yokai = {"mode": mv[0], "graine": _entier(ry.get("graine", 0)) & 0x7FFFFFFF, "melange": mv[1]}
        elif isinstance(ry, dict):
            self.rando_yokai = None
            if ry.get("mode") != "aucun":
                self.rando_yokai_inconnu = str(ry.get("mode"))
        rb = sd.get("rando_boss")
        if isinstance(rb, dict) and rb.get("mode") in rboss.MODES and rb.get("mode") != "aucun":
            self.rando_boss = {"mode": rb["mode"], "graine": _entier(rb.get("graine", 0)) & 0x7FFFFFFF}
        elif isinstance(rb, dict):
            self.rando_boss = None
        if "death_link" in sd:
            self.death_link = bool(_entier(sd["death_link"]))
        if "bingo_kai_infini" in sd:
            self.bingo_kai_infini = bool(_entier(sd["bingo_kai_infini"]))

    def locations_anim(self) -> set[int]:
        """Locations dont le check n'a AUCUN affichage dans le jeu (fenêtre « objet obtenu », toujours active, sans option :
        décision de l'humain du 2026-09-30) : boss d'histoire et de quête, fins de chapitre, Montée de rang, Vélo (entrées
        de `boss`), Tablo-blabla, et (décision de l'humain, 2026-10-01 puis précisée le 2026-10-02) les SERVICES
        (`recompenses` à `service` vrai), les amis et (décision de l'humain du 2026-10-07) les Yo-criminels (la scène
        d'arrestation ne montre pas l'objet AP). Pas les requêtes (écran de résultat). Jamais un coffre, un spot d'objet-clé (don de script substitué : fenêtre du jeu) ni un article de
        boutique (montré dans la boutique)."""
        requetes = {loc for loc, r in self.recompenses.items() if not r.service}     # aussi dans `quetes` (phase 255)
        s = set(self.boss) | set(self.quetes) | set(self.tablos) | set(self.amis)   # `quetes` contient les services
        s |= {inv.location for inv in self.invites}                                 # invités de l'Auberge : amis
        s |= set(self.criminels)                                                    # Yo-criminels arrêtés
        exclus = set(self.coffres) | set(self.emplacements) | set(self.boutiques) | requetes
        exclus |= set(self.spots.values())
        return s - exclus

    def don(self, item: int) -> ObjetADonner:
        """Don correspondant à un objet AP ; objet inconnu : type 0 (le jeu l'ignore et avance son compteur,
        code TYPE_INCONNU), pour ne pas bloquer la file."""
        return self.objets.get(item, ObjetADonner(0, 0, 0))

    @property
    def services(self) -> set[int]:
        """N° de quête des services de la graine (phase 255 transitoire)."""
        return {r.quete for r in self.recompenses.values() if r.service}

    @property
    def index_vers_location(self) -> dict[int, int]:
        return {i: loc for loc, i in self.coffres.items()}


# ================================================================================================ liaison (v4)
def raison_non_neuve(h, ouverts: set[int], indices_ap: Iterable[int],
                     boss_vaincus: Iterable[int] = (), quetes_finies: Iterable[int] = (),
                     tablos_appeles: Iterable[int] = ()) -> str | None:
    """None si la sauvegarde chargée est une PARTIE NEUVE (liaison automatique permise), sinon la raison.

    Critères (tous exigés ; justification dans archipelago_boite.md §11.3) :
    - aucun identifiant (P+0x3BC == 0) : jamais liée à une partie AP ;
    - compteur de dons (P+0x3B8) à 0 : n'a jamais reçu d'objet d'Archipelago ;
    - chapitre connu (structure de scénario présente) et chapitre 0, ou chapitre 1 avec un pas de scénario
      < 100 (phase d'index 16 de `phase_set_c01` : don du Filet, premier objet-clé mélangé) ;
    - ni « partie terminée » ni après-jeu ;
    - aucun bit de spot d'objet-clé (TBox 558..575) ;
    - aucun coffre d'Archipelago (index TBox de la graine) déjà ouvert ;
    - aucun boss de la graine déjà vaincu (redondant avec le chapitre : le premier boss est au chapitre 3), ni
      aucune quête (boss de quête, requête, service) de la graine déjà terminée (redondant : la première apparaît au
      chapitre 2), ni aucun Tablo-blabla de la graine déjà appelé (redondant : aucun panneau avant le chapitre 2).
    Le jeu v4 revérifie identifiant, compteur, chapitre et spots avant une clé automatique (apLiaison)."""
    if h.ident_sauvegarde:
        return "identifiant déjà présent"
    if h.compteur:
        return f"{h.compteur} don(s) déjà reçu(s)"
    if not h.progression & bp.PROGRESSION_CHAPITRE:
        return "chapitre inconnu"
    if h.progression & VICTOIRE:
        return "partie terminée"
    if h.chapitre > 1 or (h.chapitre == 1 and h.pas_scenario >= bp.PAS_NEUVE):
        return f"chapitre {h.chapitre}, pas {h.pas_scenario}"
    if h.spots:
        return "objet-clé déjà obtenu"
    deja = ouverts & set(indices_ap)
    if deja:
        return f"{len(deja)} coffre(s) AP déjà ouvert(s)"
    boss = set(boss_vaincus)
    if boss:
        return f"{len(boss)} boss déjà vaincu(s)"
    quetes = set(quetes_finies)
    if quetes:
        return f"{len(quetes)} quête(s) déjà terminée(s)"
    tablos = set(tablos_appeles)
    if tablos:
        return f"{len(tablos)} Tablo-blabla déjà appelé(s)"
    return None


@dataclass
class Liaison:
    """Instantané pris à la liaison d'une sauvegarde : bits de victoire déjà présents (la victoire ne compte que si
    elle apparaît après), et ensembles EXCLUS (jamais envoyés comme checks) : toujours vides depuis G1-2 (liaison
    automatique : partie neuve, rien de fait ; liaison MANUELLE : les checks déjà faits sont envoyés), sauf pour une
    sauvegarde liée par un client v3 (clé 0, « premiere_vue ») ; un instantané manuel antérieur qui excluait des
    checks est vidé à son chargement (`Synchro._liaison_manuelle`).
    Historique des champs : `boss` (`quetes`) None : instantané pris par un client sans boss (sans boss de
    quête), complété à la première vue (`Synchro._charger_liaison`). `secours` : bits de spot dont le don avait
    déjà été fait SANS table à la liaison (détection de secours, `bp.SPOTS_SECOURS`), exclus comme `exclus` ; None :
    instantané d'un client sans détection de secours, complété de la même façon. `tablos` : flags « Yo-kai appelé »
    des Tablo-blabla déjà posés à la liaison ; None : instantané d'un client sans Tablo-blabla, complété de même."""
    exclus: set[int] = field(default_factory=set)
    progression: int = 0
    manuelle: bool = False
    origine: str = "auto"          # auto (partie neuve), manuelle (écran, X), premiere_vue (liaison sans instantané)
    boss: set[int] | None = None   # flags bit globaux de boss déjà posés à la liaison
    quetes: set[int] | None = None  # quêtes de boss déjà terminées (phase 255) à la liaison
    secours: set[int] | None = None  # bits de spot vus par la seule détection de secours à la liaison
    tablos: set[int] | None = None   # flags « Yo-kai appelé » des Tablo-blabla déjà posés à la liaison
    # n° de quête lus pour l'instantané `quetes` (None : instantané d'un client sans requêtes, qui ne lisait que les
    # quêtes de boss) ; une quête hors de cet ensemble est complétée à la première vue (`Synchro._couvrir_quetes`)
    quetes_couvertes: set[int] | None = None
    # bandeau du chapitre 10 déjà montré (ou devenu sans objet : victoire, aucun check restant) pour cette sauvegarde
    alerte_ch10: bool = False
    # n° du Médaillium déjà amis / n° des Yo-criminels déjà arrêtés à la liaison (exclus) ; None : instantané d'un client
    # sans amis / Yo-criminels, complété à la première lecture (`Synchro._completer_instantane`) : vide pour une liaison
    # automatique (partie neuve) ou manuelle (G1-2), ce qui est déjà fait à la première vue sinon
    amis: set[int] | None = None
    criminels: set[int] | None = None
    # bits de boutique (premier achat fait) déjà posés à la liaison (exclus) ; None : instantané d'un client sans
    # boutiques, complété à la première lecture comme `amis` / `criminels`
    boutiques: set[int] | None = None
    # n° du Médaillium des invités de l'Auberge dont l'annonce a déjà été montrée pour cette sauvegarde (évènement
    # INVITE du journal) : jamais remontrée, même après un relancement du jeu
    invites_annonces: set[int] = field(default_factory=set)
    # chambre de l'Auberge (1..9 = 101..109) que le JEU a attribuée à chaque invité (n° du Médaillium) dans cette
    # sauvegarde (évènement INVITE_CHAMBRE du journal) : réécrite dans la liste, l'invité la garde jusqu'à l'amitié,
    # d'un lancement à l'autre (archipelago_invites.md §18)
    invites_chambres: dict[int, int] = field(default_factory=dict)

    def exclus_tous(self) -> set[int]:
        return self.exclus | (self.secours or set())


class RegistreLiaisons:
    """Instantanés des liaisons, par (identifiant de partie, clé de liaison P+0x3B6), dans `liaisons.json` du
    dossier du client (la sauvegarde n'a pas de place pour 576 bits : seuls 2 octets libres, P+0x3B6, gardent la
    clé, bit 15 = liaison manuelle)."""

    def __init__(self, dossier: Path, journal: logging.Logger | None = None):
        self.fichier = Path(dossier) / FICHIER_LIAISONS
        self.log = journal or logging.getLogger("ykw2ap.synchro")

    @staticmethod
    def cle(ident: int, cle_liaison: int) -> str:
        return f"{ident & 0xFFFFFFFF:08x}:{cle_liaison & 0xFFFF:04x}"

    def _tout(self) -> dict:
        try:
            d = json.loads(self.fichier.read_text(encoding="utf-8"))
            return d if isinstance(d, dict) else {}
        except FileNotFoundError:
            return {}
        except (OSError, ValueError) as e:
            self.log.warning("Liaisons illisibles (%s) : ignorées", e)
            return {}

    def lire(self, ident: int, cle_liaison: int) -> Liaison | None:
        e = self._tout().get(self.cle(ident, cle_liaison))
        if not isinstance(e, dict):
            return None
        boss, quetes, secours, tablos = e.get("boss"), e.get("quetes"), e.get("secours"), e.get("tablos")
        couvertes = e.get("quetes_couvertes")
        amis, criminels, boutiques = e.get("amis"), e.get("criminels"), e.get("boutiques")
        return Liaison({int(x) for x in e.get("exclus", [])}, int(e.get("progression", 0)),
                       bool(e.get("manuelle")), str(e.get("origine", "auto")),
                       None if boss is None else {int(x) for x in boss},
                       None if quetes is None else {int(x) for x in quetes},
                       None if secours is None else {int(x) for x in secours},
                       None if tablos is None else {int(x) for x in tablos},
                       None if couvertes is None else {int(x) for x in couvertes},
                       bool(e.get("alerte_ch10")),
                       None if amis is None else {int(x) for x in amis},
                       None if criminels is None else {int(x) for x in criminels},
                       None if boutiques is None else {int(x) for x in boutiques},
                       {int(x) for x in e.get("invites_annonces", [])},
                       {int(k): int(v) for k, v in (e.get("invites_chambres") or {}).items()
                        if str(k).isdigit() and isinstance(v, int) and 0 < v < bp.INVITES_PIECES})

    def ecrire(self, ident: int, cle_liaison: int, l: Liaison) -> None:
        d = self._tout()
        e = {"exclus": sorted(l.exclus), "progression": l.progression, "manuelle": l.manuelle,
             "origine": l.origine, "date": time.strftime("%Y-%m-%d %H:%M:%S")}
        if l.boss is not None:
            e["boss"] = sorted(l.boss)
        if l.quetes is not None:
            e["quetes"] = sorted(l.quetes)
        if l.secours is not None:
            e["secours"] = sorted(l.secours)
        if l.tablos is not None:
            e["tablos"] = sorted(l.tablos)
        if l.quetes_couvertes is not None:
            e["quetes_couvertes"] = sorted(l.quetes_couvertes)
        if l.alerte_ch10:
            e["alerte_ch10"] = True
        if l.amis is not None:
            e["amis"] = sorted(l.amis)
        if l.criminels is not None:
            e["criminels"] = sorted(l.criminels)
        if l.boutiques is not None:
            e["boutiques"] = sorted(l.boutiques)
        if l.invites_annonces:
            e["invites_annonces"] = sorted(l.invites_annonces)
        if l.invites_chambres:
            e["invites_chambres"] = {str(k): v for k, v in sorted(l.invites_chambres.items())}
        d[self.cle(ident, cle_liaison)] = e
        try:
            self.fichier.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.fichier.with_suffix(".tmp")
            tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(self.fichier)
        except OSError as e:
            self.log.warning("Liaison non enregistrée : %s", e)


# ================================================================================================ synchro
@dataclass
class Statistiques:
    cycles: int = 0
    instances: int = 0
    depots: int = 0
    checks_envoyes: int = 0
    notifications: int = 0
    tables_ecrites: int = 0
    publications: int = 0
    erreurs_gdb: int = 0
    liaisons: int = 0
    cycles_suivi: int = 0                  # tours sans le jeu (suivi seul : aucun paquet GDB)


class Synchro:
    """Boucle du client invisible. `executer()` ne rend la main qu'à l'arrêt (`arreter()`)."""

    def __init__(self, pont: PontGdb, stockage: StockageConfig, config: ConfigLocale | None = None, *,
                 catalogue: Catalogue | None = None, disposition: v3.DispositionV3 | None = None,
                 periode: float | None = None, periode_filet: float | None = None,
                 periode_resync: float | None = None, echelle: float = 1.0,
                 options_reseau: dict | None = None,
                 fabrique_client: Callable[..., ClientAP] | None = None, journal: logging.Logger | None = None,
                 attacher_jeu: bool = True):
        self.pont = pont
        # suivi seul (lanceur, sans Azahar) : réseau seulement, AUCUN paquet GDB (ni connexion au stub) tant que
        # `attacher_jeu()` n'a pas été appelé ; `detacher_jeu()` y revient (Azahar fermé)
        self.jeu_attache = attacher_jeu
        self.boite = Boite(pont)
        self.zone = v3.ZoneConnexion(self.boite, disposition)
        self.stockage = stockage
        self.config = config or stockage.charger()
        self.catalogue_base = catalogue or Catalogue.charger()
        self.catalogue = self._copie_catalogue()
        # fréquence de lecture : régime de config.json (`lecture`), paramètres explicites prioritaires ; `echelle`
        # multiplie toutes les durées (tests et mesures en temps accéléré, archipelago/tests/charge_gdb.py)
        self.lecture = self.config.lecture if self.config.lecture in REGIMES_LECTURE else LECTURE_DEFAUT
        regime = REGIMES_LECTURE[self.lecture]
        self.echelle = echelle
        self.periode = periode if periode is not None else regime["periode"] * echelle
        filet = periode_filet if periode_filet is not None else periode_resync
        self.periode_filet = filet if filet is not None else regime["filet"] * echelle
        self.options_reseau = dict(options_reseau or {})
        self.fabrique_client = fabrique_client or ClientAP
        self.log = journal or logging.getLogger("ykw2ap.synchro")
        self.liaisons = RegistreLiaisons(stockage.dossier, self.log)
        # lieu du joueur (carte courante, position) recopié de l'en-tête dans lieu.json pour le sous-onglet « Carte »
        # du lanceur : aucun paquet GDB, écritures bornées (lieu_local.py)
        self.lieu = ll.SuiviLieu(stockage.dossier)
        # connexion : saisie du lanceur (config_locale) ; révision de config.json appliquée
        self._rev_locale = self.config.revision_connexion
        self._signature_config = stockage.signature()
        self.periode_config = PERIODE_CONFIG * echelle
        self.raison_non_liee = ""              # sauvegarde non liée : pourquoi ce n'est pas une partie neuve (etat.json)
        self.stats = Statistiques()
        self._arret = asyncio.Event()
        # réseau
        self.reseau: ClientAP | None = None
        self._tache_reseau: asyncio.Task | None = None
        self._taches: set[asyncio.Task] = set()
        self._deja_connecte = False            # avec la configuration courante
        self._refus: list[str] = []
        self._connexion_prete = False          # slot_data appliqué, identifiant connu
        self.ident_partie: int | None = None
        self.objets: list[ObjetReseau] = []
        self._scout: dict[int, ObjetReseau] = {}
        self._scout_fait = False
        self._victoire_envoyee = False
        self._checks_empreinte: str | None = None   # dernier checks.json écrit (aucune écriture s'il n'a pas changé)
        self._indices_empreinte: str | None = None  # dernier indices.json écrit (idem)
        # discussion (onglet « Discussion » du lanceur) : journal des messages et commandes du lanceur
        self.session_chat = secrets.token_hex(8)
        self.journal_chat = ch.JournalMessages(stockage.dossier, self.session_chat)
        self.commandes_chat = ch.SuiviCommandes(stockage.dossier, self.session_chat)
        self.periode_chat = PERIODE_CHAT * echelle
        # jeu
        self._instance = 0
        self._instance_preparee = -1
        self._publie: v3.EtatConnexion | None = None
        self._message_bandeau = False
        self._table_ecrite: tuple | None = None
        self._config_ecrite: tuple | None = None
        self._depot_cle: tuple | None = None
        self._depot_t = 0.0
        self._resync_t = 0.0
        self._resync_demandee = True
        self._victoire_t = 0.0
        self._spots_vus = -1
        self._progression_vue: tuple | None = None   # (chapitre, pas, terrain) : un changement relit les boss
        self._verrous_ecrits: tuple | None = None
        self._verrous_compiles: tuple[int, int | None] | None = None   # (instance, masque publié par le jeu)
        # invités de l'Auberge des voyageurs : bits compilés lus une fois par instance (seulement si la graine a des
        # invités), dernière liste écrite, séquence de la zone, dernier état écrit dans invites.json
        self._invites_compiles: tuple[int, int | None] | None = None
        self._etendues_compilees: tuple[int, int | None] | None = None   # (instance, bits de ApPnj::fonctions)
        self._invites_ecrits: tuple | None = None
        self._invites_seq = 0
        self._invites_fichier: tuple | None = None
        self._evenement_ecrit: tuple | None = None       # (instance, masque, ident) de ApPnj::ev_declares écrit
        self._panique_vue: tuple[int, int] | None = None   # (instance, compte) de la dernière panique du jeu lue (§28)
        self.paniques: list[dict] = []        # paniques du jeu lues depuis le lancement du client (plantage.json)
        self.options_absentes: list[int] = []   # options du joueur choisies mais non compilées (avertissement)
        self._recompenses_etat: tuple[int, str] | None = None   # (instance, état de la substitution des récompenses)
        self._recompenses_montrees: set[int] = set()   # locations dont l'écran de résultat a montré l'objet (évènement)
        self.verrous_manquants: list[int] = []  # verrous exigés par slot_data et absents du jeu (état refusé)
        # v9 : la graine a des checks de boutique mais le jeu ne les a pas (jeu v8 ou antérieur, ou build --define
        # YKW2_AP_SANS_BOUTIQUES) : ces locations seraient impossibles -> même refus que des verrous manquants
        self.boutiques_manquantes = False
        self._boutiques_etat: tuple[int, str] | None = None     # (instance, « actives » / « non_compilees » / « jeu_ancien »)
        # locations de boutique déjà cochées sur le serveur quand la sauvegarde liée a été vue (instantané par sauvegarde :
        # la table n'est pas réécrite à chaque achat ; le jeu pose lui-même le bit et remet l'article d'origine)
        self._boutiques_faites: frozenset[int] | None = None
        self._boutiques_bits: set[int] = set()      # bits de boutique posés, lus par le dernier _lire_bits
        self._boutiques_ecrites: tuple | None = None   # (instance, entrées) de la dernière table des boutiques écrite
        # hachages des articles lus dans la ROM du joueur (format 17, `boutiques_local.json`) : état de la résolution
        # (« pretes », « calcul », « absente », « refusee ») et tâche de génération de la table locale
        self._boutiques_resolution = "pretes"
        self._boutiques_tache: asyncio.Task | None = None
        # indices automatiques des boutiques (évènement BOUTIQUE, archipelago_boutiques.md §10) : (graine, slot, location)
        # dont l'indice a été demandé au serveur (une seule fois par article ; retiré si la demande échoue)
        self._indices_boutiques: set[tuple[str, int, int]] = set()
        # randomizer de Yo-kai (R3)
        self.rando_melange: rando.Melange | None = None
        self.rando_statut = "aucun"            # aucun | calcul | pret | refuse | base_absente
        self._rando_sans_p: int | None = None  # instance du jeu déjà signalée sans le mélange par rencontre (v10)
        self.rando_message = ""
        self._rando_cle: tuple | None = None   # (ident_partie, mode, graine) du mélange calculé
        self._rando_tache: asyncio.Task | None = None
        self._rando_jeu: tuple[int, int | None] | None = None   # (instance, masque publié : None = jeu sans v6)
        self._rando_fichier: tuple | None = None
        self._rando_attente_t = 0.0
        # randomizer des boss (v7)
        self.boss_melange: rboss.MelangeBoss | None = None
        self.boss_statut = "aucun"             # aucun | calcul | pret | refuse | base_absente
        self.boss_message = ""
        self._boss_cle: tuple | None = None    # (ident_partie, mode, graine) du mélange calculé
        self._boss_jeu: tuple[int, int | None] | None = None    # (instance, masque publié : None = jeu sans v7)
        self._boss_fichier: tuple | None = None
        self._boss_attente_t = 0.0
        self._boss_lu_cle: tuple | None = None
        self._boss_lu_t = 0.0
        self._boss_attente = False
        self._boss_valide_lu = 0               # `valide` lu en dernier (0 : rien à retirer dans le jeu)
        self._medaillium_t = 0.0
        self._medaillium: tuple | None = None
        self._progression_suivi: tuple | None = None   # (ident_sauvegarde, progression publiée) de la dernière lecture
        self._progression_fichier: tuple | None = None
        self._base_rafraichie = False                   # base locale d'un format antérieur : régénérée une fois
        # DeathLink (boîte v8, docs/systemes/archipelago_deathlink.md)
        self.deathlink = dl.EtatDeathLink()
        self._tag_deathlink = False            # tag « DeathLink » annoncé au serveur
        # fenêtre « objet obtenu » des checks sans affichage (§27)
        self.anims = ao.EtatAnims()
        self._battement = 0                    # client_images : +1 à chaque publication (aucune écriture pour lui seul)
        self._reveil = asyncio.Event()         # tour immédiat (dons reçus, connexion, arrêt)
        # lectures sur évènement (§23)
        self._journal_lu = 0                   # index de lecture du client (acquittement différé)
        self._acquitter_t = 0.0                # 0 : rien à acquitter ; sinon date de la première lecture non acquittée
        self._rando_lu_cle: tuple | None = None
        self._rando_lu_t = 0.0
        self._rando_attente = False            # écriture du mélange en cours : en-tête relu tous les TOURS_ATTENTE tours
        self._terrain_suivi: int | None = None
        self._adresse_q: int | None = None     # Q et O validés par la dernière relecture (chaînage relu après seulement)
        self._adresse_rang: int | None = None
        self._resync_echecs = 0
        self._bilan_t = 0.0
        self._bilan_stats: dict | None = None
        self._arrets_signales = False
        self._partie_cle: tuple | None = None
        self.sauvegarde = "aucune"             # aucune | attente | liee | liaison | non_liee | autre | jeu_ancien
        self._liaison: Liaison | None = None   # instantané de la sauvegarde liée chargée
        self._secours_seuls: set[int] = set()  # bits de spot du dernier _lire_bits vus par la seule détection de secours
        self._criminels_arretes: set[int] = set()   # n° des Yo-criminels arrêtés, lus par le dernier _lire_bits
        self._demande: tuple | None = None     # (terrain_numero, clé, numéro de demande) en attente
        self._eval_cle: tuple | None = None    # dernier état évalué d'une sauvegarde sans identifiant
        self._notif_sauvegarde: tuple | None = None
        self._echecs_notifies: set[int] = set()
        self.notifications: collections.deque[str] = collections.deque(maxlen=64)
        self.etat_publie: v3.EtatConnexion | None = None
        self.entete: Any = None

    # ------------------------------------------------------------------------------ cycle de vie
    async def executer(self) -> None:
        self.stockage.consommer_transmis()                 # mot de passe transmis par le lanceur : lu, effacé du disque
        if self.config.configuree:
            self._demarrer_reseau()
        self._lancer(self._surveiller_config())
        self._lancer(self._surveiller_chat())
        try:
            while not self._arret.is_set():
                if not self.jeu_attache:
                    self._suivi_sans_jeu()
                    with contextlib.suppress(asyncio.TimeoutError):
                        await asyncio.wait_for(self._reveil.wait(), self.periode)
                    self._reveil.clear()
                    continue
                if not self.pont.connecte:
                    try:
                        await self.pont.connecter(arreter=lambda: self._arret.is_set() or not self.jeu_attache)
                    except Deconnecte:
                        if self._arret.is_set():
                            break
                        continue
                try:
                    await self.cycle()
                except Deconnecte as e:
                    self.log.info("Jeu déconnecté (%s) : attente d'un nouveau lancement", e)
                    self.stats.erreurs_gdb += 1
                    self.lieu.oublier()                    # plus de jeu : plus de lieu pour le lanceur
                except (ArretNonConfirme, DelaiDepasse, AccesRefuse, BoiteAbsente) as e:
                    self.log.debug("Cycle interrompu : %s", e)
                    self.stats.erreurs_gdb += 1
                except ErreurGdb as e:
                    self.log.warning("Erreur GDB : %s", e)
                    self.stats.erreurs_gdb += 1
                with contextlib.suppress(asyncio.TimeoutError):
                    await asyncio.wait_for(self._reveil.wait(), self.periode_effective())
                self._reveil.clear()
        finally:
            self.lieu.oublier()
            if self.pont.connecte and self._acquitter_t:
                with contextlib.suppress(Exception):             # dernier acquittement du journal (au mieux)
                    await self.boite.acquitter_journal(self._journal_lu)
            await self._arreter_reseau()
            for t in list(self._taches):
                t.cancel()

    def arreter(self) -> None:
        self._arret.set()
        self._reveil.set()

    # ------------------------------------------------------------------------------ suivi seul / jeu attaché
    def attacher_jeu(self) -> None:
        """« JOUER » dans le lanceur : le client de suivi attend maintenant le stub GDB d'Azahar (même connexion au
        serveur, même état : rien n'est refait)."""
        if self.jeu_attache:
            return
        self.jeu_attache = True
        self.log.info("Jeu attaché : attente du stub GDB sur %s:%d", self.pont.hote, self.pont.port)
        self.reveiller()

    async def detacher_jeu(self) -> None:
        """Azahar fermé : retour au suivi seul (connexion GDB fermée, état de la partie oublié ; le réseau continue)."""
        if not self.jeu_attache:
            return
        self.jeu_attache = False
        self.reveiller()
        with contextlib.suppress(Exception):
            await self.pont.fermer()
        self._nouvelle_instance()
        self.entete = None
        self.lieu.oublier()
        self.log.info("Jeu détaché : suivi seul (connexion au serveur gardée)")

    def _suivi_sans_jeu(self) -> None:
        """Un tour sans le jeu : seulement ce qui se calcule sans lui (mélanges de la graine pour le tracker). Aucun
        accès GDB, aucun check envoyé (les checks ne viennent que du jeu)."""
        self.stats.cycles_suivi += 1
        if self._connexion_prete and self.reseau is not None:
            self._preparer_rando()
            self._preparer_boss()

    def reveiller(self) -> None:
        """Tour suivant sans attendre la période (dons reçus, connexion au serveur)."""
        self._reveil.set()

    @property
    def periode_resync(self) -> float:
        """Ancien nom de `periode_filet` (relecture complète périodique)."""
        return self.periode_filet

    @periode_resync.setter
    def periode_resync(self, v: float) -> None:
        self.periode_filet = v

    def periode_effective(self) -> float:
        """Période du tour ; ×FACTEUR_LECTURES_ARRETEES si le stub ne sert pas les lectures jeu en marche (chaque lecture
        arrête alors le jeu)."""
        if self.pont.lectures_en_marche is False:
            if not self._arrets_signales:
                self._arrets_signales = True
                self.log.warning("Le stub GDB ne sert pas les lectures jeu en marche : chaque lecture arrête le jeu "
                                 "(tour ralenti à %.1f s)", self.periode * FACTEUR_LECTURES_ARRETEES)
            return self.periode * FACTEUR_LECTURES_ARRETEES
        return self.periode

    def _bilan(self) -> None:
        """Charge GDB dans le journal du client toutes les PERIODE_BILAN s (paquets, octets, arrêts du jeu par minute)."""
        maintenant = time.monotonic()
        st = dict(self.pont.stats)
        if self._bilan_stats is None:
            self._bilan_t, self._bilan_stats = maintenant, st
            return
        duree = maintenant - self._bilan_t
        if duree < PERIODE_BILAN * self.echelle:
            return
        d = {k: st.get(k, 0) - self._bilan_stats.get(k, 0) for k in st}
        m = 60.0 / duree
        self.log.info("Charge GDB (%d s, lecture %s) : %.0f paquets/min, %.0f octets/min, %.1f arrêts/min (gel cumulé "
                      "%.0f ms/min), %d lecture(s) jeu arrêté", duree, self.lecture, d["paquets"] * m, d["octets"] * m,
                      d["arrets"] * m, d["duree_arret"] * m * 1000, d["lectures_arretees"])
        self._bilan_t, self._bilan_stats = maintenant, st

    # ------------------------------------------------------------------------------ réseau
    def _copie_catalogue(self) -> Catalogue:
        return copy.deepcopy(self.catalogue_base)

    def _demarrer_reseau(self) -> None:
        c = self.config
        self._deja_connecte = False
        self._refus = []
        self._connexion_prete = False
        self._scout, self._scout_fait = {}, False
        self._victoire_envoyee = False
        self.objets = []
        self.catalogue = self._copie_catalogue()
        self._table_ecrite = self._config_ecrite = self._depot_cle = None
        self._boutiques_ecrites = None
        opts = {"uuid": c.uuid, "dossier_cache": self.stockage.dossier_cache, **self.options_reseau}
        r = self.fabrique_client(c.serveur, c.slot, c.mot_de_passe, **opts)
        r.sur_connecte = self._sur_connecte
        r.sur_refus = self._sur_refus
        r.sur_objets = self._sur_objets
        r.sur_deconnexion = self._sur_deconnexion
        r.sur_indices = self._sur_indices
        r.sur_paquet = self._sur_paquet
        r.sur_message = self._sur_message
        r.sur_deathlink = self._sur_deathlink
        self.deathlink.option, self._tag_deathlink = False, False
        self.reseau = r
        self._tache_reseau = asyncio.create_task(self._executer_reseau(r))
        self.log.info("Connexion à %s (slot %s)", c.serveur, c.slot)

    async def _executer_reseau(self, r: ClientAP) -> None:
        try:
            await r.executer()
        except RefusConnexion as e:
            self.log.warning("Connexion refusée : %s", e)
        except asyncio.CancelledError:
            raise
        except Exception:                                   # pragma: no cover - filet de sécurité
            self.log.exception("Client Archipelago arrêté sur une erreur")

    async def _arreter_reseau(self) -> None:
        r, t = self.reseau, self._tache_reseau
        self.reseau = self._tache_reseau = None
        if r is not None:
            with contextlib.suppress(Exception):
                await r.arreter()
        if t is not None:
            t.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await t

    async def _sur_connecte(self, paquet: dict) -> None:
        r = self.reseau
        if r is None:
            return
        self._deja_connecte = True
        self._refus = []
        self.catalogue = self._copie_catalogue()
        self.catalogue.appliquer_slot_data(r.slot_data)
        if self.catalogue.format_slot_data > FORMAT_SLOT_DATA:
            self.log.warning("slot_data au format %d (client : %d) : APWorld plus récent que le client",
                             self.catalogue.format_slot_data, FORMAT_SLOT_DATA)
        graine = str(r.room_info.get("seed_name", ""))
        ancien = self.ident_partie
        self.ident_partie = self.catalogue.ident_partie or ident_partie_par_defaut(graine, r.team or 0, r.slot or 0)
        if ancien is not None and ancien != self.ident_partie:
            self.anims.attente.clear()               # fenêtres d'une autre partie AP : jamais écrites
        self._connexion_prete = True
        self._config_ecrite = self._table_ecrite = None
        self._resync_demandee = True
        self._rando_lu_cle = None
        self._boss_lu_cle = None
        self.reveiller()
        # la configuration est déjà dans config.json (écrite par le lanceur) ; l'identifiant du client
        # y est gardé s'il manquait (réécrire toute la configuration écraserait une saisie plus récente du lanceur)
        if not self.stockage.lire_brut().get("uuid"):
            try:
                self.stockage.modifier(uuid=self.config.uuid)
            except OSError as e:
                self.log.warning("Configuration non enregistrée : %s", e)
        self.log.info("Connecté : slot %s, identifiant de partie %#010x, %d coffres, %d spots", r.slot,
                      self.ident_partie, len(self.catalogue.coffres), len(self.catalogue.spots))
        self._maj_checks()
        self._maj_indices()
        self.journal_chat.systeme("connecte", serveur=self.config.serveur, slot=r.nom_joueur(r.slot))
        # DeathLink : tag posé seulement quand le jeu attaché le compile (`_suivre_deathlink`)
        self.deathlink.option, self._tag_deathlink = self.catalogue.death_link, False
        self._maj_tag_deathlink()
        if not self._scout_fait:
            self._lancer(self._scouter(r))

    def _sur_refus(self, erreurs: list[str]) -> None:
        self._refus = list(erreurs) or ["?"]
        self.journal_chat.systeme("refuse", erreurs=list(self._refus))

    def _sur_objets(self, objets: list[ObjetReseau], debut: int) -> None:
        self.objets = list(objets)
        self.reveiller()                                     # don reçu : déposé au tour suivant, sans attendre
        self._maj_checks()

    def _sur_indices(self, _indices: list[dict]) -> None:
        self._maj_checks()
        self._maj_indices()

    def _sur_paquet(self, p: dict) -> None:
        if p.get("cmd") == "RoomUpdate" and "checked_locations" in p:
            self._maj_checks()

    def _sur_deconnexion(self, raison: str) -> None:
        self.log.info("Serveur Archipelago perdu : %s", raison)
        self._maj_checks(connecte=False)
        self._maj_indices(connecte=False)
        self.journal_chat.systeme("deconnecte", raison=str(raison)[:200])

    # ------------------------------------------------------------------------------ discussion (onglet du lanceur)
    def _sur_message(self, _texte: str, p: dict) -> None:
        """PrintJSON du serveur -> `messages.jsonl` (parties colorées, noms résolus ; rien d'autre que ce que le serveur
        envoie)."""
        r = self.reseau
        if r is None:
            return
        parties = ch.parties_printjson(p, slot_soi=r.slot, nom_soi=r.nom_joueur(r.slot) if r.slot else "",
                                       nom_joueur=r.nom_joueur, nom_objet=r.nom_objet, nom_location=r.nom_location)
        self.journal_chat.ajouter(str(p.get("type") or ""), parties)

    async def _surveiller_chat(self) -> None:
        """`chat_commandes.json` (lanceur) surveillé : chaque commande nouvelle de cette session est envoyée une fois."""
        while not self._arret.is_set():
            try:
                await self.suivre_commandes_chat()
            except Exception as e:                            # noqa: BLE001 - la surveillance ne doit pas s'arrêter
                self.log.warning("Commande du lanceur non traitée : %s", e)
            await asyncio.sleep(self.periode_chat)

    async def suivre_commandes_chat(self) -> int:
        """Envoie (Say) les commandes nouvelles du lanceur ; chacune est notée dans le journal (envoyée ou non). Renvoie
        le nombre de commandes envoyées."""
        n = 0
        for c in self.commandes_chat.nouvelles():
            r = self.reseau
            if r is None or not r.connecte:
                self.journal_chat.systeme("non_envoye", commande=c["id"], texte=c["texte"], raison="non_connecte")
                continue
            if "action" in c:
                if await self._action_lanceur(r, c):
                    n += 1
                continue
            try:
                await r.dire(c["texte"])
            except Exception as e:                            # noqa: BLE001 - connexion perdue pendant l'envoi
                self.journal_chat.systeme("non_envoye", commande=c["id"], texte=c["texte"], raison=str(e)[:200])
                continue
            n += 1
            self.journal_chat.systeme("envoye", commande=c["id"], texte=c["texte"])
            self.log.info("Message du lanceur envoyé au serveur (%d caractères)", len(c["texte"]))
        return n

    async def _action_lanceur(self, r: ClientAP, c: dict) -> bool:
        """Action du lanceur (sous-onglet « Indices ») : seul UpdateHint est permis (`indices_local.valider_action`)."""
        paquet = il.valider_action(c.get("action"))
        if paquet is None:
            self.journal_chat.systeme("non_envoye", commande=c["id"], texte=c["texte"], raison="action_invalide")
            return False
        try:
            await r.changer_statut_indice(paquet["player"], paquet["location"], paquet["status"])
        except Exception as e:                                # noqa: BLE001 - connexion perdue pendant l'envoi
            self.journal_chat.systeme("non_envoye", commande=c["id"], texte=c["texte"], raison=str(e)[:200])
            return False
        h = next((h for h in r.indices if il._entier(h.get("finding_player")) == paquet["player"]
                  and il._entier(h.get("location")) == paquet["location"]), None)
        objet = r.nom_objet(int(h["item"]), il._entier(h.get("receiving_player"))) if h and "item" in h else ""
        lieu = r.nom_location(paquet["location"], paquet["player"])
        self.journal_chat.systeme("statut_indice", commande=c["id"], objet=objet, lieu=lieu, statut=paquet["status"])
        self.log.info("Priorité d'un indice demandée au serveur (location %d, état %d)", paquet["location"],
                      paquet["status"])
        return True

    def _maj_indices(self, connecte: bool | None = None) -> None:
        """`indices.json` pour le lanceur (sous-onglet « Indices ») : réécrit seulement s'il a changé."""
        r = self.reseau
        if r is None or r.slot is None:
            return
        try:
            d = il.construire_indices(r.indices, slot=r.slot, team=r.team, graine=str(r.room_info.get("seed_name", "")),
                                      joueur=r.nom_joueur(r.slot), connecte=r.connecte if connecte is None else connecte,
                                      nom_joueur=r.nom_joueur, nom_objet=r.nom_objet, nom_location=r.nom_location)
            self._indices_empreinte = il.ecrire_indices(self.stockage.dossier, d, self._indices_empreinte)
        except OSError as e:
            self.log.warning("indices.json non écrit : %s", e)

    def _lancer(self, coro) -> None:
        t = asyncio.create_task(coro)
        self._taches.add(t)
        t.add_done_callback(self._taches.discard)

    async def _scouter(self, r: ClientAP) -> None:
        """Contenu de TOUTES les locations du slot (LocationScouts, sans indice) pour la table, les notifications
        (« Envoyé : … » d'un boss vaincu), le contenu des checks faits (`checks.json`) et le spoiler log sur demande."""
        locs = r.locations_manquantes | r.locations_verifiees
        try:
            res = await r.scouter(sorted(locs)) if locs else []
        except Exception as e:                               # déconnexion : refait à la prochaine connexion
            self.log.info("LocationScouts non abouti : %s", e)
            return
        if r is not self.reseau:
            return
        self._scout = {o.location: o for o in res}
        self._scout_fait = True
        self._table_ecrite = None
        self.reveiller()
        self.log.info("Contenu de %d locations reçu", len(self._scout))
        self._maj_checks()

    # ------------------------------------------------------------------------------ état publié (§5.2)
    def etat_voulu(self) -> v3.EtatConnexion:
        """État publié dans la zone C (écran Archipelago en lecture seule, bandeau, etat.json). Depuis le 2026-09-28,
        jamais de demande de saisie ni d'effacement de mot de passe (drapeaux 0x01 / 0x04 : la configuration se fait
        dans le lanceur) ; `revision_lue` reste à 0."""
        c, r = self.config, self.reseau
        drapeaux = 0
        commun = dict(connu=c.connu, serveur=c.serveur, slot=c.slot)
        if not c.configuree:
            return v3.EtatConnexion(v3.NON_CONFIGURE, drapeaux=drapeaux, message=MESSAGES["non_configure"], **commun)
        if self._refus:
            code, msg = v3.ERR_AUTRE, "Connexion refusée"
            for nom, k, m in ERREURS_REFUS:
                if nom in self._refus:
                    code, msg = k, m
                    break
            return v3.EtatConnexion(v3.ERREUR, erreur=code, drapeaux=drapeaux | v3.CX_AFFICHER_MESSAGE,
                                    message=msg, **commun)
        if r is not None and r.connecte:
            if self.verrous_manquants or self.boutiques_manquantes:
                return v3.EtatConnexion(v3.CONNECTE, drapeaux=drapeaux, message=MESSAGES["verrous_incompatibles"],
                                        **commun)
            if self.sauvegarde in MESSAGES:
                # sauvegarde non liée / autre partie / jeu ancien / liaison : message dans l'écran seulement (le
                # bandeau reçoit une notification dédiée, une fois par sauvegarde : `_suivre_partie`)
                return v3.EtatConnexion(v3.CONNECTE, drapeaux=drapeaux, message=MESSAGES[self.sauvegarde], **commun)
            return v3.EtatConnexion(v3.CONNECTE, drapeaux=drapeaux | v3.CX_AFFICHER_MESSAGE,
                                    message=MESSAGES["connecte"], **commun)
        if self._deja_connecte:
            return v3.EtatConnexion(v3.DECONNECTE, drapeaux=drapeaux | v3.CX_AFFICHER_MESSAGE,
                                    message=MESSAGES["deconnecte"], **commun)
        if r is not None and r.derniere_erreur:
            return v3.EtatConnexion(v3.ERREUR, erreur=v3.ERR_INJOIGNABLE, drapeaux=drapeaux | v3.CX_AFFICHER_MESSAGE,
                                    message=MESSAGES["injoignable"], **commun)
        return v3.EtatConnexion(v3.CONNEXION, drapeaux=drapeaux, message=MESSAGES["connexion"], **commun)

    async def _publier(self, force: bool = False) -> None:
        voulu = self.etat_voulu()
        if not force and self._publie == voulu.sans_images():
            return
        # AFFICHER_MESSAGE : seulement quand l'état ou le message change (pas pour un simple acquittement)
        if self._publie is not None and not force and (self._publie.etat, self._publie.message) == (voulu.etat, voulu.message):
            voulu = replace(voulu, drapeaux=voulu.drapeaux & ~v3.CX_AFFICHER_MESSAGE)
        self._battement += 1
        a_publier = replace(voulu, client_images=self._battement)
        await self.zone.publier(a_publier)
        self._publie = voulu.sans_images()
        self.etat_publie = a_publier
        self.stats.publications += 1
        self.log.info("État publié : %s — %s", v3.NOMS_ETAT.get(voulu.etat, voulu.etat), voulu.message)

    # ------------------------------------------------------------------------------ configuration du lanceur
    async def _surveiller_config(self) -> None:
        """config.json surveillé (date, taille) : une saisie du lanceur (révision de connexion plus grande que la
        nôtre) est appliquée et reconnecte. Fichier local seulement : aucune lecture ni écriture GDB."""
        while not self._arret.is_set():
            try:
                await self.suivre_fichier_config()
            except Exception as e:                            # noqa: BLE001 - la surveillance ne doit pas s'arrêter
                self.log.warning("Configuration locale illisible : %s", e)
            try:
                self.suivre_demande_spoiler()
            except Exception as e:                            # noqa: BLE001
                self.log.warning("Spoiler log non écrit : %s", e)
            await asyncio.sleep(self.periode_config)

    async def suivre_fichier_config(self) -> bool:
        """Applique config.json s'il a changé ; True si une nouvelle saisie de connexion a été appliquée."""
        sig = self.stockage.signature()
        if sig is None or sig == self._signature_config:
            return False
        self._signature_config = sig
        disque = self.stockage.charger()
        c = self.config
        c.rom = disque.rom                                    # réglage du lanceur (base du randomizer)
        # révision seulement : une configuration écrite par une version antérieure (source « jeu ») compte pareil
        if disque.revision_connexion <= self._rev_locale:
            return False
        if disque.mdp_revision == disque.revision_connexion:  # mot de passe choisi dans cette saisie
            mdp = disque.mot_de_passe
            self.stockage.consommer_transmis()
        else:                                                  # « inchangé » : celui que le client a déjà
            mdp = c.mot_de_passe
        change = (disque.serveur, disque.slot, mdp) != (c.serveur, c.slot, c.mot_de_passe)
        self.log.info("Configuration du lanceur (révision de connexion %d) : serveur %s, slot %s, mot de passe %s%s",
                      disque.revision_connexion,
                      disque.serveur or "-", disque.slot or "-", "défini" if mdp else "aucun",
                      "" if change else " (inchangée)")
        c.serveur, c.slot, c.mot_de_passe = disque.serveur, disque.slot, mdp
        c.memoriser_mot_de_passe = disque.memoriser_mot_de_passe
        c.revision_connexion, c.mdp_revision = disque.revision_connexion, disque.mdp_revision
        c.source_connexion, c.horodatage_connexion = disque.source_connexion, disque.horodatage_connexion
        self._rev_locale = disque.revision_connexion
        if change or self._refus or not (self.reseau and self.reseau.connecte):
            await self._arreter_reseau()
            if c.configuree:
                self._demarrer_reseau()
        self.reveiller()                                       # état republié dans le jeu au prochain tour
        return True

    # ------------------------------------------------------------------------------ un tour
    async def cycle(self) -> None:
        self.stats.cycles += 1
        brut = await self.zone.lire_entete_brut()
        hd = bp.lire_entete(brut)
        if hd["magic"] != bp.MAGIC:
            return                                           # jeu pas encore à sa première image
        h = Entete(**hd)
        self.entete = h
        self.lieu.suivre(h.lieu)                             # en-tête de ce tour seulement : aucun paquet de plus
        if self.boite.nouvelle_instance(h):
            self._nouvelle_instance()
        if h.etat & bp.ETAT_PANIQUE:
            await self._suivre_panique()                 # le jeu a paniqué : enregistrement lu, journalisé, acquitté
        a_v3 = self.zone.disponible(h)
        if a_v3:
            self.zone.ajuster(brut)
        # jeu d'une version antérieure (écran Archipelago avec claviers) : jeu suspendu par un clavier, aucune écriture ;
        # sa configuration (zone J) n'est jamais lue (la saisie se fait dans le lanceur)
        if a_v3 and self.zone.saisie_etat(brut) == v3.SAISIE_CLAVIER_OUVERT:
            return
        if self._connexion_prete and self.reseau is not None:
            await self._verifier_verrous(a_v3)
            await self._verifier_boutiques(h)
            await self._configurer_boite(h, a_v3)            # avant la liaison (identifiant de partie, politique)
            await self._suivre_partie(h, brut)
            await self._suivre_rando(h)
            await self._suivre_rando_boss(h)
            await self._suivre_tracker(h)
            await self._suivre_deathlink(h)
            await self._suivre_anims(h)
        async with self.pont.lot():                          # écritures de fin de tour : un seul arrêt
            if a_v3:
                await self._publier(force=self._publie is None)   # l'état d'abord (puis ce qu'il annonce)
            if self._connexion_prete and self.reseau is not None:
                # tables APRÈS le statut de la sauvegarde de CE tour (sauvegarde liée rechargée : table des coffres
                # présente dès ce tour-ci) et AVANT les dons, dans le même arrêt
                await self._ecrire_table(h, a_v3)
                if a_v3:
                    await self._ecrire_verrous()
                    await self._ecrire_invites(h)
                    await self._ecrire_evenement()
            await self._deposer_dons(h)
            if self._connexion_prete and self.reseau is not None:
                await self._ecrire_mort(h)               # mort reçue : demande au jeu (et son bandeau, ci-dessous)
                await self._deposer_anims(h)             # fenêtres « objet obtenu » des checks sans affichage
            await self._deposer_notifications(h)
            await self._acquitter_journal(h)                 # avec l'arrêt déjà pris, ou au plus tard après un délai
        self._bilan()

    async def _suivre_panique(self) -> None:
        """Panique du jeu (svc Break « PANIC », §28) : le jeu a recopié dans ApPanique l'adresse de retour et la pile de la
        fonction fautive puis attend (au plus 20 s) que `lu` = `compte`. Lu une fois par panique (un seul paquet), écrit
        dans le journal (ERREUR) et dans `plantage.json` du dossier du client, puis acquitté : le jeu continue sa panique
        (svc Break, fenêtre d'erreur d'Azahar). Aucune autre lecture ni écriture."""
        b = await self.pont.lire(bp.ZONE + bp.OFF_PANIQUE, bp.TAILLE_PANIQUE)
        d = bp.dec_panique(b)
        cle = (self._instance, d["compte"])
        if d["compte"] == 0 or cle == self._panique_vue:
            return
        self._panique_vue = cle
        self.log.error("Le jeu a planté (%s). Garder ce journal et plantage.json pour le diagnostic "
                       "(archipelago/PLAN.md, « Si le jeu plante »).", bp.texte_panique(d))
        e = {"horodatage": time.time(), "instance": self._instance, "ident_partie": self.ident_partie,
             **{k: d[k] for k in ("compte", "raison", "images", "etat", "chapitre", "pas", "terrain_numero")},
             "appelant": f"{d['appelant']:#010x}", "pile": f"{d['pile']:#010x}",
             "regs_r4_r11": [f"{x:#x}" for x in d["regs"]],
             "retours": [[o, f"{v:#010x}"] for o, v in bp.retours_panique(d)],
             "mots": [f"{x:#010x}" for x in d["mots"]]}
        self.paniques.append(e)
        try:
            f = Path(self.stockage.dossier) / "plantage.json"
            tmp = f.with_suffix(".tmp")
            tmp.write_text(json.dumps({"format": 1, "paniques": self.paniques[-10:]}, ensure_ascii=False, indent=1),
                           encoding="utf-8")
            tmp.replace(f)
        except OSError as err:
            self.log.warning("plantage.json non écrit : %s", err)
        async with self.pont.transaction():          # écriture jeu arrêté, comme toutes les autres
            await self.pont.ecrire(bp.ZONE + bp.OFF_PANIQUE + bp.PANIQUE_OFF_LU, struct.pack("<I", d["compte"]))

    def _nouvelle_instance(self) -> None:
        self._instance += 1
        self.stats.instances += 1
        self._publie = None
        self._table_ecrite = self._config_ecrite = self._depot_cle = None
        self._boutiques_ecrites = None
        self._partie_cle = None
        self._oublier_sauvegarde()
        self._resync_demandee = True
        self._victoire_t = 0.0
        self._spots_vus = -1
        self._progression_vue = None
        self._verrous_ecrits = None
        self._verrous_compiles = None
        self._invites_compiles = self._invites_ecrits = None
        self._etendues_compilees = None
        self._evenement_ecrit = None
        self._invites_seq = 0
        self._recompenses_etat = None
        self._boutiques_etat = None
        self._rando_jeu = None
        self._medaillium = None
        self._progression_suivi = None
        self._journal_lu, self._acquitter_t = 0, 0.0
        self._rando_lu_cle, self._rando_attente = None, False
        self._boss_jeu = None
        self._boss_lu_cle, self._boss_attente, self._boss_valide_lu = None, False, 0
        self._terrain_suivi = None
        self._adresse_q = self._adresse_rang = None
        self.deathlink.nouvelle_instance()
        self.anims.nouvelle_instance()
        self._maj_tag_deathlink()
        self.log.info("Nouvelle instance du jeu (session GDB %d) : resynchronisation complète", self.pont.sessions)

    async def _configurer_boite(self, h, a_v3: bool) -> None:
        politique = bp.POLITIQUE_REESSAYER if self.catalogue.politique_reessai else 0
        if h.version >= bp.VERSION_LIAISON:
            # v4 : le jeu ne marque une sauvegarde QUE sur une demande de liaison explicite (liaison_demande,
            # `_evaluer_sauvegarde`) ; un jeu v3 marquerait toute sauvegarde chargée : jamais de MARQUER pour lui
            politique |= bp.POLITIQUE_MARQUER
        langue = 1 if self.catalogue.langue == "en" else 0
        voulu = (self._instance, self.ident_partie, politique, langue, self.catalogue.vitrine)
        if self._config_ecrite == voulu and h.ident_partie == self.ident_partie:
            return
        async with self.pont.transaction():
            await self.boite.configurer(ident_partie=self.ident_partie, politique=politique, notif_langue=langue,
                                        pause=False)
            if a_v3:
                await self.pont.ecrire(*bp.champ("vitrine", self.catalogue.vitrine))
        self._config_ecrite = voulu

    # ------------------------------------------------------------------------------ tables (coffres, J3, J5)
    def _contenu(self, loc: int) -> Contenu | None:
        """Contenu d'une location : celui de slot_data (APWorld), sinon déduit du LocationScouts."""
        c = self.catalogue.contenus.get(loc)
        if c is not None:
            return c
        r, o = self.reseau, self._scout.get(loc)
        if o is None or r is None:
            return None
        nom_objet = r.nom_objet(o.item, o.player)
        if o.player == r.slot:
            don = self.catalogue.don(o.item)
            if don.type == bp.DON_OBJET and don.hash:
                return Contenu(True, don.hash, None)
            return Contenu(True, self.catalogue.vitrine, nom_objet)
        return Contenu(False, self.catalogue.vitrine, nom_vitrine(nom_objet, r.nom_joueur(o.player)))

    def table_voulue(self, a_v3: bool) -> tuple[list[EntreeCoffre], dict[int, str]]:
        """Entrées de la table des coffres (par index en v3, par hachage TBox sinon) et noms de vitrine
        {étiquette = location : texte}."""
        entrees, noms = [], {}
        for loc, idx in sorted(self.catalogue.coffres.items(), key=lambda x: x[1]):
            c = self._contenu(loc)
            if c is None:
                continue
            drapeaux = bp.COFFRE_AFFICHAGE_SEUL
            if a_v3:
                tbox, drapeaux = idx, drapeaux | bp.COFFRE_PAR_INDEX
            elif loc in self.catalogue.hachages_tbox:
                tbox = self.catalogue.hachages_tbox[loc]
            else:
                continue
            entrees.append(EntreeCoffre(tbox, c.hachage, 1, drapeaux, loc & 0xFFFFFFFF))
            if c.hachage == self.catalogue.vitrine and c.texte:
                noms[loc] = c.texte
        return entrees, noms

    def scripts_voulus(self) -> tuple[list[v3.EntreeScript], dict[int, str]]:
        """Dons de script substitués (§12) : un par spot connu de slot_data. Spot mélangé : l'objet d'origine
        n'est pas donné, la fenêtre montre le contenu AP (vitrine nommée ou objet de ce monde, qui arrive par la
        file) ; spot NON mélangé : DONNER l'objet d'origine (le jeu le donne lui-même, le bit de check est posé)."""
        entrees, noms = [], {}
        for loc, e in sorted(self.catalogue.emplacements.items(), key=lambda x: x[1].bit):
            c = self._contenu(loc)
            if not e.hachage_origine or c is None:
                continue
            if e.substituer:
                entrees.append(v3.EntreeScript(e.hachage_origine, c.hachage, e.bit, 0, loc))
            else:
                entrees.append(v3.EntreeScript(e.hachage_origine, e.hachage_origine, e.bit, bp.SCRIPT_DONNER, loc))
            if c.hachage == self.catalogue.vitrine and c.texte:
                noms[loc] = c.texte
        return entrees, noms

    def recompenses_voulues(self) -> dict[int, bytes]:
        """Table des récompenses de quête (boîte v5, §21) : n° de quête -> entrée. Objet de ce monde : le vrai objet
        (montré, puis livré par la file de dons quand le check est confirmé) ; autre monde, argent, objet sans objet du
        jeu : la vitrine et son nom. Service déjà envoyé : pas d'entrée (il est rejouable ; il redonne sa récompense
        d'origine, sans objet)."""
        r, verifiees = {}, (self.reseau.locations_verifiees if self.reseau is not None else set())
        for loc, q in sorted(self.catalogue.recompenses.items()):
            c = self._contenu(loc)
            if c is None or (q.service and loc in verifiees):
                continue
            texte = bp.nom_vitrine(c.texte) if c.hachage == self.catalogue.vitrine and c.texte else b""
            r[q.quete] = bp.enc_quete(c.hachage, loc, bp.QUETE_VALIDE, texte)
        return r

    async def _etat_recompenses(self, h) -> str:
        """« actives », « non_compilees » (build --define YKW2_AP_SANS_RECOMPENSES) ou « jeu_ancien » (boîte v4 : aucune
        table ; la récompense d'origine est donnée, le check part quand même par la phase 255). Lu une fois par
        instance du jeu."""
        if self._recompenses_etat is None or self._recompenses_etat[0] != self._instance:
            if not self.zone.recompenses_disponibles(h):
                etat = "jeu_ancien"
            else:
                c = bp.recompenses_compilees(await self.zone.lire_quetes_entete())
                etat = "actives" if c else "non_compilees"
            self._recompenses_etat = (self._instance, etat)
            if self.catalogue.recompenses and etat != "actives":
                self.log.warning("Récompenses de quête d'origine (%s) : les checks de quête partent quand même",
                                 "jeu v%d sans table" % h.version if etat == "jeu_ancien"
                                 else "build compilé sans la substitution")
        return self._recompenses_etat[1]

    def boutiques_voulues(self) -> list[bytes]:
        """Table des boutiques (boîte v9, §26) : une entrée par hachage d'article des locations de boutique pas encore
        faites. Objet de ce monde : le vrai objet (montré, puis livré par la file de dons quand le check est confirmé) ;
        autre monde, argent, objet sans objet du jeu : la vitrine et son nom. Articles omis : déjà cochés sur le serveur
        quand la sauvegarde liée a été vue (instantané `_boutiques_faites` : l'article reste d'origine même si le joueur
        recharge une sauvegarde d'avant l'achat) ; le jeu omet de lui-même ceux dont le bit est posé."""
        if self._boutiques_faites is None:
            verifiees = self.reseau.locations_verifiees if self.reseau is not None else set()
            self._boutiques_faites = frozenset(loc for loc in self.catalogue.boutiques if loc in verifiees)
        r = []
        for loc, b in sorted(self.catalogue.boutiques.items(), key=lambda x: x[1].bit):
            c = self._contenu(loc)
            if c is None or loc in self._boutiques_faites:
                continue
            texte = bp.nom_vitrine(c.texte) if c.hachage == self.catalogue.vitrine and c.texte else b""
            affiche = 0 if c.hachage == self.catalogue.vitrine else c.hachage
            for a in b.articles:
                r.append(bp.enc_boutique(a, affiche, loc, b.bit, bp.BOUTIQUE_VALIDE, texte))
        return r[:bp.CAP_BOUTIQUES]

    async def _etat_boutiques(self, h) -> str:
        """« actives », « non_compilees » (build --define YKW2_AP_SANS_BOUTIQUES) ou « jeu_ancien » (boîte v8 ou
        antérieure : aucune table). Lu une fois par instance du jeu."""
        if self._boutiques_etat is None or self._boutiques_etat[0] != self._instance:
            if not self.zone.boutiques_disponibles(h):
                etat = "jeu_ancien"
            else:
                c = bp.boutiques_compilees(await self.zone.lire_boutiques_entete())
                etat = "actives" if c else "non_compilees"
            self._boutiques_etat = (self._instance, etat)
        return self._boutiques_etat[1]

    def _preparer_boutiques(self) -> str:
        """Hachages des articles (format 17) lus dans `boutiques_local.json`, généré depuis la ROM configurée s'il manque
        (tâche de fond, < 1 s) ; renvoie l'état : « pretes » (tous les articles ont leur hachage), « calcul »,
        « absente » (ni table locale ni ROM : « Réparer le mod »), « refusee » (ROM qui ne correspond pas)."""
        a_resoudre = {loc: b for loc, b in self.catalogue.boutiques.items() if not b.articles}
        if not a_resoudre:
            self._boutiques_resolution = "pretes"
            return "pretes"
        if self._boutiques_tache is not None and not self._boutiques_tache.done():
            return "calcul"
        try:
            ib = _installation_boutiques()
        except Exception as e:  # noqa: BLE001 - module distribué avec le client ; absent : refus clair
            return self._boutiques_refus("absente", f"module installation/boutiques.py introuvable ({e})")
        try:
            attendue = ib.apworld_boutiques().EMPREINTE_ARTICLES
        except Exception:  # noqa: BLE001 - APWorld embarqué illisible : la table locale reste contrôlée article par article
            attendue = None
        table = ib.charger(self.stockage.dossier, attendue)
        if table is None:
            if self._boutiques_resolution == "refusee":
                return "refusee"            # ROM déjà refusée : pas de nouvelle lecture à chaque tour
            rom = self.config.rom
            if not rom or not Path(rom).is_file():
                return self._boutiques_refus("absente", "table locale des boutiques absente et ROM non configurée "
                                             "(« Réparer le mod » dans le lanceur)")
            self.log.info("Articles de boutique : table locale générée depuis la ROM…")
            self._boutiques_resolution = "calcul"
            self._boutiques_tache = asyncio.create_task(asyncio.to_thread(ib.generer_fichier, rom,
                                                                          self.stockage.dossier))
            self._boutiques_tache.add_done_callback(self._boutiques_generee)
            return "calcul"
        try:
            resolus = {loc: ib.cles_article(table, b.boutique, b.entrees, b.nb_entrees) for loc, b in a_resoudre.items()}
        except ib.ErreurBoutiques as e:
            return self._boutiques_refus("refusee", f"article de la graine introuvable dans la ROM ({e})")
        for loc, arts in resolus.items():
            self.catalogue.boutiques[loc].articles = arts
        self._boutiques_resolution = "pretes"
        self.log.info("Articles de boutique lus dans la ROM du joueur : %d location(s)", len(resolus))
        return "pretes"

    def _boutiques_refus(self, etat: str, message: str) -> str:
        if self._boutiques_resolution != etat:
            self.log.error("Boutiques : %s ; les checks de boutique sont impossibles (rien ne sera lié, livré ni "
                           "envoyé)", message)
        self._boutiques_resolution = etat
        return etat

    def _boutiques_generee(self, t: asyncio.Task) -> None:
        if t.cancelled():
            return
        e = t.exception()
        if e is not None:
            self._boutiques_refus("refusee", f"ROM refusée : {e}")
        else:
            self.log.info("Table locale des boutiques écrite : %s", t.result())
            self._boutiques_resolution = "absente"      # relue tout de suite (« pretes » si elle convient)
            self._preparer_boutiques()

    async def _verifier_boutiques(self, h) -> None:
        """Une graine avec des checks de boutique exige un jeu v9 compilé avec les boutiques et les hachages de ses
        articles lus dans la ROM du joueur (format 17) : sinon ces locations sont impossibles (l'achat donnerait l'objet
        d'origine, aucun bit) -> état « Verrous incompatibles » (rien n'est lié, livré ni envoyé), comme un verrou
        manquant (§20)."""
        resolution = self._preparer_boutiques() if self.catalogue.boutiques else "pretes"
        manquantes = bool(self.catalogue.boutiques) and (await self._etat_boutiques(h) != "actives"
                                                         or resolution != "pretes")
        if manquantes != self.boutiques_manquantes:
            self.boutiques_manquantes = manquantes
            if manquantes and resolution != "pretes":
                self.log.warning("Boutiques : hachages des articles pas encore lus dans la ROM du joueur (%s) : "
                                 "partie en attente", resolution)
            elif manquantes:
                pourquoi = ("jeu v%d" % h.version if self._boutiques_etat[1] == "jeu_ancien"
                            else "build compilé sans les boutiques")
                self.log.error("Boutiques absentes du jeu installé (%s) : la partie a %d checks de boutique ; rien ne "
                               "sera lié, livré ni envoyé. Installer le patch du mod à jour, ou générer une graine avec "
                               "l'option boutiques: aucune.", pourquoi, len(self.catalogue.boutiques))

    async def _ecrire_table(self, h, a_v3: bool) -> None:
        if not self._scout_fait and not self.catalogue.contenus:
            return
        entrees, noms = self.table_voulue(a_v3)
        scripts, noms_scripts = self.scripts_voulus() if a_v3 else ([], {})
        noms.update(noms_scripts)
        recompenses = None
        if a_v3 and self.catalogue.recompenses and await self._etat_recompenses(h) == "actives":
            recompenses = self.recompenses_voulues()
        boutiques = None
        if a_v3 and self.catalogue.boutiques and await self._etat_boutiques(h) == "actives":
            boutiques = self.boutiques_voulues() if self.sauvegarde == "liee" else []
        if self.sauvegarde != "liee":
            # sauvegarde non liée (ou aucune) : aucune table qui change le jeu (le jeu v4 les ignore aussi)
            entrees, scripts, noms = [], [], {}
            recompenses = {} if recompenses is not None else None
        if boutiques is not None:
            # table des boutiques (jusqu'à 25 Ko) : écrite à part, seulement si ELLE change (pas à chaque changement des
            # autres tables) ; une table vide ne coûte qu'un mot (`valide` = 0), et seulement pour en retirer une
            cle_b = (self._instance, tuple(boutiques))
            if cle_b != self._boutiques_ecrites and (boutiques or self._boutiques_ecrites is not None):
                await self.zone.ecrire_boutiques(boutiques)
                self.log.info("Table des boutiques écrite : %d article(s)", len(boutiques))
            self._boutiques_ecrites = cle_b if (boutiques or self._boutiques_ecrites is not None) else None
        cle = (self._instance, tuple(entrees), tuple(scripts), tuple(sorted(noms.items())),
               None if recompenses is None else tuple(sorted(recompenses.items())))
        if self._table_ecrite == cle:
            return
        if not entrees and self.catalogue.coffres and self.sauvegarde == "liee":
            self.log.warning("Table des coffres non écrite : boîte v%d sans entrées par index ni hachages TBox",
                             h.version)
        await self.boite.ecrire_table_coffres(entrees)
        if a_v3:
            await self.zone.ecrire_noms(dict(list(noms.items())[:self.zone.capacites["noms"]]))
            if len(scripts) > self.zone.capacites["scripts"]:
                # jeu antérieur aux objets-clés de quête (16 entrées) : les dernières (bit 575, puis sans bit) sont
                # ignorées, leurs objets sont donnés d'origine (archipelago_objets_cles_v11.md §16.4)
                self.log.warning("Table des dons de script : %d entrées pour %d places dans ce jeu (patch à mettre à "
                                 "jour) : les dernières sont ignorées", len(scripts), self.zone.capacites["scripts"])
            await self.zone.ecrire_scripts(scripts[:self.zone.capacites["scripts"]])
        if recompenses is not None:
            await self.zone.ecrire_recompenses(recompenses)
        self._table_ecrite = cle
        self.stats.tables_ecrites += 1
        self.log.info("Tables écrites : %d coffres, %d dons de script, %d noms de vitrine, %s récompenses de quête",
                      len(entrees), len(scripts), len(noms), "-" if recompenses is None else len(recompenses))

    async def _verifier_verrous(self, a_v3: bool) -> None:
        """Verrous compilés dans le jeu (§20, lus une fois par instance) comparés aux verrous que slot_data exige :
        un verrou exigé mais absent fausserait la logique de la graine (elle compte sur un objet qui bloque vraiment)
        -> état « Verrous incompatibles »."""
        if self._verrous_compiles is None or self._verrous_compiles[0] != self._instance:
            compiles = bp.verrous_compiles(await self.zone.lire_verrous()) if a_v3 else None
            self._verrous_compiles = (self._instance, compiles)
            self.log.info("Verrous compilés dans le jeu : %s", "aucune liste publiée (jeu sans verrous)"
                          if compiles is None else f"{compiles:#x}")
        compiles = self._verrous_compiles[1] or 0
        # invités de l'Auberge : le n° FONCTION_INVITES n'est jamais publié dans `compiles` (un client d'avant les
        # invités refuse donc la graine) ; ici il se lit dans la zone des invités, une fois par instance
        fonctions = set(self.catalogue.fonctions) - {bp.FONCTION_INVITES, bp.FONCTION_ETENDUES}
        manquants = sorted(k for k in set(self.catalogue.verrous) | fonctions if not compiles >> k & 1)
        if self.catalogue.invites or bp.FONCTION_INVITES in self.catalogue.fonctions:
            if self._invites_compiles is None or self._invites_compiles[0] != self._instance:
                h = self.entete
                bits = await self.zone.lire_invites_compile() \
                    if a_v3 and h is not None and self.zone.invites_disponibles(h) else None
                self._invites_compiles = (self._instance, bits)
                self.log.info("Invités de l'Auberge compilés dans le jeu : %s",
                              "non (jeu antérieur ou compilé sans)" if bits is None else f"{bits:#x}")
            if not (self._invites_compiles[1] or 0) & bp.INVITES_COMPILE:
                manquants = sorted(manquants + [bp.FONCTION_INVITES])
        # fonctions étendues (n° >= 32) : lues dans ApPnj::fonctions, une fois par instance, seulement si la graine en
        # exige ; le n° 22 seul (graine d'un APWorld plus récent que ce client ?) ne demande rien de plus
        if self.catalogue.fonctions_etendues - bp.FONCTIONS_CLIENT_CONNUES:
            if self._etendues_compilees is None or self._etendues_compilees[0] != self._instance:
                h = self.entete
                bits = await self.zone.lire_fonctions_etendues()                     if a_v3 and h is not None and self.zone.pnj_disponibles(h) else None
                self._etendues_compilees = (self._instance, bits)
                self.log.info("Fonctions étendues compilées dans le jeu : %s",
                              "aucune liste publiée (jeu antérieur)" if bits is None else f"{bits:#x}")
            # (les n° « client » connus de ce client, jamais publiés par le jeu, ne demandent rien au jeu)
            manquants = sorted(manquants + [n for n in self.catalogue.fonctions_etendues - bp.FONCTIONS_CLIENT_CONNUES
                                            if not bp.fonction_etendue_compilee(self._etendues_compilees[1], n)])
        options = bp.options_actives(self.catalogue.bingo_kai_infini)
        options_absentes = sorted(k for k in range(32) if options >> k & 1 and not compiles >> k & 1)
        if options_absentes != self.options_absentes:
            self.options_absentes = options_absentes
            if options_absentes:                     # confort seulement : aucune location n'en dépend, rien de refusé
                self.log.warning("Option(s) %s choisie(s) dans la graine mais absente(s) du jeu installé (patch trop "
                                 "ancien ou compilé sans) : le jeu garde son comportement d'origine.",
                                 ", ".join(bp.NOMS_OPTIONS.get(k, f"k={k}") for k in options_absentes))
        if manquants != self.verrous_manquants:
            self.verrous_manquants = manquants
            if manquants:
                self.log.error("Verrous incompatibles : la partie exige %s, absent(s) du jeu installé (patch trop ancien "
                               "ou compilé sans) ; rien ne sera lié, livré ni envoyé. Installer le patch du mod à jour, "
                               "ou générer une graine sans ce(s) verrou(s) (option verrous_actifs).",
                               ", ".join(bp.NOMS_VERROUS.get(k, f"k={k}") for k in manquants))

    async def _ecrire_verrous(self) -> None:
        """Verrous (§16) : actifs = verrous de slot_data ; recu[k] = l'objet est dans ReceivedItems. Verrou progressif
        (rangs de montre, k = 18) : recu[k] = NOMBRE d'exemplaires dans ReceivedItems. Graine de format 7 : entrée
        « rangs_d » (k = 19, même objet) = mode « portes D » du jeu (rang AP = ce nombre, portes D fermées) ; recu[19]
        vaut 0 / 1 et n'est pas lu par le jeu. Graine antérieure (sans k = 19) : rang AP = D + ce nombre. Graine de
        format 20 : entrée « rangs_reel » (k = 20, même objet) = mode « rang réel » : le JEU monte le vrai rang de la
        montre à min(recu[18], A) sur le terrain de la sauvegarde liée (idempotent : une sauvegarde antérieure
        rechargée est remontée par le jeu, sans rien de plus à écrire ici) ; recu[20] vaut 0 / 1, non lu par le jeu.
        Graine de format 21 : entrée « velo_reel » (k = 21, objet Vélo) = mode « vélo réel » : le JEU donne vraiment le
        vélo quand recu[12] passe à 1 (flags 39 / 40, objet vélo ; une sauvegarde antérieure rechargée est remise en
        état par le jeu) ; recu[21] vaut 0 / 1, non lu par le jeu."""
        recus = collections.Counter(o.item for o in self.objets)
        actifs = 0
        recu: dict[int, bool | int] = {}
        for k, objet in self.catalogue.verrous.items():
            if 0 <= k < self.zone.capacites["verrous"]:
                actifs |= 1 << k
                recu[k] = min(recus[objet], 255) if k in bp.VERROUS_PROGRESSIFS else objet in recus
        # options du joueur appliquées par le jeu (bits 24.., sans objet : recu[] non concerné) ; un jeu qui ne les
        # compile pas ignore le bit (jeu d'origine), aucune location n'en dépend
        actifs |= bp.options_actives(self.catalogue.bingo_kai_infini)
        if self.sauvegarde != "liee" or self.verrous_manquants:
            actifs = 0                                   # sauvegarde non liée : aucun verrou (jeu normal)
        cle = (self._instance, actifs, tuple(sorted(recu.items())))
        if cle == self._verrous_ecrits:
            return
        await self.zone.ecrire_verrous(actifs, recu)
        self._verrous_ecrits = cle
        self.log.info("Verrous : actifs %#x, reçus %s", actifs, sorted(k for k, v in recu.items() if v))

    # ------------------------------------------------------------------------------ invités de l'Auberge des voyageurs
    def invite_declare(self, inv: Invite) -> bool:
        """Déclencheur de l'invité rempli. « requetes » : la graine a des requêtes-checks et le serveur les tient
        TOUTES pour cochées (critère (i) de l'analyse : couvre les services, survit aux rechargements). « objet » :
        son invitation est dans les objets reçus du serveur (ReceivedItems : survit aux rechargements et aux
        relancements, vaut pour toute sauvegarde liée à la partie). Déclencheur inconnu de ce client (APWorld plus
        récent) : jamais."""
        r = self.reseau
        if r is None:
            return False
        if inv.declencheur == "objet":
            return inv.objet != 0 and any(o.item == inv.objet for o in self.objets)
        if inv.declencheur != "requetes" or not inv.locations:
            return False
        return inv.locations <= r.locations_verifiees

    # ------------------------------------------------------- Yo-kai d'évènement à leur emplacement d'origine (§33)
    def evenement_masque(self) -> int:
        """Bits de ApPnj::ev_declares : Yo-kai dont l'objet AP (slot_data `evenement_places`) est dans les objets
        reçus du serveur (ReceivedItems : vaut pour toute sauvegarde liée, survit aux relancements)."""
        recus = {o.item for o in self.objets}
        return sum(1 << k for k, objet in self.catalogue.evenement_places.items() if objet in recus)

    async def _ecrire_evenement(self) -> None:
        """Objets reçus -> ApPnj::ev_declares + ev_ident, seulement si la graine en a, si le jeu publie la fonction
        étendue 34 et si rien ne manque. Écrit quand le masque change (objet reçu, nouvelle instance) : aucun paquet
        périodique. Écrit même hors sauvegarde liée : le masque vise l'identifiant de partie (`ev_ident`) et le jeu
        l'ignore pour toute autre sauvegarde ; ainsi un PNJ est là dès le chargement de la sauvegarde, sans attendre
        la liaison de ce tour."""
        if not self.catalogue.evenement_places or self.verrous_manquants or not self.ident_partie \
                or self._etendues_compilees is None or self._etendues_compilees[0] != self._instance \
                or not bp.fonction_etendue_compilee(self._etendues_compilees[1], bp.FONCTION_EVENEMENT_PLACE):
            return
        cle = (self._instance, self.evenement_masque(), self.ident_partie)
        if cle == self._evenement_ecrit:
            return
        await self.zone.ecrire_evenement(cle[1], self.ident_partie)
        self._evenement_ecrit = cle
        self.log.info("Yo-kai d'évènement à leur place : %s",
                      ", ".join(bp.EV_NOMS[k] for k in range(bp.EV_NOMBRE) if cle[1] >> k & 1) or "aucun objet reçu")

    def invites_voulus(self) -> list[tuple[int, int, int, int]]:
        """Liste à écrire dans le jeu : (CHARA_PARAM, n° du Médaillium, drapeaux, chambre) dans l'ordre de la graine.
        `chambre` : celle que le jeu a attribuée à l'invité dans la sauvegarde liée (mémoire de liaison ; 0 : aucune,
        et toujours 0 pour Pandanoko, qui loge dans la Suite) ; un patch antérieur ignore cet octet."""
        l = self._liaison
        annonces = l.invites_annonces if l is not None else set()
        chambres = l.invites_chambres if l is not None else {}
        return [(inv.param, inv.medaille, (bp.INVITE_DECLARE if self.invite_declare(inv) else 0)
                 | (bp.INVITE_ANNONCE if inv.medaille in annonces else 0),
                 0 if inv.param == bp.INVITES_PARAM_PNJ else chambres.get(inv.medaille, 0))
                for inv in self.catalogue.invites]

    async def _ecrire_invites(self, h) -> None:
        """Liste des invités -> ApInvites, pour la sauvegarde LIÉE seulement et seulement si le jeu publie la fonction
        (un jeu antérieur n'a rien là). Écrite quand elle change (déclencheur rempli, annonce faite, autre sauvegarde
        liée, nouvelle instance) : aucun paquet périodique. Le jeu revérifie tout (sauvegarde visée et liée, pas
        encore ami) ; hors sauvegarde liée, rien n'est écrit : la liste déjà là vise une autre sauvegarde."""
        if not self.catalogue.invites or self._invites_compiles is None \
                or self._invites_compiles[0] != self._instance \
                or not (self._invites_compiles[1] or 0) & bp.INVITES_COMPILE:
            return
        if self.sauvegarde != "liee" or self._liaison is None or self.verrous_manquants or not h.partie \
                or not self.ident_partie:
            return
        voulus = self.invites_voulus()
        self._maj_invites_fichier(h, voulus)
        cle = (self._instance, self.ident_partie, tuple(voulus))
        if cle == self._invites_ecrits:
            return
        self._invites_seq += 1
        await self.zone.ecrire_invites(voulus, self.ident_partie, self._invites_seq)
        self._invites_ecrits = cle
        declares = [f"n° {m}{' (déjà annoncé)' if d & bp.INVITE_ANNONCE else ''}{f' (chambre {100 + c})' if c else ''}"
                    for _, m, d, c in voulus if d & bp.INVITE_DECLARE]
        self.log.info("Invités de l'Auberge : %d sur %d déclaré(s)%s", len(declares), len(voulus),
                      " : " + ", ".join(declares) if declares else "")

    def _maj_invites_fichier(self, h, voulus) -> None:
        """`invites.json` (tracker de Yo-kai du lanceur) : état de chaque invité pour la sauvegarde liée : « attente »
        (déclencheur pas rempli : `restantes` locations à cocher, ou invitation pas reçue), « present » (`piece` : 0 la
        Suite, réservée à Pandanoko ; 1..9 les chambres 101..109), « file » (déclaré, attend qu'une des neuf chambres
        se libère : `rang` dans la file),
        « ami » (bit du Médaillium de la dernière lecture groupée). Patch courant (Suite réservée, chambres gardées) :
        rien n'est calculé, la chambre est celle que le jeu a signalée (mémoire de liaison) ; patch antérieur : même
        calcul que ce patch-là (`bp.etats_invites`), sans les errants StreetPass du joueur, que le client ne lit pas.
        Écrit seulement quand il change."""
        r = self.reseau
        amis = set()
        if self._medaillium is not None and self._medaillium[0] == h.ident_sauvegarde:
            z = rando.zones_medaillium(self._medaillium[1]).get("ami") or b""
            if len(z) >= rando.TAILLE_MEDAILLIUM:
                amis = {inv.medaille for inv in self.catalogue.invites if z[inv.medaille >> 3] >> (inv.medaille & 7) & 1}
        etats = []
        # la règle d'affectation est celle que le patch publie (Suite réservée à Pandanoko, ou patch antérieur)
        pieces, reservee = bp.regle_invites(self._invites_compiles[1])
        calcul = bp.etats_invites([(p, m, bool(d & bp.INVITE_DECLARE), c) for p, m, d, c in voulus], amis, pieces,
                                  reservee)
        for inv, e in zip(self.catalogue.invites, calcul):
            restantes = len(inv.locations - r.locations_verifiees) if r is not None else len(inv.locations)
            x = {"medaille": inv.medaille, "location": inv.location, "declencheur": inv.declencheur,
                 "etat": e["etat"], "restantes": restantes, "total": len(inv.locations)}
            if "piece" in e:
                x["piece"] = e["piece"]
            if "rang" in e:
                x["rang"] = e["rang"]
            etats.append(x)
        cle = (self.ident_partie, h.ident_sauvegarde, json.dumps(etats, sort_keys=True))
        if cle == self._invites_fichier:
            return
        try:
            p = Path(self.stockage.dossier) / FICHIER_INVITES
            tmp = p.with_suffix(".tmp")
            tmp.write_text(json.dumps({"format": FORMAT_INVITES, "horodatage": time.time(),
                                       "ident_partie": self.ident_partie, "ident_sauvegarde": h.ident_sauvegarde,
                                       "invites": etats}, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(p)
            self._invites_fichier = cle
        except OSError as ex:
            self.log.warning("invites.json non écrit : %s", ex)

    # ------------------------------------------------------------------------------ randomizer de Yo-kai (R3)
    def _rando_publier(self, statut: str, message: str, niveau: int = logging.INFO) -> None:
        if (statut, message) != (self.rando_statut, self.rando_message):
            self.rando_statut, self.rando_message = statut, message
            self.log.log(niveau, "Randomizer de Yo-kai : %s", message)
        self._rando_fichier_local()

    def _rando_fichier_local(self, jeu: dict | None = None) -> None:
        """`rando_yokai.json` (tracker du lanceur) : réécrit quand le mélange, l'état ou ce que le jeu publie change."""
        etat = {"pret": "actif", "aucun": "aucun", "refuse": "refuse", "base_absente": "refuse"}.get(
            self.rando_statut, "attente")
        cle = (self.ident_partie, self.rando_statut, self.rando_message,
               None if self.rando_melange is None else self.rando_melange.generation,
               None if jeu is None else tuple(sorted(jeu.items())))
        if cle == self._rando_fichier:
            return
        self._rando_fichier = cle
        try:
            rando.ecrire_fichier_local(self.stockage.dossier, self.rando_melange, self.ident_partie, etat,
                                       dict(jeu or {}, message=self.rando_message))
        except OSError as e:
            self.log.warning("rando_yokai.json non écrit : %s", e)

    def _preparer_rando(self) -> None:
        """Mélange de la graine, une fois par (partie, mode, graine). Base locale absente : générée en tâche de fond
        depuis la ROM configurée (sinon : « Réparer le mod » dans le lanceur)."""
        ry = self.catalogue.rando_yokai
        version = 1 if ry is None else int(ry.get("melange", 1))
        cle = (self.ident_partie, None if ry is None else ry["mode"], None if ry is None else ry["graine"], version)
        if cle == self._rando_cle or (self._rando_tache is not None and not self._rando_tache.done()):
            return
        if ry is None:
            self._rando_cle, self.rando_melange = cle, None
            if self.catalogue.rando_yokai_inconnu:
                self._rando_publier("refuse", f"mode de mélange {self.catalogue.rando_yokai_inconnu!r} inconnu de ce "
                                    "client (APWorld plus récent : mettre à jour le mod) : Yo-kai d'origine",
                                    logging.WARNING)
                return
            self._rando_publier("aucun", "pas de mélange sur cette partie")
            return
        if version not in rando.VERSIONS_MELANGE:
            self._rando_cle, self.rando_melange = cle, None
            self._rando_publier("refuse", f"mélange de version {version} inconnu de ce client (APWorld plus récent : "
                                "mettre à jour le mod) : Yo-kai d'origine", logging.WARNING)
            return
        base = rando.charger_base(self.stockage.dossier)
        rom = self.config.rom
        besoin = rando.format_requis(ry["mode"], version)
        if base is not None and base.get("format", 0) < besoin and rom and Path(rom).is_file():
            base = None         # format antérieur (sans les espèces exigées fixées / les emplacements) : régénérée
        if base is None:
            if not rom or not Path(rom).is_file():
                self._rando_cle, self.rando_melange = cle, None
                self._rando_publier("base_absente", "base locale des rencontres absente : « Réparer le mod » dans le "
                                    "lanceur (ROM non configurée)", logging.WARNING)
                return
            self._rando_publier("calcul", "base locale des rencontres générée depuis la ROM…")
            self._rando_tache = asyncio.create_task(asyncio.to_thread(rando.generer_base, rom, self.stockage.dossier))
            self._rando_tache.add_done_callback(self._rando_generee)
            return
        self._rando_cle = cle
        try:
            self.rando_melange = rando.calculer(base, ry["graine"], ry["mode"], version=version)
        except rando.RandoImpossible as e:
            self.rando_melange = None
            self._rando_publier("refuse", f"mélange refusé : {e}", logging.ERROR)
            return
        m = self.rando_melange
        if m.par_rencontre:
            self._rando_publier("pret", f"mélange {m.mode} (version {m.version}) de la graine {m.graine} : "
                                f"{m.stats['changes']} combattants "
                                f"changés sur {m.stats['combattants']} ({m.stats['rencontres_changees']} rencontres sur "
                                f"{len(m.w)}), empreinte {m.empreinte[:12]}" + self._rando_sans_normal(m))
            return
        self._rando_publier("pret", f"mélange {m.mode} (version {m.version}) de la graine {m.graine} : "
                            f"{len(m.sigma)} espèces déplacées, "
                            f"{len(m.w)} rencontres, empreinte {m.empreinte[:12]}" + self._rando_sans_normal(m))

    @staticmethod
    def _rando_sans_normal(m) -> str:
        """Version 3 du mélange (§21) : repli annoncé dans le journal (jamais silencieux)."""
        if m.version < 3:
            return ""
        invitees = ""
        if m.version >= 4:                                # §22 : espèces invitées (repli annoncé, jamais silencieux)
            invitees = (f" ; {len(m.invitees) - len(m.invitees_absentes)} Yo-kai invités placés sur "
                        f"{len(m.invitees)}" + (f" ({len(m.invitees_absentes)} sans aucune place : "
                                                + ", ".join(f"0x{p:08X}" for p in m.invitees_absentes[:8]) + ")"
                                                if m.invitees_absentes else ""))
        if not m.sans_normal:
            return invitees + " ; chaque Yo-kai du mélange a un lieu hors portail mystère"
        return (invitees + f" ; {len(m.sans_normal)} Yo-kai sans lieu hors portail mystère (contrainte infaisable "
                "pour eux : " + ", ".join(f"0x{p:08X}" for p in m.sans_normal[:8]) + ")")

    def _rando_generee(self, t: asyncio.Task) -> None:
        if t.cancelled():
            return
        e = t.exception()
        if e is not None:
            self._rando_cle = (self.ident_partie, None, None, None)
            self._rando_publier("base_absente", f"base locale des rencontres non générée ({e}) : « Réparer le mod »",
                                logging.ERROR)
        else:
            self.log.info("Base locale des rencontres générée : %s", t.result())

    async def _suivre_rando(self, h) -> None:
        """Écrit le mélange dans la boîte v6 pour la sauvegarde liée ; sinon `valide` = 0 (le jeu retire le mélange).
        Changement de mélange : `valide` = 0, attente que le jeu publie les tables d'origine (générations 0), puis
        écriture des tables et de `valide` (§22). Jeu sans v6 ou sans le randomizer compilé : rien n'est écrit."""
        self._preparer_rando()
        if not self.zone.rando_disponible(h):
            if self.rando_melange is not None and self._rando_jeu != (self._instance, None):
                self._rando_jeu = (self._instance, None)
                self.log.warning("Randomizer de Yo-kai : jeu v%d sans table de mélange (patch du mod à mettre à jour) : "
                                 "Yo-kai d'origine", h.version)
            self._rando_fichier_local({"support": False})
            return
        # en-tête du mélange relu sur évènement seulement (§23) : instance, partie ou statut de la sauvegarde, mélange
        # voulu, passage sur le terrain ou terrain stable (le jeu publie gen_carte / gen_commune sur le terrain stable) ;
        # tous les TOURS_ATTENTE tours pendant l'écriture d'un mélange ; filet de sécurité sinon
        m = self.rando_melange
        voulu = m.generation if (m is not None and self.sauvegarde == "liee") else 0
        maintenant = time.monotonic()
        cle_lue = (self._instance, h.partie, h.ident_sauvegarde, self.sauvegarde, voulu, h.terrain_numero, h.stable)
        delai = TOURS_ATTENTE * self.periode if self._rando_attente else self.periode_filet
        if cle_lue == self._rando_lu_cle and maintenant - self._rando_lu_t < delai:
            return
        self._rando_lu_cle, self._rando_lu_t = cle_lue, maintenant
        brut = await self.zone.lire_rando_entete()
        e = bp.dec_rando_entete(brut)
        self._rando_attente = False
        if self._rando_jeu is None or self._rando_jeu[0] != self._instance:
            self._rando_jeu = (self._instance, bp.rando_compile(brut))
            if self.rando_melange is not None and not self._rando_jeu[1]:
                self.log.warning("Randomizer de Yo-kai absent du jeu installé (compilé sans) : Yo-kai d'origine")
        compile_ = self._rando_jeu[1]
        if compile_ and self.rando_melange is not None and self.rando_melange.par_rencontre and not (
                self.zone.rando_rencontre_disponible(h) and compile_ & bp.RANDO_PAR_RENCONTRE):
            # mélange par rencontre demandé, jeu v6-v9 : rien n'est écrit (jamais au-delà de sa zone), mélange retiré
            if self._rando_sans_p != self._instance:
                self._rando_sans_p = self._instance
                self.log.warning("Randomizer de Yo-kai : le jeu installé (v%d) ne connaît pas le mélange par "
                                 "rencontre (patch du mod à mettre à jour) : Yo-kai d'origine", h.version)
            compile_ = 0
        jeu = {"support": bool(compile_), "valide": e["valide"], "table_gen": e["table_gen"],
               "gen_carte": e["gen_carte"], "gen_commune": e["gen_commune"], "modifies": e["modifies"]}
        self._rando_fichier_local(jeu)
        if not compile_:
            return
        m = self.rando_melange
        voulu = m.generation if (m is not None and self.sauvegarde == "liee") else 0
        if voulu == 0:
            if e["valide"] != 0:
                await self.zone.ecrire_rando_valide(0)
                self._rando_attente = True
                self.log.info("Randomizer de Yo-kai : mélange retiré (sauvegarde %s)", self.sauvegarde)
            return
        if e["table_gen"] == voulu:
            if e["valide"] != voulu:
                await self.zone.ecrire_rando_valide(voulu)
                self._rando_attente = True
                self.log.info("Randomizer de Yo-kai : mélange %#010x réactivé", voulu)
            return
        # autres tables dans la boîte : d'abord les retirer du jeu
        maintenant = time.monotonic()
        self._rando_attente = True                          # retrait puis écriture : en-tête relu souvent
        if e["valide"] != 0:
            await self.zone.ecrire_rando_valide(0)
            self._rando_attente_t = maintenant
            return
        encore = {e["gen_carte"], e["gen_commune"]} - {0, bp.RANDO_GEN_AUCUNE, bp.RANDO_GEN_IGNOREE}
        if encore and e["table_gen"] != 0:
            if not self._rando_attente_t:
                self._rando_attente_t = maintenant
            if maintenant - self._rando_attente_t < ATTENTE_RETRAIT_RANDO * self.echelle:
                return
            self.log.warning("Randomizer de Yo-kai : l'ancien mélange (%s) n'a pas été retiré en %d s ; nouveau mélange "
                             "écrit quand même (une table déjà mélangée le garde jusqu'à son prochain chargement)",
                             ", ".join(f"{g:#x}" for g in sorted(encore)), ATTENTE_RETRAIT_RANDO)
        self._rando_attente_t = 0.0
        if m.par_rencontre:
            await self.zone.ecrire_rando_rencontre(m.entrees, m.especes, m.w, voulu, m.empreinte32)
            self.log.info("Randomizer de Yo-kai : mélange par rencontre %#010x écrit (%d places, %d espèces, %d "
                          "rencontres)", voulu, len(m.entrees), len(m.especes), len(m.w))
            return
        await self.zone.ecrire_rando(m.sigma, m.beta, m.w, voulu, m.empreinte32)
        self.log.info("Randomizer de Yo-kai : mélange %#010x écrit (%d espèces, %d bases, %d rencontres)", voulu,
                      len(m.sigma), len(m.beta), len(m.w))

    # ------------------------------------------------------------------------------ randomizer des boss (v7)
    def _boss_publier(self, statut: str, message: str, niveau: int = logging.INFO) -> None:
        if (statut, message) != (self.boss_statut, self.boss_message):
            self.boss_statut, self.boss_message = statut, message
            self.log.log(niveau, "Randomizer des boss : %s", message)
        self._boss_fichier_local()

    def _boss_fichier_local(self, jeu: dict | None = None) -> None:
        """`rando_boss.json` (tracker du lanceur) : réécrit quand le mélange, l'état ou ce que le jeu publie change."""
        etat = {"pret": "actif", "aucun": "aucun", "refuse": "refuse", "base_absente": "refuse"}.get(
            self.boss_statut, "attente")
        cle = (self.ident_partie, self.boss_statut, self.boss_message,
               None if self.boss_melange is None else self.boss_melange.generation,
               None if jeu is None else tuple(sorted(jeu.items())))
        if cle == self._boss_fichier:
            return
        self._boss_fichier = cle
        try:
            rboss.ecrire_fichier_local(self.stockage.dossier, self.boss_melange, self.ident_partie, etat,
                                       dict(jeu or {}, message=self.boss_message))
        except OSError as e:
            self.log.warning("rando_boss.json non écrit : %s", e)

    def _preparer_boss(self) -> None:
        """Mélange des boss de la graine, une fois par (partie, mode, graine). Base locale absente ou d'un format sans
        les scripts de combat (< 4) : générée en tâche de fond depuis la ROM configurée (même base que les Yo-kai)."""
        rb = self.catalogue.rando_boss
        cle = (self.ident_partie, None if rb is None else rb["mode"], None if rb is None else rb["graine"])
        if cle == self._boss_cle or (self._rando_tache is not None and not self._rando_tache.done()):
            return
        if rb is None:
            self._boss_cle, self.boss_melange = cle, None
            self._boss_publier("aucun", "pas de mélange des boss sur cette partie")
            return
        base = rando.charger_base(self.stockage.dossier)
        rom = self.config.rom
        if base is not None and base.get("format", 0) < rboss.FORMAT_BASE_BOSS and rom and Path(rom).is_file():
            base = None         # format antérieur (sans les scripts de combat) : régénérée depuis la ROM
        if base is None:
            if not rom or not Path(rom).is_file():
                self._boss_cle, self.boss_melange = cle, None
                self._boss_publier("base_absente", "base locale des rencontres absente : « Réparer le mod » dans le "
                                   "lanceur (ROM non configurée)", logging.WARNING)
                return
            self._boss_publier("calcul", "base locale des rencontres générée depuis la ROM…")
            self._rando_tache = asyncio.create_task(asyncio.to_thread(rando.generer_base, rom, self.stockage.dossier))
            self._rando_tache.add_done_callback(self._boss_generee)
            return
        self._boss_cle = cle
        try:
            self.boss_melange = rboss.calculer(base, rb["graine"], rb["mode"])
        except rboss.RandoBossImpossible as e:
            self.boss_melange = None
            self._boss_publier("refuse", f"mélange refusé : {e}", logging.ERROR)
            return
        m = self.boss_melange
        self._boss_publier("pret", f"mélange {m.mode} de la graine {m.graine} : {len(m.sigma)} boss à script déplacés "
                           f"({len(m.b)} places), {len(m.n)} boss sans script, empreinte {m.empreinte[:12]}")

    def _boss_generee(self, t: asyncio.Task) -> None:
        if t.cancelled():
            return
        e = t.exception()
        if e is not None:
            self._boss_cle = (self.ident_partie, None, None)
            self._boss_publier("base_absente", f"base locale des rencontres non générée ({e}) : « Réparer le mod »",
                               logging.ERROR)
        else:
            self.log.info("Base locale des rencontres générée : %s", t.result())

    async def _suivre_rando_boss(self, h) -> None:
        """Écrit le mélange des boss dans la boîte v7 pour la sauvegarde liée ; sinon `valide` = 0 (le jeu remet les
        places d'origine). Même protocole que le randomizer de Yo-kai (§22 / §24) : changement de mélange = retrait,
        attente des générations 0, puis tables et `valide`. Jeu sans v7 ou sans le randomizer des boss : rien.
        Charge GDB (§23) : en-tête relu sur les mêmes évènements que celui des Yo-kai ; sans mélange sur la partie et
        `valide` déjà lu à 0 pour cette instance du jeu : plus aucune lecture (sauf filet de sécurité)."""
        self._preparer_boss()
        if not self.zone.boss_disponible(h):
            if self.boss_melange is not None and self._boss_jeu != (self._instance, None):
                self._boss_jeu = (self._instance, None)
                self.log.warning("Randomizer des boss : jeu v%d sans table des boss (patch du mod à mettre à jour) : "
                                 "boss d'origine", h.version)
            self._boss_fichier_local({"support": False})
            return
        m = self.boss_melange
        voulu = m.generation if (m is not None and self.sauvegarde == "liee") else 0
        maintenant = time.monotonic()
        connu = self._boss_jeu is not None and self._boss_jeu[0] == self._instance
        if m is None and connu and self._boss_valide_lu == 0 and not self._boss_attente \
                and maintenant - self._boss_lu_t < self.periode_filet:
            return
        cle_lue = (self._instance, h.partie, h.ident_sauvegarde, self.sauvegarde, voulu, h.terrain_numero, h.stable)
        delai = TOURS_ATTENTE * self.periode if self._boss_attente else self.periode_filet
        if cle_lue == self._boss_lu_cle and maintenant - self._boss_lu_t < delai:
            return
        self._boss_lu_cle, self._boss_lu_t = cle_lue, maintenant
        brut = await self.zone.lire_boss_entete()
        e = bp.dec_boss_entete(brut)
        self._boss_attente = False
        self._boss_valide_lu = e["valide"]
        if not connu:
            self._boss_jeu = (self._instance, bp.boss_compile(brut))
            if self.boss_melange is not None and not self._boss_jeu[1]:
                self.log.warning("Randomizer des boss absent du jeu installé (compilé sans) : boss d'origine")
        compile_ = self._boss_jeu[1]
        jeu = {"support": bool(compile_), "valide": e["valide"], "table_gen": e["table_gen"],
               "gen_carte": e["gen_carte"], "gen_commune": e["gen_commune"], "places": e["places"],
               "especes": e["especes"], "erreurs": e["erreurs"], "manquants": e["manquants"]}
        self._boss_fichier_local(jeu)
        if not compile_:
            return
        if voulu == 0:
            if e["valide"] != 0:
                await self.zone.ecrire_boss_valide(0)
                self._boss_attente = True
                self._boss_valide_lu = 0
                self.log.info("Randomizer des boss : mélange retiré (sauvegarde %s)", self.sauvegarde)
            return
        if e["table_gen"] == voulu:
            if e["valide"] != voulu:
                await self.zone.ecrire_boss_valide(voulu)
                self._boss_attente = True
                self.log.info("Randomizer des boss : mélange %#010x réactivé", voulu)
            return
        # autres tables dans la boîte : d'abord les retirer du jeu
        self._boss_attente = True
        if e["valide"] != 0:
            await self.zone.ecrire_boss_valide(0)
            self._boss_attente_t = maintenant
            return
        encore = {e["gen_carte"], e["gen_commune"]} - {0, bp.RANDO_GEN_AUCUNE, bp.RANDO_GEN_IGNOREE}
        if encore and e["table_gen"] != 0:
            if not self._boss_attente_t:
                self._boss_attente_t = maintenant
            if maintenant - self._boss_attente_t < ATTENTE_RETRAIT_RANDO * self.echelle:
                return
            self.log.warning("Randomizer des boss : l'ancien mélange (%s) n'a pas été retiré en %d s ; nouveau mélange "
                             "écrit quand même (une table déjà modifiée le garde jusqu'à son prochain chargement)",
                             ", ".join(f"{g:#x}" for g in sorted(encore)), ATTENTE_RETRAIT_RANDO)
        self._boss_attente_t = 0.0
        await self.zone.ecrire_boss(m.b, m.n, voulu, m.empreinte32)
        self._boss_valide_lu = voulu
        self.log.info("Randomizer des boss : mélange %#010x écrit (%d places à script, %d boss sans script)", voulu,
                      len(m.b), len(m.n))

    # ------------------------------------------------------------------------------ suivi pour le tracker
    async def _suivre_tracker(self, h) -> None:
        """Fichiers du tracker de Yo-kai du lanceur, pour la SAUVEGARDE LIÉE seulement (docs/systemes/
        archipelago_rando_yokai.md §10.6) : `medaillium.json` (bits « vu » et « ami », une lecture groupée
        P+0x40C..0x643) et `progression.json` (chapitre, pas et progression de l'en-tête, rang de montre réel lu dans
        O = *(*0x0081521C + 0x10)). Relus sur évènement (§23) : tout de suite si la progression publiée change, sur un
        passage sur le terrain (fin de combat, de scène, de menu : au plus une fois par TOURS_TRACKER_MIN tours), et
        toutes les PERIODE_MEDAILLIUM secondes en filet ; en-tête et objet du rang relus APRÈS les données : tout est
        écarté si la partie a changé."""
        self._rafraichir_base()
        if self.sauvegarde != "liee" or not h.partie or not h.adresse_p:
            return
        maintenant = time.monotonic()
        publiee = (h.ident_sauvegarde, h.chapitre, h.pas_scenario, h.progression)
        ecoule = maintenant - self._medaillium_t
        if publiee == self._progression_suivi and ecoule < PERIODE_MEDAILLIUM * self.echelle \
                and (h.terrain_numero == self._terrain_suivi or ecoule < TOURS_TRACKER_MIN * self.periode):
            return
        self._medaillium_t = maintenant
        debut, taille = rando.LECTURE_MEDAILLIUM
        b = await self.pont.lire(h.adresse_p + debut, taille)
        o, rang = await self.boite.rang_montre(self._adresse_rang)
        if not await self._meme_partie(h):
            return
        if o is not None or self._adresse_rang is not None:
            apres = await self.boite.adresse_rang()
            if apres != o:
                self._adresse_rang = None                       # O déplacé (ou nul) : relu en entier au prochain tour
                return
        self._adresse_rang = o
        self._progression_suivi, self._terrain_suivi = publiee, h.terrain_numero
        await self._verifier_amis(h, b)
        cle = (h.ident_sauvegarde, b)
        if cle != self._medaillium:
            try:
                rando.ecrire_medaillium(self.stockage.dossier, self.ident_partie, b, h.ident_sauvegarde)
                self._medaillium = cle
            except OSError as ex:
                self.log.warning("medaillium.json non écrit : %s", ex)
        connu = bool(h.progression & bp.PROGRESSION_CHAPITRE)
        prog = {"ident_sauvegarde": h.ident_sauvegarde,
                "chapitre": h.chapitre if connu else None, "pas_scenario": h.pas_scenario if connu else None,
                "phase": h.chapitre * 10000 + h.pas_scenario if connu else None,
                "rang_montre": rang, "apres_jeu": bool(h.progression & bp.PROGRESSION_VICTOIRE)}
        cle = tuple(sorted(prog.items()))
        if cle != self._progression_fichier:
            try:
                rando.ecrire_progression(self.stockage.dossier, self.ident_partie, prog)
                self._progression_fichier = cle
            except OSError as ex:
                self.log.warning("progression.json non écrit : %s", ex)

    def _rafraichir_base(self) -> None:
        """Base locale d'un format antérieur (n° du Médaillium faux, lieux sans condition décodée) : régénérée en tâche
        de fond depuis la ROM configurée, une fois par session (le mélange, calculé sur W, D, F, reste identique)."""
        if self._base_rafraichie or (self._rando_tache is not None and not self._rando_tache.done()):
            return
        self._base_rafraichie = True
        rom = self.config.rom
        if not rom or not Path(rom).is_file() or not rando.base_a_refaire(self.stockage.dossier):
            return
        self.log.info("Base locale des rencontres d'un format antérieur : régénération depuis la ROM")
        self._rando_tache = asyncio.create_task(asyncio.to_thread(rando.generer_base, rom, self.stockage.dossier))
        self._rando_tache.add_done_callback(self._base_regeneree)

    def _base_regeneree(self, t: asyncio.Task) -> None:
        if t.cancelled():
            return
        e = t.exception()
        if e is not None:
            self.log.warning("Base locale des rencontres non régénérée (%s) : l'ancienne reste utilisée", e)
        else:
            self.log.info("Base locale des rencontres régénérée : %s", t.result())

    # ------------------------------------------------------------------------------ partie chargée
    async def _meme_partie(self, h) -> bool:
        """Relit l'en-tête APRÈS une lecture de données (journal, bits, progression) : si la partie a changé
        entre-temps (autre sauvegarde chargée, retour au titre), les données lues sont écartées."""
        h2 = await self.boite.detecter()
        return (h2 is not None and h2.partie == h.partie and h2.adresse_p == h.adresse_p
                and h2.ident_sauvegarde == h.ident_sauvegarde)

    def _oublier_sauvegarde(self) -> None:
        self.sauvegarde = "aucune"
        self._boutiques_faites = None
        self._liaison = None
        self._demande = None
        self._eval_cle = None
        self.raison_non_liee = ""

    def _indices_ap(self) -> set[int]:
        return set(self.catalogue.coffres.values()) | set(self.catalogue.spots)

    async def _lire_bits(self, h) -> tuple[set[int], set[int], set[int] | None, set[int]] | None:
        """Bits persistants de la partie chargée : (index TBox posés, flags de boss de la graine posés, quêtes de
        boss de la graine terminées, flags « Yo-kai appelé » des Tablo-blabla de la graine posés), lus puis validés
        par une relecture de l'adresse de Q (boss de quête) et de l'en-tête (`_meme_partie`) ; None sans partie ou si
        la partie a changé. Flags (boss, secours, Tablo-blabla : P+4+14 .. P+4+269 au plus, un paquet) et phases de
        quête : une lecture groupée chacun, aucune si la graine n'en a pas ; flags et TBox dans le même paquet quand ils y
        tiennent (`Boite.bits_partie`, §23). Q validé par la relecture précédente : chaînage relu après seulement. Q
        illisible (maillon nul ou hors du tas) : quêtes None (« inconnues »), sans bloquer les coffres ni les boss."""
        boss: set[int] | None = set()
        tablos: set[int] = set()
        secours = self._secours()
        seuls: set[int] = set()
        # une seule lecture groupée : flags TBox, flags des boss, flags « évènement vu » de la détection de secours et
        # flags « Yo-kai appelé » des Tablo-blabla
        flags = set(self.catalogue.boss.values()) | set(secours.values()) | set(self.catalogue.tablos.values())
        # boss détectés par un octet global (pseudo-flags) : les 8 flags bit de l'octet, dans la même lecture
        pseudos = {f for f in self.catalogue.boss.values() if bp.boss_octet_decode(f) is not None}
        for f in pseudos:
            flags |= set(bp.boss_octet_flags(bp.boss_octet_decode(f)[0]))
        flags -= pseudos
        if self.catalogue.criminels or self.catalogue.boutiques:
            # + octets des Yo-criminels et des bits de boutique, dans le même regroupement (un paquet, §23)
            lu_p = await self.boite.partie_groupee(h, flags, bool(self.catalogue.criminels),
                                                   bool(self.catalogue.boutiques))
            octets_boutiques = self.boite.octets_boutiques
        else:
            octets_boutiques = b""
            lu = await self.boite.bits_partie(h, flags)
            lu_p = None if lu is None else (*lu, b"")
        if lu_p is None:
            return None
        ouverts, poses, octets_criminels = lu_p
        # Yo-criminels : arrêté quand l'octet `wantedNN` atteint le nombre d'étapes (dans le même paquet)
        arretes = {n for n, e in self.catalogue.criminels.values()
                   if len(octets_criminels) >= n and octets_criminels[n - 1] >= e}
        if self.catalogue.boss or secours or self.catalogue.tablos:
            boss = (poses & set(self.catalogue.boss.values())) | bp.boss_octets_atteints(pseudos, poses)
            tablos = poses & set(self.catalogue.tablos.values())
            # don d'un spot fait sans table (bit jamais posé) : l'évènement joué juste après le don fait foi
            seuls = {bit for bit, f in secours.items() if f in poses and bit not in ouverts}
            ouverts = ouverts | seuls
        quetes: set[int] | None = set()
        if self.catalogue.quetes:
            lu = await self.boite.quetes_terminees(h, self.catalogue.quetes.values(), self._adresse_q)
            if lu is None:
                self.log.debug("Bloc des quêtes illisible (Q nul ou hors du tas) : quêtes relues plus tard")
                quetes = None
            else:
                adresse_q, quetes = lu
                apres = await self.boite.adresse_quetes()
                if apres != adresse_q:
                    self._adresse_q = None                   # Q déplacé : données écartées, chaînage relu en entier
                    return None
                self._adresse_q = adresse_q
        if not await self._meme_partie(h):
            return None
        self._secours_seuls = seuls
        self._criminels_arretes = arretes
        self._boutiques_bits = bp.bits_boutiques(octets_boutiques) if octets_boutiques else set()
        return ouverts, boss, quetes, tablos

    def _secours(self) -> dict[int, int]:
        """Détection de secours (`bp.SPOTS_SECOURS`) des spots de la graine : bit de spot -> flag « évènement vu »."""
        return {bit: f for bit, f in bp.SPOTS_SECOURS.items() if bit in self.catalogue.spots}

    async def _evaluer_sauvegarde(self, h) -> str:
        """Statut de la sauvegarde chargée (règle v4) : `liee` seulement si P+0x3BC == ident_partie. Une
        sauvegarde SANS identifiant n'est liée que si c'est une PARTIE NEUVE (liaison automatique) ; la liaison manuelle
        n'existe plus (décision de l'humain du 2026-09-28, option (b)) : une sauvegarde existante reste « non liée »,
        le joueur commence une nouvelle partie."""
        ident = self.ident_partie
        if h.ident_sauvegarde == ident:
            return "liee"
        if h.ident_sauvegarde:
            return "autre"
        if h.version < bp.VERSION_LIAISON:
            return "jeu_ancien"                          # un jeu v3 ne sait pas lier sans risque
        d = self._demande
        if d is not None and h.liaison_demande == d[2] and h.terrain_numero == d[0]:
            return "liaison"                             # le jeu la traitera au terrain stable
        if not h.stable:
            # décision seulement sur le terrain stable (une nouvelle partie n'est pas encore « non liée »)
            return "non_liee" if self.sauvegarde == "non_liee" else "attente"
        cle_eval = (h.terrain_numero, h.compteur, h.chapitre, h.pas_scenario, h.progression, h.spots)
        if cle_eval == self._eval_cle:
            return "non_liee"
        bits = await self._lire_bits(h)
        if bits is None:
            return "non_liee"
        ouverts, boss, quetes, tablos = bits
        seuls = set(self._secours_seuls)
        self._eval_cle = cle_eval
        indices = self._indices_ap()
        # critères de partie neuve sur les bits RÉELS : un Filet donné sans table dans une partie neuve (chapitre 1,
        # client coupé) n'empêche pas la liaison automatique, et son check est envoyé après elle (G1-3)
        raison = raison_non_neuve(h, ouverts - seuls, indices, boss, quetes or (), tablos)
        if raison is None:
            cle = secrets.randbelow(0x7FFF) + 1           # partie neuve : aucune quête finie avant la liaison
            l = Liaison((ouverts - seuls) & indices, h.progression & VICTOIRE, False, "auto", set(boss),
                        set(quetes or ()), set(), set(tablos), self._numeros_quetes())
            self.log.info("Nouvelle partie détectée : liaison automatique à la partie AP %#010x", ident)
        else:
            self.raison_non_liee = raison
            self.log.info("Sauvegarde non liée à la partie AP (%s) : rien n'est livré ni envoyé ; une partie "
                          "Archipelago se joue sur une nouvelle partie", raison)
            return "non_liee"
        self.liaisons.ecrire(ident, cle, l)              # instantané enregistré AVANT la demande
        n = await self.boite.demander_liaison(h.terrain_numero, cle)
        self._demande = (h.terrain_numero, cle, n)
        self.stats.liaisons += 1
        return "liaison"

    async def _charger_liaison(self, h) -> Liaison | None:
        """Instantané de la sauvegarde liée chargée ; sans instantané enregistré (autre ordinateur, sauvegarde
        marquée par un ancien client, clé manuelle d'une version antérieure : la liaison manuelle n'existe plus depuis
        le 2026-09-28 mais ces sauvegardes restent liées, règle G1-2), celui de la première vue : ce qui est déjà ouvert ou
        gagné maintenant ne compte pas (seule une clé automatique v4, partie neuve, en est dispensée)."""
        ident, cle = self.ident_partie, h.liaison_sauvegarde
        l = self.liaisons.lire(ident, cle)
        if l is not None and (l.manuelle or cle & bp.LIAISON_MANUELLE):
            return self._liaison_manuelle(l, cle)
        if l is None and cle & bp.LIAISON_MANUELLE:
            # liaison manuelle sans instantané (autre ordinateur, fichier perdu) : même règle qu'à la liaison (G1-2) ;
            # la victoire déjà présente à cette première vue ne compte pas (on ne sait pas si elle suit la liaison)
            l = self._liaison_manuelle_vide(h)
            self.log.warning("Sauvegarde liée manuellement sans instantané (clé %#06x) : checks déjà faits envoyés%s",
                             cle, " ; victoire déjà acquise ignorée" if l.progression else "")
            self.liaisons.ecrire(ident, cle, l)
            return l
        if l is not None and l.boss is not None and l.quetes is not None and l.secours is not None \
                and l.tablos is not None:
            return await self._couvrir_quetes(h, l, cle)
        if l is not None:
            # instantané pris par un client sans boss (ou sans boss de quête) : même règle qu'un instantané absent
            # (§11.3), pour la partie manquante seulement. Liaison automatique = partie neuve (chapitre 1) : aucun
            # boss vaincu ni aucune quête finie avant elle ; sinon, première vue.
            if l.origine == "auto" and not l.manuelle:
                l.boss = set() if l.boss is None else l.boss
                l.quetes = set() if l.quetes is None else l.quetes
                l.secours = set() if l.secours is None else l.secours
                l.tablos = set() if l.tablos is None else l.tablos
            else:
                bits = await self._lire_bits(h)
                if bits is None:
                    return None
                if l.boss is None:
                    l.boss = set(bits[1])
                    self.log.warning("Instantané sans boss (clé %#06x) : %d boss déjà vaincu(s) à la première vue ne "
                                     "compteront pas", cle, len(l.boss))
                if l.quetes is None and bits[2] is not None:  # Q illisible : complété par _resynchroniser
                    l.quetes = set(bits[2])
                    self.log.warning("Instantané sans boss de quête (clé %#06x) : %d quête(s) déjà terminée(s) à la "
                                     "première vue ne compteront pas", cle, len(l.quetes))
                if l.tablos is None:
                    l.tablos = set(bits[3])
                    if l.tablos:
                        self.log.warning("Instantané sans Tablo-blabla (clé %#06x) : %d Yo-kai déjà appelé(s) à la "
                                         "première vue ne compteront pas", cle, len(l.tablos))
                if l.secours is None:
                    l.secours = self._secours_seuls & self._indices_ap()
                    if l.secours:
                        self.log.warning("Instantané sans détection de secours (clé %#06x) : %d don(s) de spot faits "
                                         "sans table à la première vue ne compteront pas", cle, len(l.secours))
        elif cle and not cle & bp.LIAISON_MANUELLE:
            l = Liaison(set(), 0, False, "auto", set(), set(), set(), set(), self._numeros_quetes())
        else:
            bits = await self._lire_bits(h)
            if bits is None:
                return None
            ouverts, boss, quetes, tablos = bits
            l = Liaison(ouverts & self._indices_ap(), h.progression & VICTOIRE, bool(cle), "premiere_vue", set(boss),
                        None if quetes is None else set(quetes), self._secours_seuls & self._indices_ap(), set(tablos),
                        None if quetes is None else self._numeros_quetes())
            self.log.warning("Sauvegarde liée sans instantané (clé %#06x) : %d coffre(s)/spot(s) déjà ouverts, %d "
                             "boss déjà vaincu(s), %d Tablo-blabla déjà appelé(s) et la victoire déjà acquise ne "
                             "compteront pas", cle, len(l.exclus), len(boss) + len(quetes or ()), len(tablos))
        self.liaisons.ecrire(ident, cle, l)
        return await self._couvrir_quetes(h, l, cle)

    def _liaison_manuelle_vide(self, h) -> Liaison:
        """Instantané d'une liaison MANUELLE (G1-2) : rien d'exclu, bits de victoire présents gardés."""
        return Liaison(set(), h.progression & VICTOIRE, True, "manuelle", set(), set(), set(), set(),
                       self._numeros_quetes())

    def _liaison_manuelle(self, l: Liaison, cle: int) -> Liaison:
        """Instantané d'une liaison manuelle relu : un instantané écrit par un client d'avant G1-2 excluait les
        checks déjà faits à la liaison ; ils sont remis en jeu (envoyés à la resynchronisation qui suit), la
        victoire déjà acquise reste ignorée (`progression` inchangée)."""
        exclus = (len(l.exclus_tous()), len(l.boss or ()), len(l.quetes or ()), len(l.tablos or ()))
        if any(exclus) or None in (l.boss, l.quetes, l.secours, l.tablos) or not l.manuelle \
                or l.quetes_couvertes != self._numeros_quetes():
            if any(exclus):
                self.log.warning("Liaison manuelle antérieure (clé %#06x) : %d coffre(s)/spot(s), %d boss, %d quête(s) "
                                 "et %d Tablo-blabla exclus jusqu'ici seront envoyés (G1-2)", cle, *exclus)
            l = Liaison(set(), l.progression, True, "manuelle", set(), set(), set(), set(), self._numeros_quetes())
            self.liaisons.ecrire(self.ident_partie, cle, l)
        return l

    def _numeros_quetes(self) -> set[int]:
        """N° des quêtes lues par ce client (boss de quête, requêtes, services de la graine)."""
        return set(self.catalogue.quetes.values())

    async def _couvrir_quetes(self, h, l: Liaison, cle: int) -> Liaison | None:
        """Instantané pris par un client qui ne lisait pas toutes les quêtes de la graine (avant les requêtes : seules
        les quêtes de boss) : les quêtes NON couvertes sont complétées comme un instantané absent (§11.3) — liaison
        automatique (partie neuve) : aucune quête finie avant elle ; sinon, première vue : celles déjà terminées
        maintenant ne compteront pas. Q illisible : complété plus tard (`_resynchroniser`)."""
        if l.quetes is None:
            return l
        couvertes = l.quetes_couvertes if l.quetes_couvertes is not None else set(self.catalogue.quetes_boss)
        manquantes = self._numeros_quetes() - couvertes
        if not manquantes and l.quetes_couvertes is not None:
            return l
        if manquantes and not (l.origine == "auto" and not l.manuelle):
            bits = await self._lire_bits(h)
            if bits is None:
                return None
            if bits[2] is None:
                return l                                     # Q illisible : relu plus tard
            deja = bits[2] & manquantes
            l.quetes = set(l.quetes) | deja
            if deja:
                self.log.warning("Instantané sans requêtes (clé %#06x) : %d quête(s) déjà terminée(s) à la première vue "
                                 "ne compteront pas", cle, len(deja))
        l.quetes_couvertes = couvertes | self._numeros_quetes()
        self.liaisons.ecrire(self.ident_partie, cle, l)
        return l

    async def _suivre_partie(self, h, brut: bytes) -> None:
        r = self.reseau
        if not h.partie:
            self._partie_cle = None
            self._oublier_sauvegarde()
            self._notif_sauvegarde = None
            await self._lire_journal(h, ignorer=True)
            return
        cle = (h.adresse_p, h.ident_sauvegarde, h.liaison_sauvegarde)
        if cle != self._partie_cle:
            self._partie_cle = cle
            self._oublier_sauvegarde()
            self._resync_demandee = True
            self._adresse_q = self._adresse_rang = None
            self._victoire_t = 0.0
            self._echecs_notifies.clear()
        # verrous exigés absents du jeu : aucune liaison, aucun don, aucun check (la partie n'est pas jouable)
        statut = "verrous_incompatibles" if self.verrous_manquants or self.boutiques_manquantes \
            else await self._evaluer_sauvegarde(h)
        if statut != self.sauvegarde:
            self.log.info("Sauvegarde chargée : %s (identifiant %#010x, attendu %#010x)", statut,
                          h.ident_sauvegarde, self.ident_partie)
            self.sauvegarde = statut
        if statut != "liee":
            if statut in NOTIF_SAUVEGARDE and self._notif_sauvegarde != (cle, statut):
                self._notif_sauvegarde = (cle, statut)
                textes = NOTIF_SAUVEGARDE[statut]
                for texte in (textes,) if isinstance(textes, str) else textes:
                    self._notifier(texte)
            await self._lire_journal(h, ignorer=True)    # rien n'est envoyé depuis cette sauvegarde
            return
        if self._liaison is None:
            self._liaison = await self._charger_liaison(h)
            if self._liaison is None:
                return
        maintenant = time.monotonic()
        # (dons : déposés en fin de tour, `_deposer_dons`, avec les autres écritures dans un seul arrêt)
        # journal ; spots publiés dans l'en-tête (bits 558..) : un changement déclenche la relecture
        if h.spots != self._spots_vus:
            self._spots_vus = h.spots
            self._resync_demandee = True
        # boss : la victoire pose le flag du combat, puis l'histoire avance (phase suivante) ; un changement de
        # chapitre ou de pas de scénario relit les flags sans attendre la resynchronisation périodique. Boss de
        # quête : la quête se termine par une scène ou un rapport suivi d'un retour sur le terrain
        # (`terrain_numero`) : ce changement relit aussi. Tablo-blabla : l'appel du Yo-kai (menu, puis scène du
        # territoire) se termine par un retour sur le terrain : même relecture. Tout passage sur le terrain relit
        # (évènement rare : fin de combat, de scène, de menu, changement de carte ; §23), la relecture périodique
        # n'est plus qu'un filet de sécurité (`periode_filet`)
        progression = (h.chapitre, h.pas_scenario, h.terrain_numero)
        if progression != self._progression_vue:
            self._progression_vue = progression
            self._resync_demandee = True
        await self._lire_journal(h)
        # resynchronisation par les bits persistants
        if self._resync_demandee or maintenant - self._resync_t > self.periode_filet:
            await self._resynchroniser(h)
        self._alerter_chapitre_10(h)
        # victoire : seulement si elle est apparue APRÈS la liaison (instantané)
        nouvelle_victoire = h.progression & VICTOIRE & ~self._liaison.progression
        if not self._victoire_envoyee and nouvelle_victoire:
            self._victoire_envoyee = True
            self.log.info("Victoire (progression %#x, chapitre %d) : CLIENT_GOAL", h.progression, h.chapitre)
            await r.signaler_victoire()
            self._notifier("Objectif atteint !")

    def _alerter_chapitre_10(self, h) -> None:
        """Bandeau « ville bouclée au chapitre 10, N checks à faire avant » dès la phase 9-80 (dernière promenade libre
        avant le chapitre 10), ou à la liaison d'une sauvegarde déjà au chapitre 10, une fois par sauvegarde liée, s'il reste des locations de `avant_chapitre_10` non vérifiées (serveur : manquantes, ni
        vérifiées ni en attente). Sauvegarde déjà victorieuse ou après-jeu (la ville est rouverte) : marqué sans bandeau.
        Appelé seulement pour une sauvegarde liée (mêmes garde-fous que les checks)."""
        l, r = self._liaison, self.reseau
        if l is None or r is None or l.alerte_ch10 or not self.catalogue.avant_chapitre_10:
            return
        if not h.progression & bp.PROGRESSION_CHAPITRE or (h.chapitre, h.pas_scenario) < SEUIL_ALERTE_CH10:
            return
        restants = set()
        if h.chapitre <= 10 and not h.progression & VICTOIRE:
            restants = ((self.catalogue.avant_chapitre_10 & r.locations_manquantes)
                        - r.locations_verifiees - r.locations_en_attente)
        l.alerte_ch10 = True
        self.liaisons.ecrire(self.ident_partie, h.liaison_sauvegarde, l)
        if not restants:
            return
        self.log.info("Chapitre %d-%d : %d check(s) hors chapitre 10 restent (ville bouclée de 10-10 à la fin)",
                      h.chapitre, h.pas_scenario, len(restants))
        textes = ALERTE_CHAPITRE_10.get(self.catalogue.langue, ALERTE_CHAPITRE_10["fr"])
        for t in textes:
            self._notifier(t.format(n=len(restants)))

    def _don_a_deposer(self, o: ObjetReseau) -> ObjetADonner:
        """Objet de ce monde trouvé à un spot NON substitué : le jeu l'a donné lui-même (DONNER), le rang est
        déposé comme « type 0 » (ignoré par le jeu, compteur avancé) pour ne pas le donner deux fois."""
        e = self.catalogue.emplacements.get(o.location)
        if e is not None and not e.substituer and self.reseau is not None and o.player == self.reseau.slot:
            return ObjetADonner(0, 0, 0)
        don = self.catalogue.don(o.item)
        if don.type == 0 and o.item in self.catalogue.objets_du_jeu:
            # invitation : son objet du jeu, s'il existe chez ce joueur (RomFS patché à l'installation) ; sinon le jeu
            # l'ignore (OBJET_INCONNU, compteur avancé) comme le « type 0 » d'avant. L'invité ne dépend pas de ce don.
            return ObjetADonner(bp.DON_OBJET, self.catalogue.objets_du_jeu[o.item], 1)
        return don

    async def _lire_journal(self, h, ignorer: bool = False) -> None:
        """Évènements non lus (index de lecture du CLIENT : `journal_lu` du jeu n'est écrit qu'avec une autre écriture,
        ou au plus tard après TOURS_ACQUITTEMENT tours, `_acquitter_journal` ; le jeu ne s'en sert que pour compter les
        évènements écrasés)."""
        lu = max(h.journal_lu, self._journal_lu)
        if h.journal_ecrit <= lu:
            return
        j = await self.boite.lire_journal(h, lu)
        if not ignorer and not await self._meme_partie(h):
            return                                       # relu au prochain tour, avec le bon en-tête
        if j.perdus:
            self.log.info("%d évènements du journal perdus : resynchronisation", j.perdus)
            self._resync_demandee = True
        if not ignorer:
            await self._traiter_evenements(h, j.evenements)
        self._journal_lu = j.ecrit
        if not self._acquitter_t:
            self._acquitter_t = time.monotonic()

    async def _acquitter_journal(self, h) -> None:
        """`journal_lu` = index de lecture du client : dans l'arrêt déjà pris par une autre écriture de ce tour, sinon
        au plus tard TOURS_ACQUITTEMENT tours après la lecture (ou quand le retard approche la capacité du journal)."""
        if not self._acquitter_t or self._journal_lu <= h.journal_lu:
            self._acquitter_t = 0.0
            return
        if self.pont.en_marche and time.monotonic() - self._acquitter_t < TOURS_ACQUITTEMENT * self.periode \
                and self._journal_lu - h.journal_lu < bp.CAP_JOURNAL // 2:
            return
        await self.boite.acquitter_journal(self._journal_lu)
        self._acquitter_t = 0.0

    async def _deposer_dons(self, h) -> None:
        """Dons reçus d'AP -> file de dons, pour la sauvegarde liée seulement (liaison chargée). Pré-vérification sans
        arrêt (`Boite.deposer_dons` avec l'en-tête du tour) : le jeu n'est arrêté que s'il y a vraiment à écrire."""
        if not (self._connexion_prete and self.reseau is not None and h.partie and self.sauvegarde == "liee"
                and self._liaison is not None):
            return
        maintenant = time.monotonic()
        a_livrer = len(self.objets) > h.compteur
        cle_depot = (self._instance, h.compteur, len(self.objets), h.ident_sauvegarde)
        if not a_livrer or (cle_depot == self._depot_cle and maintenant - self._depot_t <= self.periode_filet):
            return
        dons = [self._don_a_deposer(o) for o in self.objets]
        res = await self.boite.deposer_dons(dons, h)
        self._depot_cle, self._depot_t = cle_depot, maintenant
        if res.ecrits:
            self.stats.depots += len(res.ecrits)
            self.log.info("Dons déposés : %d (compteur %d, %d reçus)", len(res.ecrits), res.compteur, len(self.objets))
        if res.conflits:
            self.log.warning("Dons en attente au contenu différent (non touchés) : %s", res.conflits)

    async def _traiter_evenements(self, h, evts) -> None:
        index_loc = self.catalogue.index_vers_location
        exclus = self._liaison.exclus if self._liaison is not None else set()
        checks, dons = [], []
        bits_vus: set[int] = set()                       # bits d'articles de boutique montrés (évènements BOUTIQUE)
        for e in evts:
            if e.type == bp.EVT_COFFRE:
                idx = e.index_tbox
                loc = index_loc.get(idx) if idx is not None else None
                if loc is None and e.etiquette in self.catalogue.coffres:
                    loc = e.etiquette                    # étiquette de la table = identifiant de location
                # check immédiat seulement si le flag TBox vient d'être posé (0x01) ; un coffre doré est d'abord
                # « regardé » sans être ouvert (0x35EB(0), ev98_0070) puis marqué par 0x35F1 : son check vient
                # du bit persistant (resynchronisation), jamais d'un coffre resté fermé (excédent, combat)
                if loc is not None and e.drapeaux & bp.EVT_COFFRE_MARQUE_OUVERT \
                        and self.catalogue.coffres[loc] not in exclus:
                    checks.append(loc)
                self._resync_demandee = True
            elif e.type == bp.EVT_OBJET_JEU:
                self._resync_demandee = True             # don d'objet-clé substitué (J3) : bit à relire
            elif e.type == bp.EVT_RECOMPENSE:
                # récompense de quête remplacée (v5) : l'écran de résultat montre l'objet ; la quête vient de passer à
                # 255 (relecture) et l'objet de ce monde, livré ensuite par la file, n'a pas à être réannoncé
                if e.etiquette in self.catalogue.recompenses:
                    self._recompenses_montrees.add(e.etiquette)
                self._resync_demandee = True
            elif e.type == bp.EVT_ACHAT:
                # premier achat d'un article de boutique (v9) : check immédiat (le bit est posé, relu ensuite) ; l'objet
                # de ce monde montré, livré ensuite par la file, n'a pas à être réannoncé
                b = self.catalogue.boutiques.get(e.etiquette)
                if b is not None:
                    self._recompenses_montrees.add(e.etiquette)
                    l = self._liaison
                    if l is None or l.boutiques is None or b.bit not in l.boutiques:
                        checks.append(e.etiquette)
                self._resync_demandee = True
            elif e.type == bp.EVT_INVITE:
                # annonce d'un invité de l'Auberge fermée par le joueur : notée pour la sauvegarde (jamais remontrée)
                l = self._liaison
                if l is not None and e.valeur not in l.invites_annonces \
                        and any(inv.medaille == e.valeur for inv in self.catalogue.invites):
                    l.invites_annonces.add(e.valeur)
                    self.liaisons.ecrire(self.ident_partie, h.liaison_sauvegarde, l)
                    self.log.info("Invité de l'Auberge annoncé en jeu : n° %d du Médaillium", e.valeur)
            elif e.type == bp.EVT_INVITE_CHAMBRE:
                # le jeu a attribué une chambre à un invité : notée pour la sauvegarde (il la garde jusqu'à l'amitié,
                # d'un lancement à l'autre) ; la liste est réécrite avec elle au même tour
                l = self._liaison
                if l is not None and 0 < e.quantite < bp.INVITES_PIECES \
                        and l.invites_chambres.get(e.valeur) != e.quantite \
                        and any(inv.medaille == e.valeur and inv.param != bp.INVITES_PARAM_PNJ
                                for inv in self.catalogue.invites):
                    for m in [m for m, c in l.invites_chambres.items() if c == e.quantite]:
                        del l.invites_chambres[m]            # l'ancien occupant (devenu ami) a libéré la chambre
                    l.invites_chambres[e.valeur] = e.quantite
                    self.liaisons.ecrire(self.ident_partie, h.liaison_sauvegarde, l)
                    self.log.info("Invité de l'Auberge n° %d du Médaillium : chambre %d", e.valeur, 100 + e.quantite)
            elif e.type == bp.EVT_BOUTIQUE:
                bits_vus.update(bp.bits_evt_boutique(vars(e)))   # articles visibles d'une boutique ouverte (§10)
            elif e.type == bp.EVT_DON and (e.drapeaux == bp.CODE_OK or (
                    e.drapeaux in (bp.CODE_TYPE_INCONNU, bp.CODE_OBJET_INCONNU) and self._don_sans_objet(e.valeur))):
                dons.append(e.valeur)
            elif e.type == bp.EVT_DON_ECHEC and e.valeur not in self._echecs_notifies:
                self._echecs_notifies.add(e.valeur)
                self._notifier("Inventaire plein !")
        if checks:
            await self._envoyer_checks(checks)
        if bits_vus:
            self._indiquer_boutique(bits_vus)
        self._notifier_dons(dons)

    def _indiquer_boutique(self, bits: set[int]) -> None:
        """Évènements BOUTIQUE (v9, boutique ouverte, `archipelago_boutiques.md` §10) : indices « annoncés »
        (LocationScouts `create_as_hint` 2, le serveur n'annonce que les nouveaux) des articles que le jeu a réellement
        MONTRÉS à cette ouverture (bits publiés : ligne AP posée et condition d'affichage vraie ; jamais un article
        conditionnel encore caché), présents dans la graine et pas encore cochés (ni en attente, ni déjà indiqués, ni
        faits avant la liaison), une seule fois par article. Sauvegarde liée seulement (le journal d'une autre sauvegarde
        est ignoré ; revérifié ici)."""
        r, l = self.reseau, self._liaison
        if r is None or l is None or r.slot is None or not self._connexion_prete or self.sauvegarde != "liee":
            return
        locs = {loc for loc, x in self.catalogue.boutiques.items() if x.bit in bits}
        codes = sorted({self.catalogue.boutiques[loc].boutique or "?" for loc in locs})
        cle = (str(r.room_info.get("seed_name", "")), int(r.slot))
        deja = set()
        for h in r.indices:
            with contextlib.suppress(KeyError, TypeError, ValueError):
                if int(h.get("finding_player", -1)) == r.slot:
                    deja.add(int(h["location"]))
        faits = self._boutiques_bits | (l.boutiques or set())
        a_indiquer = sorted(loc for loc in locs
                            if loc in r.locations_manquantes and loc not in r.locations_verifiees
                            and loc not in r.locations_en_attente and loc not in deja
                            and (*cle, loc) not in self._indices_boutiques
                            and self.catalogue.boutiques[loc].bit not in faits)
        if not a_indiquer:
            return
        self._indices_boutiques |= {(*cle, loc) for loc in a_indiquer}
        self._lancer(self._envoyer_indices_boutique(r, cle, a_indiquer, "/".join(codes)))

    async def _envoyer_indices_boutique(self, r: ClientAP, cle: tuple[str, int], locs: list[int],
                                        code: str) -> None:
        try:
            await r.scouter(locs, create_as_hint=2)
        except Exception as e:                               # déconnexion : redemandés à la prochaine ouverture
            self._indices_boutiques -= {(*cle, loc) for loc in locs}
            self.log.info("Indices de la boutique %s non créés : %s", code, e)
            return
        self.log.info("Indices de la boutique %s : %d article(s) %s", code, len(locs), locs)

    def _don_sans_objet(self, numero: int) -> bool:
        """Don n° `numero` (1 = premier de ReceivedItems) d'un objet AP connu SANS objet du jeu (don « aucun » : Rang
        de montre, verrou progressif) : le jeu l'ignore (TYPE_INCONNU) mais il est bien reçu, donc annoncé. Une
        invitation (don « aucun », objet du jeu facultatif) dont l'objet n'existe pas chez ce joueur est ignorée de
        même (OBJET_INCONNU) et annoncée de même."""
        if not 1 <= numero <= len(self.objets):
            return False
        o = self.catalogue.objets.get(self.objets[numero - 1].item)
        return o is not None and o.type == 0

    def _notifier_dons(self, numeros: list[int]) -> None:
        r = self.reseau
        spots = set(self.catalogue.spots.values()) | set(self.catalogue.emplacements)   # dons substitués (bit ou non)
        a_dire = []
        for n in numeros:
            if not 1 <= n <= len(self.objets):
                continue
            o = self.objets[n - 1]
            if o.player == r.slot and (o.location in self.catalogue.coffres or o.location in spots
                                       or o.location in self._recompenses_montrees):
                continue                                 # le coffre (don substitué, écran de résultat) l'a montré
            a_dire.append(o)
        if len(a_dire) > RESUME_AU_DELA:
            self._notifier(f"{len(a_dire)} objets reçus")
            return
        for o in a_dire:
            don = self.catalogue.don(o.item)
            joueur = r.nom_joueur(o.player) if o.player not in (0, r.slot) else None
            q = don.quantite if don.type == bp.DON_OBJET else 1
            self._notifier(texte_recu(r.nom_objet(o.item, r.slot), joueur, q))

    async def _resynchroniser(self, h) -> None:
        self._resync_demandee = False
        self._resync_t = time.monotonic()
        bits = await self._lire_bits(h)
        if bits is None:
            # lecture écartée (partie ou Q changés pendant la lecture) : réessayée au tour suivant, quelques fois
            self._resync_echecs += 1
            self._resync_demandee = self._resync_echecs <= ESSAIS_RELECTURE
            return
        self._resync_echecs = 0
        ouverts, boss, quetes, tablos = bits
        l = self._liaison
        if quetes is not None and l is not None and l.quetes is None:
            # instantané sans quêtes (Q illisible à la liaison) : complété à la première lecture réussie de Q, rien
            # n'est envoyé pour les quêtes déjà finies à ce moment (règle de la première vue)
            l.quetes = set(quetes)
            l.quetes_couvertes = self._numeros_quetes()
            self.liaisons.ecrire(self.ident_partie, h.liaison_sauvegarde, l)
            self.log.warning("Instantané des quêtes complété : %d quête(s) déjà terminée(s) ne compteront pas",
                             len(l.quetes))
        if quetes is not None and l is not None and l.quetes:
            # service déjà terminé à la liaison : son 255 est TRANSITOIRE (remis à 0 par le tirage des services,
            # archipelago_quetes.md §2.5) et le service revient ; vu à une autre phase, il sort de l'instantané (le
            # refaire comptera)
            leves = {n for n in l.quetes & self.catalogue.services if n not in quetes}
            if leves:
                l.quetes = set(l.quetes) - leves
                self.liaisons.ecrire(self.ident_partie, h.liaison_sauvegarde, l)
                self.log.info("Service(s) %s de l'instantané remis en jeu par le jeu : ils compteront", sorted(leves))
        exclus = l.exclus_tous() if l is not None else set()
        boss_exclus = (l.boss if l is not None else None) or set()
        quetes_exclues = (l.quetes if l is not None else None) or set()
        tablos_exclus = (l.tablos if l is not None else None) or set()
        checks = [loc for loc, idx in self.catalogue.coffres.items() if idx in ouverts and idx not in exclus]
        checks += [loc for bit, loc in self.catalogue.spots.items() if bit in ouverts and bit not in exclus]
        checks += [loc for loc, f in self.catalogue.boss.items() if f in boss and f not in boss_exclus]
        if quetes is not None:
            checks += [loc for loc, n in self.catalogue.quetes.items() if n in quetes and n not in quetes_exclues]
        checks += [loc for loc, f in self.catalogue.tablos.items() if f in tablos and f not in tablos_exclus]
        if self.catalogue.criminels and l is not None:
            criminels_exclus = self._completer_instantane(h, l, "criminels", self._criminels_arretes)
            checks += [loc for loc, (n, _e) in self.catalogue.criminels.items()
                       if n in self._criminels_arretes and n not in criminels_exclus]
        if self.catalogue.boutiques and l is not None:
            # boutiques : bit « premier achat fait » (octets de flags globaux, même paquet que la TBox)
            boutiques_exclues = self._completer_instantane(h, l, "boutiques", self._boutiques_bits)
            checks += [loc for loc, b in self.catalogue.boutiques.items()
                       if b.bit in self._boutiques_bits and b.bit not in boutiques_exclues]
        await self._envoyer_checks(checks)

    def _completer_instantane(self, h, l: Liaison, champ: str, deja: set[int]) -> set[int]:
        """Instantané `amis` / `criminels` de la liaison (exclus) ; absent (liaison prise par un client sans ces checks) :
        complété maintenant, vide pour une liaison automatique (partie neuve : rien de fait avant) ou manuelle (G1-2 : ce
        qui est déjà fait est envoyé), sinon (première vue) ce qui est déjà fait maintenant, qui ne comptera pas."""
        v = getattr(l, champ)
        if v is None:
            v = set(deja) if l.origine == "premiere_vue" and not l.manuelle else set()
            setattr(l, champ, v)
            self.liaisons.ecrire(self.ident_partie, h.liaison_sauvegarde, l)
            if v:
                self.log.warning("Instantané sans %s (clé %#06x) : %d déjà fait(s) à la première vue ne compteront pas",
                                 champ, h.liaison_sauvegarde, len(v))
        return v

    async def _verifier_amis(self, h, octets: bytes) -> None:
        """Checks « Ami : <Yo-kai> » : bits « ami » (P+0x44C | P+0x604) de la lecture groupée du Médaillium que le suivi du
        tracker vient de faire et de valider (sauvegarde liée, partie inchangée : `_suivre_tracker`) ; aucun paquet GDB."""
        l = self._liaison
        if not (self.catalogue.amis or self.catalogue.invites) or l is None or self.reseau is None:
            return
        ami = rando.zones_medaillium(octets).get("ami") or b""
        if len(ami) < rando.TAILLE_MEDAILLIUM:
            return
        paires = self.catalogue.amis_paires or list(self.catalogue.amis.items())
        # invités de l'Auberge des voyageurs : même bit « ami », même instantané de liaison
        paires = paires + [(inv.location, inv.medaille) for inv in self.catalogue.invites]
        poses = {n for n in {n for _loc, n in paires} if ami[n >> 3] >> (n & 7) & 1}
        exclus = self._completer_instantane(h, l, "amis", poses)
        await self._envoyer_checks(sorted({loc for loc, n in paires if n in poses and n not in exclus}))

    async def _envoyer_checks(self, locations: Iterable[int]) -> None:
        """LocationChecks des nouvelles locations ; notification « Envoyé : <objet> (<joueur>) » pour celles qui
        contiennent l'objet d'un autre monde (résumé au-delà de quelques-unes)."""
        r = self.reseau
        nouvelles = {int(x) for x in locations} - r.locations_verifiees - r.locations_en_attente
        if not nouvelles:
            return
        self.stats.checks_envoyes += len(nouvelles)
        self.log.info("Checks : %s", sorted(nouvelles))
        await r.verifier_locations(nouvelles)
        self._maj_checks()
        eligibles = self.catalogue.locations_anim()
        lot = sorted(loc for loc in nouvelles if loc in eligibles)
        if len(lot) > ao.LOT_MAX:
            # rattrapage (liaison d'une sauvegarde déjà avancée, client absent longtemps) : pas une file de fenêtres
            # à fermer une à une, le bandeau « Envoyé : … » suffit
            self.log.info("Fenêtres « objet obtenu » non montrées : %d checks concernés d'un coup (rattrapage)", len(lot))
            lot = []
        ajoutees = self.anims.ajouter(lot)
        if ajoutees:
            self.log.info("Fenêtre « objet obtenu » à montrer dans le jeu : %s", ajoutees)
        envois = [self._scout[loc] for loc in sorted(nouvelles)
                  if loc in self._scout and self._scout[loc].player != r.slot]
        if len(envois) > RESUME_AU_DELA:
            self._notifier(f"{len(envois)} objets envoyés")
            return
        for o in envois:
            self._notifier(texte_envoye(r.nom_objet(o.item, o.player), r.nom_joueur(o.player)))

    # ------------------------------------------------------------------------------ onglet « Checks » du lanceur
    def _contenu_scout(self, o: ObjetReseau) -> dict:
        r = self.reseau
        return {"objet": r.nom_objet(o.item, o.player), "joueur": r.nom_joueur(o.player), "soi": o.player == r.slot,
                "flags": o.flags}

    def _indices_du_monde(self) -> dict[int, dict]:
        """Indices (hints) du serveur qui portent sur une location de CE monde : location -> contenu indiqué."""
        r = self.reseau
        out: dict[int, dict] = {}
        for h in r.indices:
            try:
                if int(h.get("finding_player", -1)) != r.slot:
                    continue
                dest = int(h["receiving_player"])
                out[int(h["location"])] = {"objet": r.nom_objet(int(h["item"]), dest), "joueur": r.nom_joueur(dest),
                                           "soi": dest == r.slot, "trouve": bool(h.get("found")),
                                           "flags": int(h.get("item_flags", 0) or 0)}
            except (KeyError, TypeError, ValueError):
                continue
        return out

    def _donnees_checks(self, connecte: bool | None = None) -> dict | None:
        r = self.reseau
        if r is None or not self._connexion_prete or r.slot is None:
            return None
        toutes = r.locations_manquantes | r.locations_verifiees
        faites = r.locations_verifiees | (r.locations_en_attente & toutes)
        recus = [{"n": i + 1, "id": o.item, "objet": r.nom_objet(o.item, r.slot), "expediteur": r.nom_joueur(o.player),
                  "soi": o.player == r.slot,
                  "location": r.nom_location(o.location, o.player) if o.location >= 0 else "", "flags": o.flags}
                 for i, o in enumerate(self.objets)]
        return ck.construire_checks(
            ident_partie=self.ident_partie, graine=str(r.room_info.get("seed_name", "")), slot=r.slot, team=r.team,
            joueur=r.nom_joueur(r.slot), options=ck.options_de_slot_data(r.slot_data), locations=toutes, faites=faites,
            contenus={l: self._contenu_scout(o) for l, o in self._scout.items()}, indices=self._indices_du_monde(),
            recus=recus, connecte=r.connecte if connecte is None else connecte,
            contenus_complets=self._scout_fait and toutes <= set(self._scout))

    def _maj_checks(self, connecte: bool | None = None) -> None:
        """`checks.json` pour le lanceur : réécrit seulement s'il a changé (fichier local, aucun paquet GDB)."""
        try:
            d = self._donnees_checks(connecte)
            if d is not None:
                self._checks_empreinte = ck.ecrire_checks(self.stockage.dossier, d, self._checks_empreinte)
        except OSError as e:
            self.log.warning("checks.json non écrit : %s", e)

    def suivre_demande_spoiler(self) -> bool:
        """Demande du lanceur (`spoiler_demande.json`) : spoiler log `.txt` de toutes les locations du slot (contenu
        des LocationScouts), puis réponse (`spoiler_reponse.json`). True si une demande a été traitée."""
        dossier = self.stockage.dossier
        if not (dossier / ck.NOM_DEMANDE).is_file():
            return False
        d = ck.lire_json(dossier / ck.NOM_DEMANDE) or {}
        nonce = str(d.get("nonce", ""))[:64]
        r = self.reseau
        toutes = (r.locations_manquantes | r.locations_verifiees) if r is not None else set()
        if r is None or not self._connexion_prete or not self._scout_fait or not toutes <= set(self._scout):
            ck.repondre(dossier, nonce, False, erreur="pas_de_donnees")
            self.log.info("Spoiler log demandé : contenu des locations pas encore reçu du serveur")
            return True
        langue = d.get("langue") if d.get("langue") in ("fr", "en") else "fr"
        texte = ck.texte_spoiler(
            langue=langue, graine=str(r.room_info.get("seed_name", "")), joueur=r.nom_joueur(r.slot), slot=r.slot,
            options=ck.options_de_slot_data(r.slot_data), locations=toutes,
            faites=r.locations_verifiees | (r.locations_en_attente & toutes),
            contenus={l: self._contenu_scout(o) for l, o in self._scout.items()},
            noms_serveur={l: r.nom_location(l, r.slot) for l in toutes})
        f = ck.ecrire_spoiler(dossier, texte)
        ck.repondre(dossier, nonce, True, f)
        self.log.info("Spoiler log écrit à la demande du lanceur (%d locations)", len(toutes))
        return True

    # ------------------------------------------------------------------------------ DeathLink (§25)
    def _maj_tag_deathlink(self) -> None:
        """Tag « DeathLink » = option du slot ET jeu attaché qui compile le DeathLink (sans jeu : on ne peut ni mourir
        ni envoyer sa mort)."""
        r, voulu = self.reseau, self.deathlink.tag
        if r is None or not self._deja_connecte or voulu == self._tag_deathlink:
            return
        self._tag_deathlink = voulu
        self.log.info("DeathLink %s", "activé (tag posé)" if voulu else "désactivé (tag retiré)")
        self._lancer(r.activer_deathlink(voulu))

    def _sur_deathlink(self, donnees: dict) -> None:
        r = self.reseau
        if r is None:
            return
        m = self.deathlink.recue(donnees, r.nom)
        if m is None:
            self.log.info("DeathLink de %s ignoré", donnees.get("source") or "?")
            return
        self.log.info("DeathLink reçu de %s (%s)", m.source, m.cause or "sans cause")
        self.reveiller()

    async def _suivre_deathlink(self, h) -> None:
        """DeathLink compilé dans le jeu (lu UNE fois par instance, seulement si l'option est active : aucune lecture de
        plus sinon) ; défaite réelle publiée dans l'en-tête (`defaites`) -> Bounce DeathLink."""
        d, r = self.deathlink, self.reseau
        if h.version < bp.VERSION_MORT or h.taille_zone < bp.OFF_MORT + bp.TAILLE_MORT:
            if d.jeu is None and d.option:
                self.log.warning("DeathLink : jeu v%d sans DeathLink (patch à mettre à jour) : option ignorée",
                                 h.version)
            d.jeu = False
        elif d.jeu is None and d.option:
            b = await self.pont.lire(bp.ZONE + bp.OFF_MORT, 0x10)
            c = bp.mort_compile(b)
            d.jeu, d.demande = bool(c), bp.lire_mort(b)["demande"]
            d.fenetre = bool(c) and bp.mort_fenetre(b)
            if not d.jeu:
                self.log.warning("DeathLink : absent de ce build du jeu (YKW2_AP_SANS_DEATHLINK) : option ignorée")
        self._maj_tag_deathlink()
        if h.version < bp.VERSION_MORT or not h.partie:
            return
        if d.defaites_vues(h.defaites, (h.adresse_p, h.ident_sauvegarde), self.sauvegarde == "liee") and r:
            cause = dl.texte_cause(r.nom, self.catalogue.langue)
            self.log.info("Défaite dans le jeu (%d depuis le lancement) : DeathLink envoyé (%s)", h.defaites, cause)
            self._lancer(r.envoyer_deathlink(cause))

    async def _ecrire_mort(self, h) -> None:
        """Mort reçue -> ApMort (identifiant de partie, puis numéro de demande EN DERNIER), sauvegarde liée seulement ;
        le jeu l'exécute au prochain moment sûr (combat : défaite forcée ; terrain : fenêtre « Vous êtes tombé...
        (DeathLink de <joueur>) » puis retour au point de reprise). Le nom du joueur à l'origine est écrit d'abord
        (ApMortFenetre.source), seulement pour un jeu qui compile la fenêtre (ces octets avaient un autre rôle avant)."""
        d = self.deathlink
        m = d.a_transmettre(bool(h.partie) and self.sauvegarde == "liee" and bool(self.ident_partie))
        if m is None:
            return
        n = d.prochaine_demande()
        async with self.pont.transaction():
            if d.fenetre and h.taille_zone >= bp.OFF_MORT_FENETRE + bp.TAILLE_MORT_FENETRE:
                await self.pont.ecrire(bp.ZONE + bp.OFF_MORT_FENETRE, bp.enc_mort_source(m.source))
            await self.pont.ecrire(bp.ZONE + bp.OFF_MORT + 8, struct.pack("<I", self.ident_partie & 0xFFFFFFFF))
            await self.pont.ecrire(bp.ZONE + bp.OFF_MORT + 4, struct.pack("<I", n))
        d.transmise()
        self.log.info("Mort liée demandée au jeu (demande %d) : %s", n, m.source)
        self._notifier(dl.texte_bandeau(m.source, self.catalogue.langue))

    # ------------------------------------------------------------------------------ fenêtres « objet obtenu » (§27)
    def _anim_compilee(self, h) -> bool:
        """Fonction 29 publiée par le jeu de cette instance (liste des verrous compilés, lue une fois par instance)."""
        if h.version < bp.VERSION_BOUTIQUES or h.taille_zone < bp.OFF_ANIM_TABLE + bp.CAP_ANIM * bp.TAILLE_ANIM:
            return False
        v = self._verrous_compiles
        return v is not None and v[0] == self._instance and bool((v[1] or 0) >> bp.FONCTION_ANIM & 1)

    def _anim_possible(self, h) -> bool:
        return (self.sauvegarde == "liee" and bool(h.partie) and bool(self.ident_partie) and self.anims.travail
                and self._anim_compilee(h))

    def _anim_entree(self, loc: int) -> tuple[int, bytes, int] | None:
        """(objet montré, 0 = la vitrine ; nom de la vitrine ; quantité) de la location, ou None si son contenu n'est
        pas encore connu (LocationScouts en cours)."""
        c = self._contenu(loc)
        if c is None:
            return None
        if c.hachage == self.catalogue.vitrine or not c.hachage:
            return 0, bp.nom_vitrine(c.texte) if c.texte else b"", 1
        return c.hachage, b"", 1

    async def _suivre_anims(self, h) -> None:
        """En-tête de la file des fenêtres (0x40 octets, un paquet) : seulement pendant qu'il y a du travail (voir
        `EtatAnims.besoin_lecture`)."""
        a = self.anims
        if not self._anim_possible(h):
            return
        a.tour()
        if not a.besoin_lecture():
            return
        entete = bp.dec_anim_entete(await self.pont.lire(bp.ZONE + bp.OFF_ANIM, 0x40))
        faites = a.lue(entete)
        if faites:
            self.log.info("Fenêtre(s) « objet obtenu » traitée(s) par le jeu : %s (montrées %d, écartées %d)", faites,
                          a.montrees, a.ecartees)

    async def _deposer_anims(self, h) -> None:
        """Entrées de la file des fenêtres (dans l'arrêt de fin de tour), puis `ecrites` EN DERNIER."""
        a = self.anims
        if not self._anim_possible(h) or not a.attente:
            return
        liste = a.a_ecrire(self._anim_entree, self.ident_partie)
        if not liste:
            return
        async with self.pont.transaction():
            for n, _loc, octets in liste:
                await self.pont.ecrire(bp.adr_anim(n), octets)
            await self.pont.ecrire(bp.ZONE + bp.OFF_ANIM, struct.pack("<I", liste[-1][0] & 0xFFFFFFFF))
        a.ecrites_faites(liste)
        self.log.info("Fenêtre(s) « objet obtenu » écrite(s) dans le jeu : %s", [loc for _n, loc, _o in liste])

    # ------------------------------------------------------------------------------ notifications
    def _notifier(self, texte: str) -> None:
        self.notifications.append(texte_court(texte))

    async def _deposer_notifications(self, h) -> None:
        """Notifications en attente -> file du jeu, toutes celles qui y tiennent, dans un seul arrêt (aucun si la file du
        jeu est pleine : places comptées jeu en marche)."""
        if not h.notifications:
            self.notifications.clear()
            return
        if not self.notifications:
            return
        n = await self.boite.deposer_notifications(list(self.notifications)[:bp.CAP_NOTIFS], h)
        for _ in range(n):
            self.notifications.popleft()
            self.stats.notifications += 1
