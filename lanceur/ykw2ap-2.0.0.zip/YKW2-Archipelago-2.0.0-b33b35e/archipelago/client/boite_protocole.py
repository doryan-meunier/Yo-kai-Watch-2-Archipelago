"""Protocole de la boîte aux lettres Archipelago (v9) : constantes, disposition, encodage des entrées et
règles de texte du bandeau. Module partagé, bibliothèque standard uniquement, sans dépendance :
- par le client du mod (`archipelago/client/boite.py`) ;
- par le client de test `tools/ap_boite_test.py` (qui vérifie dans son `--selftest` que ces constantes
  sont celles de `src/archipelago/boite.h`).
Référence : docs/systemes/archipelago_boite.md. Toute modification du format se fait dans boite.h, dans ce
module et dans la doc en même temps.
"""
from __future__ import annotations

import struct

# --- Protocole (doit correspondre à src/archipelago/boite.h ; vérifié par --selftest) ---
ZONE = 0x0091C000
TAILLE_ZONE = 0x24000         # v10 (0x20000 en v9, 0x16000 en v7/v8, 0x12000 en v6, 0xE000 en v5, 0xA000 en v3/v4, 0x4000 en v1/v2)
MAGIC = 0x50414B59            # "YKAP"
VERSION = 10                  # v10 : mélange des Yo-kai par rencontre (§22.4) ; v9 : boutiques (§26) ; v8 : DeathLink (§25) ; v7 : randomizer des boss (§24) ; v6 : randomizer de Yo-kai (§22) ; v5 : récompenses de quête (§21) ; v4 : liaison (§11.2)
OFF_DONS, CAP_DONS = 0x0100, 128
OFF_JOURNAL, CAP_JOURNAL = 0x0C00, 128
OFF_COFFRES, CAP_COFFRES = 0x1C00, 576
# Notifications (v2)
OFF_NOTIFS, CAP_NOTIFS, TAILLE_NOTIF, NOTIF_TEXTE = 0x0900, 8, 64, 56
OFF_NOTIFS_AUTO, CAP_NOTIFS_AUTO = 0x0B00, 8
OFF_NOTIF_TAMPON, TAILLE_TAMPON = 0x0B80, 128
POLITIQUE_REESSAYER, POLITIQUE_NOTIF_AUTO = 0x01, 0x02
NOTIF_BALISES = 0x01
NOTIF_ETAT_AFFICHAGE, NOTIF_ETAT_AUTO, NOTIF_ETAT_SUSPENDUE = 0x01, 0x02, 0x04
NOTIF_DUREE_DEFAUT = 120      # images (~4 s)
NOTIF_LARGEUR = 112           # largeur max estimée (demi-unités, bandeau mono-ligne ~121, voir la doc)
NOTIF_AUTO_TEXTE = 4
# v3 (docs/systemes/archipelago_boite.md §10 à §14)
OFF_CONFIG, TAILLE_CONFIG = 0x4000, 0x100            # configuration de connexion (écrite par le jeu)
OFF_CONNEXION, TAILLE_CONNEXION = 0x4100, 0x200      # état de connexion (écrit par le client)
OFF_SCRIPTS, CAP_SCRIPTS, TAILLE_SCRIPT = 0xDC40, 48, 16  # dons de script (J3) ; 0x4300 / 16 entrées jusqu'aux
#   objets-clés de quête (objets_cles_v11 §16) : le jeu publie offset et capacité (scripts_off, scripts_capacite)
OFF_SCRIPTS_V3, CAP_SCRIPTS_V3 = 0x4300, 16                # emplacement d'origine (présent dans toute zone v3 et plus)
OFF_VITRINE, OFF_PRIVE = 0x4400, 0x4500              # jeu seulement
OFF_VERROUS, CAP_VERROUS, TAILLE_VERROUS = 0x4F00, 24, 0x100   # verrous de capacité (J4, client)
# v4 (J4, §20) : verrous compilés dans le build (ApVerrous::compiles, écrit par le JEU en +4) ; bit 31 = liste publiée.
# Numéros k = spots : 0 Filet, 1 Pile ou passe (machine du tutoriel, déclencheurs de phase et de carte), 2 Clés de l'école, 3 Herbe ancestrale, 4 Super tournevis (V1.1), 5 Canne à pêche,
# 6 Modèle zéro, 7 Indications de Maman (V1.1), 10 Clé salle du trésor, 11 Poignée étrange (V1.1, déclencheurs de quête),
# 12 Vélo (V1.1, sans spot : réserve 570..575), 18 Rangs de montre (V1.1, objet PROGRESSIF sans spot : recu[18] = nombre
# d'exemplaires reçus, pas 0/1), 19 portes de montre D (MODE du verrou 18, archipelago_objets_cles_v11.md §14.8 : actif,
# rang AP = recu[18] et portes D fermées aussi ; inactif, rang AP = D + recu[18] ; recu[19] ignoré par le jeu),
# 20 rang de montre RÉEL (MODE du verrou 18, archipelago_objets_cles_v11.md §17 : actif, le jeu monte le vrai rang de
# la montre à min(recu[18], A) et ignore les montées de rang de ses scripts ; recu[20] ignoré par le jeu),
# 21 vélo RÉEL (MODE du verrou 12, archipelago_objets_cles_v11.md §15 bis : actif, le jeu donne vraiment le vélo à la
# réception du Vélo, flags 39 / 40 et objet vélo, et retire l'objet vélo de la boutique tant qu'il n'est pas reçu ;
# recu[21] ignoré par le jeu).
VERROUS_PUBLIES = 0x80000000
NOMS_VERROUS = {0: "Filet à insectes", 1: "Pile ou passe", 2: "Clés de l'école", 3: "Herbe ancestrale", 4: "Super tournevis",
                5: "Canne à pêche", 6: "Modèle zéro", 7: "Indications de Maman", 10: "Clé salle du trésor",
                11: "Poignée étrange", 12: "Vélo", 18: "Rang de montre", 19: "Rang de montre (portes D)",
                20: "Rang de montre (rang réel)", 21: "Vélo (vélo réel)",
                23: "Invités de l'Auberge des voyageurs",
                24: "Yo-criminels libres", 25: "Combats d'évènement libres",
                26: "Grelots d'eShop", 28: "Boutiques", 29: "Fenêtre « objet obtenu » des checks",
                30: "Yo-criminels trouvables", 22: "Fonctions étendues (client trop ancien)",
                32: "Ultramax N et K dans la même partie", 33: "Invités de l'Auberge à leur espèce"}
# Fonctions du patch SANS objet (bits 24.. de `compiles`, jamais dans `actifs` ; src/archipelago/verrous.h) : exigées
# par slot_data `fonctions_exigees` (format 14, archipelago_amis_criminels.md §6) ; absentes -> partie refusée comme un
# verrou manquant.
FONCTION_CRIMINELS_LIBRES = 24
FONCTION_COMBATS_LIBRES = 25
FONCTION_GRELOTS_ESHOP = 26
FONCTION_BOUTIQUES = 28      # articles de boutique Archipelago (boîte v9, §26 ; slot_data format 15)
FONCTIONS_CONNUES = frozenset({FONCTION_CRIMINELS_LIBRES, FONCTION_COMBATS_LIBRES, FONCTION_GRELOTS_ESHOP,
                               FONCTION_BOUTIQUES})
# Options du joueur appliquées par le code du jeu (ni verrou ni objet) : bit k de `compiles` (option compilée, écrit par
# le jeu) ET de `actifs` (option choisie dans la graine, écrit par le client) ; recu[k] n'existe pas (k >= 24). Les bits
# 24..26 et 28 sont les fonctions sans objet ci-dessus (FONCTIONS_CONNUES).
OPTION_BINGO_KAI = 27        # Bingo-kai infini (slot_data format 16, docs/systemes/archipelago_bingo_kai.md)
NOMS_OPTIONS = {OPTION_BINGO_KAI: "Bingo-kai infini"}
FLAG_BINGO_RESTANT = 0xA45A65EC   # octet global n° 16 : tours de Bingo-kai restant aujourd'hui (lu au moins 1 par le jeu)
VERROU_PILE = 1              # k de la Pile ou passe (spot 559) : verrou RETIRÉ du jeu le 2026-10-01 (objets_cles §14.9),
#                              jamais compilé ni exigé (synchro.VERROUS_SANS_CODE) ; gardé pour les noms
VERROU_CANNE = 5             # k de la Canne à pêche (spot 563) : flag 29 lu « Canne reçue » (objets_cles_v11 §19)
VERROU_MODELE_ZERO = 6       # k de la Modèle zéro (spot 564) : commande 0x3CEF (objets_cles_v11 §19.4)
VERROU_VELO = 12             # k du verrou du Vélo (bit TBox 570 de la réserve : jamais posé, aucun spot)
VERROU_RANGS = 18            # k du verrou des rangs de montre (réserve 18..23 : aucun spot)
VERROU_RANGS_D = 19          # mode « portes D » du verrou des rangs (graine récente : 4 exemplaires D, C, B, A)
VERROU_RANG_REEL = 20        # mode « rang réel » du verrou des rangs (slot_data format 20, objets_cles_v11 §17)
VERROU_VELO_REEL = 21        # mode « vélo réel » du verrou du Vélo (slot_data format 21, objets_cles_v11 §15 bis)
VERROUS_PROGRESSIFS = frozenset({VERROU_RANGS})   # recu[k] = compteur (le client y écrit le nombre reçu)
NB_COMPTEURS_VERROUS = 24    # diagnostic du jeu : k < 8 à +0x20 / +0x40, 8..15 à +0x68 / +0x88, 16..23 à +0xA8 / +0xC8
                             # (0 si jeu antérieur)
OFF_PARTAGE, TAILLE_PARTAGE = 0x5000, 0x1000         # page de l'applet clavier (jeu seulement)
OFF_NOMS, CAP_NOMS, TAILLE_NOM, NOM_TEXTE = 0x6000, 256, 64, 56   # noms de vitrine (J5)
# v5 (docs/systemes/archipelago_boite.md §21, archipelago_quetes.md §8) : récompenses de quête. En-tête (0x40 octets) :
# valide (C, écrit en dernier), compile (J : bit 31 publié, bit 0 substitution compilée), substitutions (J), derniere
# (J : n° | mode << 8) ; puis une entrée de 80 octets par n° de quête (index de Q + 4) : affiche, etiquette, drapeaux,
# utilisations (J), texte du nom de vitrine (56 octets).
VERSION_RECOMPENSES = 5
TAILLE_ZONE_V5 = 0xE000
OFF_QUETES, OFF_QUETES_TABLE, CAP_QUETES, TAILLE_QUETE, QUETE_TEXTE = 0xA000, 0xA040, 192, 80, 56
QUETE_VALIDE, QUETE_DONNER = 0x01, 0x02
QUETES_COMPILE, QUETES_PUBLIE = 0x01, 0x80000000
RECOMPENSE_FIXE, RECOMPENSE_CHOIX, RECOMPENSE_DONNE = 0x01, 0x02, 0x04
EVT_RECOMPENSE = 5
# v6 (docs/systemes/archipelago_boite.md §22, archipelago_rando_yokai.md) : randomizer de Yo-kai. En-tête (0x40 octets)
# à 0xE000 : valide (C, génération à appliquer, écrite en dernier), compile (J), table_gen (C), sigma_nombre / beta_nombre
# (C, u16), w_nombre (C), empreinte (C), gen_carte / gen_commune (J), compteurs (J) ; σ (paires u32 triées par origine),
# β (idem, bases), W (u32 triés). Écriture (jeu arrêté) : table_gen = 0, tables et nombres, table_gen, puis valide.
VERSION_RANDO = 6
TAILLE_ZONE_V6 = 0x12000
OFF_RANDO, OFF_RANDO_SIGMA, OFF_RANDO_BETA, OFF_RANDO_W = 0xE000, 0xE040, 0xE840, 0xF040
CAP_RANDO_SIGMA, CAP_RANDO_BETA, CAP_RANDO_W = 256, 256, 2048
OFF_RANDO_PRIVE, OFF_RANDO_MARQUES, CAP_RANDO_MARQUES = 0x11040, 0x11100, 0xF00
RANDO_PUBLIE, RANDO_RENCONTRES, RANDO_LOUPE = 0x80000000, 0x01, 0x02
# v10 (§22.4, archipelago_rando_yokai.md §11) : mélange PAR RENCONTRE (zone agrandie à 0x24000). En-tête : p_nombre
# (+0x3C, u16 ; 0 = mélange σ) et especes_nombre (+0x3E, u16). Table des espèces à 0x20000 ({u32 CHARA_PARAM, u32
# CHARA_BASE} par id), entrées P à 0x20800 (u32 triés par clé = index dans W << 3 | place j ; bit 14 = 1er combattant ;
# id d'origine bits 16-23, id en jeu bits 24-31). Bit RANDO_PAR_RENCONTRE de `compile` : le jeu sait les appliquer.
VERSION_RANDO_RENCONTRE = 10
TAILLE_ZONE_V10 = 0x24000
OFF_RANDO_ESPECES, CAP_RANDO_ESPECES, OFF_RANDO_P, CAP_RANDO_P = 0x20000, 256, 0x20800, 2048
RANDO_PAR_RENCONTRE = 0x04
# Garde-fou « loupe jamais vide » (archipelago_rando_yokai.md §14.3) : bit de `compile` ; le jeu ne réécrit la base d'un
# point de loupe que si la loupe peut montrer la nouvelle espèce dans le décor du point. Compteurs (jeu seulement) dans
# ApRandoPrive : bases refusées (+0x4C) et bases non réécrites faute de watchmap_common chargé (+0x50).
RANDO_LOUPE_DECOR = 0x08
OFF_RANDO_LOUPES_REFUSEES, OFF_RANDO_LOUPES_SANS_COMMUNE = 0x11040 + 0x4C, 0x11040 + 0x50
RANDO_P_CLE, RANDO_P_PREMIER = 0x3FFF, 0x4000
RANDO_GEN_AUCUNE, RANDO_GEN_IGNOREE = 0xFFFFFFFF, 0xFFFFFFFE
RANDO_SUIVIS = 8
RANDO_ENTETE = ("valide", "compile", "table_gen", "sigma_nombre", "beta_nombre", "w_nombre", "empreinte", "gen_carte",
                "gen_commune", "modifies", "analyses", "loupes", "erreurs", "derniere", "analyses_loupe", "tardives",
                "p_nombre", "especes_nombre")
# v7 (docs/systemes/archipelago_boite.md §24, archipelago_rando_boss.md §9) : randomizer des boss. En-tête (0x40 octets)
# à 0x12000 : valide (C, écrite en dernier), compile (J), table_gen (C), b_nombre / n_nombre (C, u16), empreinte (C),
# gen_carte / gen_commune (J), compteurs (J) ; B = {u32 place, u32 donneur} triées par place (boss à script) ; N =
# {u32 place, u32 origine, u32 cible, u32 0} triées par place (boss sans script). Même protocole d'écriture que §22.
VERSION_BOSS = 7
TAILLE_ZONE_V7 = 0x16000
OFF_BOSS, OFF_BOSS_B, OFF_BOSS_N = 0x12000, 0x12040, 0x12240
CAP_BOSS_B, CAP_BOSS_N = 64, 16
OFF_BOSS_PRIVE, OFF_BOSS_INSTANT, CAP_BOSS_INSTANT, OFF_BOSS_SAUV, CAP_BOSS_SAUV = 0x12400, 0x12480, 48, 0x14000, 96
TAILLE_INSTANT, TAILLE_SAUV = 0x90, 0x4C
BOSS_PUBLIE, BOSS_COMPILE = 0x80000000, 0x01
BOSS_NOM, BOSS_MEMBRES = 16, 6
BOSS_ENTETE = ("valide", "compile", "table_gen", "b_nombre", "n_nombre", "empreinte", "gen_carte", "gen_commune",
               "places", "especes", "restaurees", "instantanes", "erreurs", "derniere", "tardives", "manquants")
# v8 (docs/systemes/archipelago_boite.md §25, archipelago_deathlink.md) : DeathLink, dans la zone de la v7 (taille
# inchangée). ApMort (0x40 octets) à 0x15F00 : compile (J), demande (C, écrite EN DERNIER), ident (C, identifiant de
# partie de la sauvegarde visée), faite (J), etat (J), compteurs (J). En-tête +0x90 `defaites` (J) : défaites RÉELLES
# du joueur depuis le lancement (jamais une défaite forcée par une mort reçue).
VERSION_MORT = 8
OFF_MORT, TAILLE_MORT = 0x15F00, 0x40
MORT_PUBLIE, MORT_COMPILE = 0x80000000, 0x01
MORT_ETATS = {0: "aucune", 1: "en attente", 2: "défaite forcée en cours", 3: "fenêtre affichée",
              4: "fenêtre fermée, retour au point de reprise dû"}
MORT_REPORTS = [(0x01, "pas de partie"), (0x02, "ni terrain ni combat"),
                (0x04, "combat jamais forcé (en ligne, règle 3/15) ou issue déjà décidée"),
                (0x08, "début ou fin de combat"), (0x10, "évènement / vélo"), (0x20, "carte"),
                (0x40, "fenêtre de la mort ajoutée ou ouverte")]
MORT_CHAMPS = ("compile", "demande", "ident", "faite", "etat", "executees", "combat", "terrain", "abandonnees",
               "attente", "motif", "ignorees", "fin_vue", "forcee", "images_combat", "images_sur")
MORT_IMAGES_COMBAT, MORT_IMAGES_TERRAIN = 150, 30
MORT_HASH_DEFAITES = 0xEE5E8CA9
# Fenêtre de la mort reçue sur le terrain (archipelago_deathlink.md §4ter) : fenêtre d'information du jeu « Vous êtes
# tombé... (DeathLink de <joueur>) » par la file de fenêtres du terrain, fermée par le joueur, puis retour au point de
# reprise (repli : même retour sans message). Bit MORT_FENETRE de `compile` ; ApMortFenetre (0xC0 octets) à
# OFF_MORT_FENETRE : `source` (C, MORT_SOURCE octets, nom du joueur à l'origine, écrit AVANT `demande` et seulement si le
# jeu publie MORT_FENETRE ; vide : texte sans nom), puis état privé du jeu et `texte` affiché. Taille de zone et version
# inchangées. L'ancien « combat de défaite » (bit 0x02, mêmes octets) est retiré : le client n'écrit rien dans ces octets
# pour un jeu qui ne publie pas MORT_FENETRE.
MORT_ECRAN_ANCIEN, MORT_FENETRE = 0x02, 0x04
MORT_ETAT_FENETRE, MORT_ETAT_RETOUR, MORT_REPORT_FENETRE = 3, 4, 0x40
MORT_TEXTE_HASH = 0x3279D626                        # crc32("ap_deathlink_fenetre") : faux label de texte de la fenêtre
OFF_MORT_FENETRE, TAILLE_MORT_FENETRE = 0x15F40, 0xC0
MORT_SOURCE, MORT_TEXTE = 0x30, 0x60
MORT_NOM_MAX = 16                                   # caractères du nom montré (nom de slot AP : 16 au plus)
MORT_IMAGES_OUVERTURE, MORT_ESSAIS_FENETRE = 90, 3
MORT_FEN_AUCUNE, MORT_FEN_AJOUTEE, MORT_FEN_OUVERTE = 0, 1, 2
MORT_FEN_ETATS = {0: "aucune", 1: "ajoutée (ouverture attendue)", 2: "ouverte (appui attendu)"}
MORT_FENETRE_CHAMPS = ("etat", "images", "fenetres", "vue", "repli", "essais", "montrees", "annulees", "replis",
                       "textes", "demande")         # u32 à partir de +MORT_SOURCE
FENETRE_TEXTE = 0                                   # type d'entrée de la file du jeu : texte d'un label, sans icône
# Diagnostic du forçage en combat (archipelago_deathlink.md §3bis, boîte §25.5) : ApMortDiag (0x40 octets) à
# OFF_MORT_DIAG, juste avant ApMort (octets libres de la zone v7 : taille et version inchangées), tenu par le jeu
# seulement si `compile` porte MORT_DIAG ; lu par `ap_boite_test.py morts`, jamais par le client (aucune charge GDB).
# `refus` : dernier motif pour lequel la défaite n'a pas été forcée dans un combat pendant qu'une mort attendait ;
# `refus_masque` : motifs vus pour la demande `refus_demande` (bit 1 << motif) ; `attendus` : combats finis sans
# défaite forcée pendant qu'une mort attendait (elle s'exécute alors sur le terrain).
MORT_DIAG = 0x08
OFF_MORT_DIAG, TAILLE_MORT_DIAG = 0x15EC0, 0x40
MORT_DIAG_CHAMPS = ("refus", "refus_demande", "refus_masque", "refus_rencontre", "refus_octets", "refus_regles",
                    "refus_images", "attendus", "attendu_motif", "attendu_rencontre", "forcees", "forcee_demande",
                    "forcee_rencontre", "forcee_drapeaux", "forcee_images", "manquees")
(MORT_REFUS_AUCUN, MORT_REFUS_ABSENT, MORT_REFUS_EN_LIGNE, MORT_REFUS_REGLE_2A, MORT_REFUS_RESULTAT,
 MORT_REFUS_DECIDE, MORT_REFUS_INTRO, MORT_REFUS_TERMINE, MORT_REFUS_APPEL) = range(9)
MORT_REFUS = {
    MORT_REFUS_AUCUN: "aucun",
    MORT_REFUS_ABSENT: "combat pas encore créé (chargement)",
    MORT_REFUS_EN_LIGNE: "combat en ligne / entre joueurs (G+0x21, G+0x2F)",
    MORT_REFUS_REGLE_2A: "règle 3/15 (G+0x2A) : combat entre joueurs ou visiteur de ev98_0100",
    MORT_REFUS_RESULTAT: "résultat du combat déjà écrit (combat fini)",
    MORT_REFUS_DECIDE: "issue déjà décidée par les règles (victoire décidée / forcée, défaite déjà forcée)",
    MORT_REFUS_INTRO: "introduction du combat (moins de 150 images)",
    MORT_REFUS_TERMINE: "combat terminé, résultat pas encore écrit",
    MORT_REFUS_APPEL: "FUN_00456E40 a refusé",
}
MORT_REFUS_REPORT = {MORT_REFUS_EN_LIGNE: 0x04, MORT_REFUS_REGLE_2A: 0x04, MORT_REFUS_DECIDE: 0x04}   # sinon 0x08
MORT_DIAG_SANS_PENALITE = 0x01                      # forcee_drapeaux : combat à règle 3/18 (G+0x2B)
# v9 (docs/systemes/archipelago_boite.md §26, archipelago_boutiques.md §8) : boutiques (zone agrandie à 0x20000). En-tête
# ApBoutiquesEntete (0x40 octets) à 0x16000 : valide (C, écrit EN DERNIER), compile (J), nombre (C), compteurs (J) ;
# table de 320 entrées ApBoutique (80 octets) triées par article à 0x16040 : article, affiche (0 = vitrine), etiquette
# (location), bit (u16), drapeaux, utilisations (J), texte (56 octets). Évènement ACHAT (6) : id = article, valeur =
# objet montré, valeur2 = prix payé, etiquette = location, index = bit, drapeaux 0x01 bit posé / 0x02 surplus.
# Évènement BOUTIQUE (7, indices, archipelago_boutiques.md §10) : à l'ouverture (2001), bits des articles AP posés ET
# visibles (condition d'affichage vraie), BOUTIQUE_BITS_EVT par évènement : deux u16 dans chacun de id, valeur,
# valeur2, etiquette, index (bits pairs en bas), BOUTIQUE_BIT_AUCUN = vide ; quantite = nombre de bits ; drapeaux
# 0x01 = dernier évènement de l'ouverture. Jeu sans le bit BOUTIQUES_INDICES dans `compile` : aucun indice
# automatique (rien d'autre ne change).
VERSION_BOUTIQUES = 9
TAILLE_ZONE_V9 = 0x20000
OFF_BOUTIQUES, OFF_BOUTIQUES_TABLE, CAP_BOUTIQUES, TAILLE_BOUTIQUE, BOUTIQUE_TEXTE = 0x16000, 0x16040, 320, 80, 56
OFF_BOUTIQUES_PRIVE, OFF_BOUTIQUES_LIGNES, BOUTIQUES_LIGNES = 0x1C500, 0x1C540, 80
BOUTIQUES_PUBLIE, BOUTIQUES_COMPILE, BOUTIQUE_VALIDE = 0x80000000, 0x01, 0x01
BOUTIQUES_INDICES = 0x02
BOUTIQUE_BITS_EVT, BOUTIQUE_BIT_AUCUN, BOUTIQUE_EVT_DERNIER = 10, 0xFFFF, 0x01
BOUTIQUE_CHAMPS_BITS = ("id", "valeur", "valeur2", "etiquette", "index")
ACHAT_BIT_POSE, ACHAT_SURPLUS = 0x01, 0x02
EVT_ACHAT = 6
EVT_BOUTIQUE = 7
BOUTIQUES_ENTETE = ("valide", "compile", "nombre", "achats", "dernier", "ouvertes", "lignes", "ignorees", "surplus",
                    "types_masques", "annonces")
# Bits persistants « premier achat fait » : flags octets globaux NON définis (P + 0x144 + index) ; bit k -> octet
# BOUTIQUE_OCTETS[k // 8], bit k % 8 (même liste que AP_BOUTIQUE_OCTETS de boite.h, vérifiée par --selftest).
BOUTIQUE_OCTETS = (53, 54, 55, 69, 70, 74, 75, 82, 83, 84, 85, 86, 87, 88, 89, 90, 121, 122, 123, 124, 125, 126, 127,
                   607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 10, 58, 99, 100, 344, 387, 599)
BOUTIQUE_BITS = 8 * len(BOUTIQUE_OCTETS)          # 320 (sans 396 ni 449, voisins des octets wantedNN)
P_FLAGS_OCTETS = 0x144
# Fenêtre « objet obtenu » des checks sans affichage (docs/systemes/archipelago_boite.md §27, archipelago_anim_objet.md) :
# dans la zone v9 (version et taille inchangées), fonction 29 de `compiles` (FONCTION_ANIM : sans elle, rien n'est écrit).
# En-tête ApAnimEntete (0x40 octets) à 0x1FC80 : ecrites (C, écrit EN DERNIER), traitees (J), montrees, ecartees,
# annulees, etat, motif, images, etiquette, fenetres, perdues (J) ; puis 8 entrées ApAnim (80 octets) à 0x1FCC0, entrée n
# (1, 2, …) à la place (n - 1) % 8 : numero, etiquette (location), affiche (0 = vitrine), ident (identifiant de partie),
# quantite (u16), drapeaux, texte (56 octets, nom de la vitrine). Le client n'écrit jamais au-delà de traitees + 8.
FONCTION_ANIM = 29
OFF_ANIM, OFF_ANIM_TABLE, CAP_ANIM, TAILLE_ANIM, ANIM_TEXTE = 0x1FC80, 0x1FCC0, 8, 80, 56
ANIM_ENTETE = ("ecrites", "traitees", "montrees", "ecartees", "annulees", "etat", "motif", "images", "etiquette",
               "fenetres", "perdues")
ANIM_ETATS = {0: "aucune", 1: "attente du moment sûr", 2: "ajoutée à la file du jeu", 3: "fenêtre ouverte"}
ANIM_REPORTS = [(0x01, "pas de partie"), (0x02, "terrain pas au sommet"), (0x04, "évènement / sous-état"),
                (0x08, "carte"), (0x10, "fenêtre du jeu"), (0x20, "mort en attente")]
ANIM_IMAGES_SURES, ANIM_IMAGES_OUVERTURE = 30, 90
NOTIF_AUTO_MESSAGE = 5
POLITIQUE_MARQUER = 0x04
COFFRE_PAR_INDEX = 0x04
EVT_OBJET_SUBSTITUE, EVT_OBJET_BIT_POSE = 0x04, 0x08
PROGRESSION_CHAPITRE, PROGRESSION_VICTOIRE, PROGRESSION_APRES_JEU = 0x01, 0x02, 0x04
HASH_FLAG_FIN = 0x176F56BB
CHAPITRE_APRES_JEU = 11
TBOX_SPOT_PREMIER, TBOX_NOMBRE = 558, 576
# Bits de check des dons de script RÉPÉTABLES (PNJ du Musée : Poster, Bobine, Y-Cola, Affiche, Louloutre) : tant que le
# bit n'est pas posé, le jeu lit l'objet d'origine « non possédé » (IsHaveItem, objets_cles_v11 §19.3)
TBOX_REPETABLE_PREMIER, TBOX_REPETABLE_DERNIER = 571, 575
SCRIPT_DONNER, SCRIPT_BIT_AUCUN = 0x01, 0xFFFF
VITRINE_DEFAUT = 0xA0531A08   # « Important Item 20 » (iky2020), jamais donné
# v4 : liaison de la sauvegarde (docs/systemes/archipelago_boite.md §11.2, §11.3)
VERSION_LIAISON = 4           # premier jeu qui ne marque une sauvegarde QUE sur demande explicite
LIAISON_MANUELLE = 0x8000     # bit 15 de la clé de liaison (P+0x3B6) : sauvegarde existante liée par le joueur
LIAISON_ARMEE = 0x01          # liaison_manuelle (jeu v4 à v6) : « lier la prochaine sauvegarde » armé (écran, X puis X)
#                               depuis le 2026-09-28 : liaison manuelle supprimée (jeu : clé manuelle refusée ; client :
#                               jamais écrite) ; LIAISON_MANUELLE sert encore à reconnaître une sauvegarde liée avant
PAS_NEUVE = 100               # partie neuve : chapitre 0, ou chapitre 1 et pas_scenario < 100
IMAGES_FENETRE = 900
SAISIE_OUVERTE, SAISIE_VALIDEE, SAISIE_ANNULEE, SAISIE_ERREUR = 1, 2, 3, 4
CFG_SERVEUR, CFG_SLOT, CFG_MDP, CFG_MDP_INCHANGE = 0x01, 0x02, 0x04, 0x08
CNX_DEMANDE_SAISIE, CNX_MESSAGE, CNX_EFFACER_MDP = 0x01, 0x02, 0x04
ETATS_CONNEXION = {0: "client absent", 1: "non configuré", 2: "connexion", 3: "connecté", 4: "erreur",
                   5: "déconnecté"}
TYPES_DON = {"objet": 1, "argent": 2, "yokai": 3}
NOMS_DON = {v: k for k, v in TYPES_DON.items()}
CODES = {0: "OK", 1: "TYPE_INCONNU", 2: "OBJET_INCONNU", 3: "ECHEC_DON", 4: "PARTIE", 5: "QUANTITE", 6: "NON_LIEE"}
BITS_ETAT = [(0x01, "partie"), (0x02, "terrain"), (0x04, "stable"), (0x08, "BLOQUE"), (0x10, "attente"),
             (0x20, "pause"), (0x80, "lieu"), (0x100, "position")]
EVTS = {1: "COFFRE", 2: "OBJET_JEU", 3: "DON", 4: "DON_ECHEC", 5: "RECOMPENSE", 6: "ACHAT", 7: "BOUTIQUE",
        8: "INVITE", 9: "INVITE_CHAMBRE"}
COFFRE_AFFICHAGE_SEUL, COFFRE_UNE_FOIS = 0x01, 0x02
PORT_AZAHAR = 24689           # CITRA_GDB_PORT du mod (yokaiwatch2/constants.py)

# En-tête : (nom, offset, format struct)
ENTETE = [
    ("magic", 0x00, "I"), ("version", 0x04, "H"), ("taille_entete", 0x06, "H"), ("taille_zone", 0x08, "I"),
    ("dons_off", 0x0C, "H"), ("dons_capacite", 0x0E, "H"), ("journal_off", 0x10, "H"),
    ("journal_capacite", 0x12, "H"), ("coffres_off", 0x14, "H"), ("coffres_capacite", 0x16, "H"),
    ("taille_don", 0x18, "H"), ("taille_evt", 0x1A, "H"), ("taille_coffre", 0x1C, "H"),
    ("liaison_sauvegarde", 0x1E, "H"),
    ("images", 0x20, "I"), ("etat", 0x24, "I"), ("compteur", 0x28, "I"), ("ident_sauvegarde", 0x2C, "I"),
    ("dernier_numero", 0x30, "I"), ("dernier_resultat", 0x34, "I"), ("dernier_code_erreur", 0x38, "I"),
    ("numero_erreur", 0x3C, "I"), ("dons_traites", 0x40, "I"), ("journal_ecrit", 0x44, "I"),
    ("journal_perdus", 0x48, "I"), ("adresse_p", 0x4C, "I"), ("adresse_joueur", 0x50, "I"),
    ("images_terrain", 0x54, "I"),
    ("notifs_off", 0x58, "H"), ("notifs_capacite", 0x5A, "H"), ("taille_notif", 0x5C, "H"),
    ("notif_texte_max", 0x5E, "H"), ("notifs_affichees", 0x60, "I"), ("notif_etat", 0x64, "I"),
    ("notif_restant", 0x68, "I"), ("notifs_auto_ecrites", 0x6C, "I"), ("notifs_auto_perdues", 0x70, "I"),
    ("notifs_montrees", 0x74, "I"),
    ("config_off", 0x78, "H"), ("connexion_off", 0x7A, "H"), ("saisie_etat", 0x7C, "I"),
    # lieu du joueur (branche ap/carte-suivi, §29) : valides SEULEMENT si ETAT_LIEU (ces 12 octets étaient privés dans
    # un jeu antérieur) ; pos_x / pos_z : bits d'un flottant 32 bits (`lieu_publie`)
    ("carte", 0x80, "I"), ("pos_x", 0x84, "I"), ("pos_z", 0x88, "I"),
    ("prive_auto_lu", 0x8C, "I"), ("defaites", 0x90, "I"),
    ("ecran_ouvert", 0x94, "I"), ("chapitre", 0x98, "H"), ("pas_scenario", 0x9A, "H"), ("progression", 0x9C, "I"),
    ("spots", 0xA0, "I"), ("scripts_off", 0xA4, "H"), ("scripts_capacite", 0xA6, "H"), ("noms_off", 0xA8, "H"),
    ("noms_capacite", 0xAA, "H"), ("taille_nom", 0xAC, "H"), ("nom_texte_max", 0xAE, "H"),
    ("vitrine_etiquette", 0xB0, "I"), ("substitutions", 0xB4, "I"), ("vitrine_off", 0xB8, "H"),
    ("prive_off", 0xBA, "H"), ("verrous_off", 0xBC, "H"), ("verrous_capacite", 0xBE, "H"),
    ("journal_lu", 0xC0, "I"), ("coffres_nombre", 0xC4, "I"), ("ident_partie", 0xC8, "I"),
    ("politique", 0xCC, "I"), ("pause", 0xD0, "I"), ("client_images", 0xD4, "I"),
    ("notif_duree_auto", 0xD8, "I"), ("notif_langue", 0xDC, "I"),
    ("scripts_nombre", 0xE0, "I"), ("noms_nombre", 0xE4, "I"), ("vitrine", 0xE8, "I"),
    # v4
    ("liaison_demande", 0xEC, "I"), ("liaison_terrain", 0xF0, "I"), ("liaison_cle", 0xF4, "H"),
    ("terrain_numero", 0xF8, "I"), ("liaison_manuelle", 0xFC, "I"),
]
CHAMP = {n: (o, f) for n, o, f in ENTETE}


def lire_mort(b: bytes) -> dict:
    """ApMort (v8) : les 0x40 octets à OFF_MORT (ou un préfixe : champs présents seulement)."""
    return {n: struct.unpack_from("<I", b, 4 * i)[0] for i, n in enumerate(MORT_CHAMPS) if 4 * i + 4 <= len(b)}


def lire_mort_fenetre(b: bytes) -> dict:
    """ApMortFenetre : les 0xC0 octets à OFF_MORT_FENETRE (source, état privé du jeu, texte affiché)."""
    d = {n: struct.unpack_from("<I", b, MORT_SOURCE + 4 * i)[0] for i, n in enumerate(MORT_FENETRE_CHAMPS)}
    d["source"] = b[:MORT_SOURCE].split(b"\0")[0]
    d["texte"] = b[0x60:0x60 + MORT_TEXTE].split(b"\0")[0]
    return d


def mort_diag(b: bytes) -> bool:
    """Diagnostic du forçage en combat tenu par le jeu : bit MORT_DIAG du champ `compile` publié."""
    c = struct.unpack_from("<I", b, 0)[0]
    return bool(c & MORT_PUBLIE) and bool(c & MORT_DIAG)


def lire_mort_diag(b: bytes) -> dict:
    """ApMortDiag : les 0x40 octets à OFF_MORT_DIAG."""
    return {n: struct.unpack_from("<I", b, 4 * i)[0] for i, n in enumerate(MORT_DIAG_CHAMPS)}


def texte_mort_refus(masque: int) -> str:
    """Motifs d'un masque de refus (bit 1 << motif), en clair."""
    return " ; ".join(t for k, t in MORT_REFUS.items() if k and masque >> k & 1) or "-"


def mort_fenetre(b: bytes) -> bool:
    """Fenêtre de la mort sur le terrain compilée : bit MORT_FENETRE du champ `compile` publié."""
    c = struct.unpack_from("<I", b, 0)[0]
    return bool(c & MORT_PUBLIE) and bool(c & MORT_FENETRE)


def enc_mort_source(nom: str | None) -> bytes:
    """Champ `source` d'ApMortFenetre : nom du joueur à l'origine (une ligne, MORT_NOM_MAX caractères au plus, UTF-8
    terminé par 0, jamais coupé au milieu d'un caractère) ; None, vide ou « ? » : champ nul (texte sans nom)."""
    nom = " ".join((nom or "").split())
    if nom == "?":
        nom = ""
    return _champ_texte(nom[:MORT_NOM_MAX], MORT_SOURCE)


def texte_mort_fenetre(source: bytes, langue: int = 0) -> bytes:
    """Texte que le jeu compose pour la fenêtre (composerTexte de deathlink.cpp) : deux lignes, nom neutralisé."""
    nom = copier_texte(bytes(source).split(b"\0")[0][:MORT_SOURCE - 1], True)
    t = b"You fell...\n(DeathLink" if langue == 1 else "Vous êtes tombé...\n(DeathLink".encode("utf-8")
    if nom:
        t += (b" from " if langue == 1 else b" de ") + nom
    return (t + b")")[:MORT_TEXTE - 1]


def mort_compile(b: bytes) -> bool | None:
    """DeathLink compilé dans le jeu : True / False, None si le champ n'est pas publié (jeu v7 ou antérieur)."""
    c = struct.unpack_from("<I", b, 0)[0]
    return None if not c & MORT_PUBLIE else bool(c & MORT_COMPILE)


def lire_entete(b: bytes) -> dict:
    return {n: struct.unpack_from("<" + f, b, o)[0] for n, o, f in ENTETE}


def champ(nom: str, valeur: int) -> tuple[int, bytes]:
    o, f = CHAMP[nom]
    return ZONE + o, struct.pack("<" + f, valeur)


def enc_don(numero: int, type_: int, hash_: int, quantite: int) -> bytes:
    return struct.pack("<IBBHIi", numero, type_, 0, 0, hash_ & 0xFFFFFFFF, quantite)


def dec_don(b: bytes) -> dict:
    n, t, _, _, h, q = struct.unpack("<IBBHIi", b)
    return {"numero": n, "type": t, "hash": h, "quantite": q}


def dec_evt(b: bytes) -> dict:
    n, t, d, q, i, v, v2, et, idx, img = struct.unpack("<IBBHIIIIII", b)
    return {"numero": n, "type": t, "drapeaux": d, "quantite": q, "id": i, "valeur": v, "valeur2": v2,
            "etiquette": et, "index": idx, "image": img}


def enc_evt(e: dict) -> bytes:
    return struct.pack("<IBBHIIIIII", e["numero"], e["type"], e["drapeaux"], e["quantite"], e["id"], e["valeur"],
                       e["valeur2"], e["etiquette"], e["index"], e["image"])


def enc_coffre(tbox: int, objet: int, quantite: int, drapeaux: int, etiquette: int, utilisations: int = 0) -> bytes:
    return struct.pack("<IIHBBI", tbox, objet, quantite, drapeaux, utilisations, etiquette)


def dec_coffre(b: bytes) -> dict:
    t, o, q, d, u, e = struct.unpack("<IIHBBI", b)
    return {"tbox": t, "objet": o, "quantite": q, "drapeaux": d, "utilisations": u, "etiquette": e}


def adr_don(numero: int) -> int:
    return ZONE + OFF_DONS + (numero % CAP_DONS) * 16


def adr_evt(numero: int) -> int:
    return ZONE + OFF_JOURNAL + ((numero - 1) % CAP_JOURNAL) * 32


def adr_notif(numero: int) -> int:
    return ZONE + OFF_NOTIFS + (numero % CAP_NOTIFS) * TAILLE_NOTIF


# --- v3 : configuration, état de connexion, dons de script, noms de vitrine ---
def _chaine(b: bytes) -> str:
    return b.split(b"\0")[0].decode("utf-8", "replace")


def _champ_texte(texte: str | bytes, taille: int) -> bytes:
    """Texte UTF-8 d'un champ de `taille` octets (terminé par 0, sans couper un caractère)."""
    b = texte.encode("utf-8") if isinstance(texte, str) else bytes(texte)
    if len(b) > taille - 1:
        b = b[:taille - 1]
        while b and b[-1] & 0xC0 == 0x80:
            b = b[:-1]
        if b and b[-1] >= 0xC0:
            b = b[:-1]
    return b.ljust(taille, b"\0")


def enc_config(revision: int, drapeaux: int, serveur: str, slot: str, mdp: str = "", revision_effacee: int = 0,
               erreur: int = 0) -> bytes:
    return (struct.pack("<IIII", revision, drapeaux, revision_effacee, erreur) + _champ_texte(serveur, 128)
            + _champ_texte(slot, 64) + _champ_texte(mdp, 48))


def dec_config(b: bytes) -> dict:
    rev, dr, eff, err = struct.unpack_from("<IIII", b)
    return {"revision": rev, "drapeaux": dr, "revision_effacee": eff, "erreur": err,
            "serveur": _chaine(b[0x10:0x90]), "slot": _chaine(b[0x90:0xD0]), "mdp": _chaine(b[0xD0:0x100])}


def enc_connexion(sequence: int, etat: int, revision_lue: int = 0, erreur: int = 0, drapeaux: int = 0,
                  client_images: int = 0, connu: int = 0, message: str = "", serveur: str = "",
                  slot: str = "") -> bytes:
    b = struct.pack("<IIIIIIII", sequence, etat, revision_lue, erreur, drapeaux, client_images, connu, 0)
    b += _champ_texte(message, NOTIF_TEXTE) + b"\0" * 8 + _champ_texte(serveur, 128) + _champ_texte(slot, 64)
    return b.ljust(TAILLE_CONNEXION, b"\0")


def dec_connexion(b: bytes) -> dict:
    seq, etat, rl, err, dr, ci, connu, _ = struct.unpack_from("<IIIIIIII", b)
    return {"sequence": seq, "etat": etat, "revision_lue": rl, "erreur": err, "drapeaux": dr, "client_images": ci,
            "connu": connu, "message": _chaine(b[0x20:0x58]), "serveur": _chaine(b[0x60:0xE0]),
            "slot": _chaine(b[0xE0:0x120])}


def enc_script(origine: int, affiche: int = 0, bit: int = SCRIPT_BIT_AUCUN, drapeaux: int = 0, etiquette: int = 0,
               utilisations: int = 0) -> bytes:
    return struct.pack("<IIHBBI", origine, affiche, bit, drapeaux, utilisations, etiquette)


def dec_script(b: bytes) -> dict:
    o, a, bit, d, u, e = struct.unpack("<IIHBBI", b)
    return {"origine": o, "affiche": a, "bit": bit, "drapeaux": d, "utilisations": u, "etiquette": e}


def enc_nom(etiquette: int, texte: str | bytes) -> bytes:
    return struct.pack("<IHBB", etiquette, 0, 0, 0) + _champ_texte(texte, NOM_TEXTE)


def dec_nom(b: bytes) -> dict:
    e, _, d, _ = struct.unpack_from("<IHBB", b)
    return {"etiquette": e, "drapeaux": d, "texte": b[8:].split(b"\0")[0]}


def enc_verrous(actifs: int, recu: dict[int, bool | int] | list[int]) -> bytes:
    """Zone des verrous (J4) : `actifs` (bit k) puis recu[k] (1 = reçu). Écrire recu (+8) AVANT actifs (+0).
    Verrou progressif (k de VERROUS_PROGRESSIFS, rangs) : recu[k] = nombre d'exemplaires reçus (plafonné à 255) ;
    un booléen y vaut 0 / 1."""
    r = bytearray(CAP_VERROUS)
    for k, v in (recu.items() if isinstance(recu, dict) else enumerate(recu)):
        if k in VERROUS_PROGRESSIFS and not isinstance(v, bool):
            r[k] = max(0, min(255, int(v)))
        else:
            r[k] = 1 if v else 0
    return (struct.pack("<II", actifs, 0) + bytes(r)).ljust(TAILLE_VERROUS, b"\0")


def dec_verrous(b: bytes) -> dict:
    """Zone des verrous : `actifs` (C), `compiles` (J, v4 §20 : bit k compilé, bit 31 liste publiée), recu[] (C),
    diagnostic du jeu (appliqués / exemptés par verrou k < 24, dernière phase plafonnée : brute, rendue ; dernier
    verrou de montre lu : rang exigé, rang AP, valeur rendue au script)."""
    actifs, compiles = struct.unpack_from("<II", b)
    d = {"actifs": actifs, "compiles": compiles, "recu": list(b[8:8 + CAP_VERROUS])}
    if len(b) >= 0xEB:
        d["appliques"] = (list(struct.unpack_from("<8I", b, 0x20)) + list(struct.unpack_from("<8I", b, 0x68))
                          + list(struct.unpack_from("<8I", b, 0xA8)))
        d["exemptes"] = (list(struct.unpack_from("<8I", b, 0x40)) + list(struct.unpack_from("<8I", b, 0x88))
                         + list(struct.unpack_from("<8I", b, 0xC8)))
        d["phase_brute"], d["phase_rendue"] = struct.unpack_from("<II", b, 0x60)
        # rangs (k = 18) : dernier verrou de montre lu (rang exigé, rang AP, valeur rendue au script : 6 = fermé)
        d["rang_exige"], d["rang_ap"], d["rang_rendu"] = b[0xE8], b[0xE9], b[0xEA]
    if len(b) >= 0xF4:
        # Yo-criminels libres (fonction 24) : dernier `wanted_no` rendu au jeu, lectures du bit 2072 rendues fausses ;
        # combats du jour libres (fonction 25) : lectures « déjà combattu aujourd'hui » rendues fausses
        d["criminel_rendu"] = b[0xEB]
        d["criminels_masques"], d["combats_libres"] = struct.unpack_from("<II", b, 0xEC)
    if len(b) >= 0xF8:
        # Bingo-kai infini (option 27) : lectures de la réserve du jour rendues 1 au lieu de 0 (0 : jeu antérieur)
        d["bingo_rendus"] = struct.unpack_from("<I", b, 0xF4)[0]
    if len(b) >= 0xFF:
        # rang réel (mode k = 20, 0 dans un jeu antérieur) : dernier rang écrit par le mod, rang réel de la sauvegarde
        # liée, fenêtre « rang » en attente, écritures, fenêtres de script filtrées, fenêtres mises en file par le mod ;
        # 0x364C neutralisée : appliques[20] ; 0x364C laissée (rang S) : exemptes[20]
        d["rang_reel_ecrit"], d["rang_reel_lu"], d["rang_fenetre"] = b[0xF8], b[0xF9], b[0xFA]
        d["rang_ecritures"], d["rang_filtrees"], d["rang_montrees"] = b[0xFC], b[0xFD], b[0xFE]
    if len(b) >= 0x100:
        # vélo réel (mode k = 21, 0 dans un jeu antérieur) : bits VELO_DIAG_* de ce que le mod a fait depuis le
        # lancement ; dons du vélo (flags posés) : appliques[21] ; objets vélo retirés : exemptes[21]
        d["velo_reel"] = b[0xFF]
    return d


def verrous_compiles(b: bytes) -> int | None:
    """Masque des verrous compilés dans le jeu, ou None si le jeu ne publie pas la liste (build antérieur à la
    v4 « verrous » : aucun verrou)."""
    c = struct.unpack_from("<I", b, 4)[0]
    return c & ~VERROUS_PUBLIES if c & VERROUS_PUBLIES else None


def options_actives(bingo_kai_infini: bool) -> int:
    """Bits d'options du joueur à poser dans `actifs` (le client les écrit avec les verrous, dans le même paquet)."""
    return (1 << OPTION_BINGO_KAI) if bingo_kai_infini else 0


def option_compilee(b: bytes, k: int) -> bool:
    """Option k compilée dans le jeu (liste publiée, bit k de `compiles`)."""
    c = verrous_compiles(b)
    return c is not None and bool(c >> k & 1)


def bingo_restant_vu(b: bytes, brut: int, sauvegarde_liee: bool = True) -> int:
    """Modèle de bingoFiltre (bingo.cpp) : réserve de tours du jour du Bingo-kai (octet 0xA45A65EC) vue par le jeu.
    Lue au moins 1 si l'option est compilée, choisie (bit 27 de `actifs`) et la sauvegarde liée ; sinon la valeur
    stockée."""
    v = dec_verrous(b)
    actif = option_compilee(b, OPTION_BINGO_KAI) and bool(v["actifs"] >> OPTION_BINGO_KAI & 1) and sauvegarde_liee
    return 1 if brut == 0 and actif else brut


def verrou_actif(b: bytes, k: int) -> bool:
    """Modèle de apVerrouActif (boite.cpp) : verrou k compilé dans le jeu, actif et objet non reçu (la condition
    « sauvegarde liée » est vérifiée à part par le jeu). Verrous à interrupteur seulement (« reçu » = octet non nul) :
    ne modélise PAS un verrou progressif (rangs de montre, k = 18 : recu[18] = nombre reçu, comparé au rang exigé,
    voir `rang_exige_vu`)."""
    v = dec_verrous(b)
    return 0 <= k < CAP_VERROUS and bool((v["compiles"] & ~VERROUS_PUBLIES) >> k & 1) \
        and bool(v["actifs"] >> k & 1) and not v["recu"][k]


def velo_vu(b: bytes, flag_brut: bool, a_velo: bool = False) -> bool:
    """Modèle de apVerrouFiltreFlag pour les flags 39 et 40 (bouton vélo du menu terrain, verrous.cpp) : valeur vue par
    le jeu. Masquée (0) si le verrou du Vélo (k = 12) s'applique, sauf si le joueur roule déjà (`a_velo` : il garde son
    bouton pour descendre)."""
    return bool(flag_brut) and (a_velo or not verrou_actif(b, VERROU_VELO))


def montee_velo_refusee(b: bytes, argument: int) -> bool:
    """Modèle de la garde 0x005336D4 (commande 0x3564, verrous.cpp) : une demande de montée (argument non nul) est
    ignorée tant que le Vélo n'est pas reçu ; la descente (0) passe toujours."""
    return argument != 0 and verrou_actif(b, VERROU_VELO)


# Vélo réel (mode k = 21, verrous.cpp apVeloReelImage, objets_cles_v11 §15 bis).
VELO_DIAG = [(0x01, "flags posés"), (0x02, "objet vélo donné"), (0x04, "objet vélo retiré"),
             (0x08, "bouton redessiné"), (0x10, "flag 40 laissé au jeu (phase >= 7-40)"), (0x20, "don de l'objet refusé")]
VELO_DIAG_FLAGS, VELO_DIAG_DONNE, VELO_DIAG_RETIRE, VELO_DIAG_BOUTON, VELO_DIAG_TEMPETE, VELO_DIAG_ECHEC = (
    m for m, _ in VELO_DIAG)
VELO_PHASE_TEMPETE = 70040   # à partir de la phase 7-40, le flag 40 est géré par le jeu (PhCmd_7_40 / PhCmd_7_70)
VELO_COULEUR_GARCON, VELO_COULEUR_FILLE = 10, 11   # couleurs des modèles par défaut (another_shop)


def velo_reel_en_vigueur(b: bytes) -> bool:
    """Mode « vélo réel » (apVeloReelImage, verrous.cpp) : verrou du Vélo (k = 12) et mode 21 compilés et actifs (la
    sauvegarde liée est vérifiée à part par le jeu)."""
    v = dec_verrous(b)
    return _verrou_en_vigueur(v, VERROU_VELO) and _verrou_en_vigueur(v, VERROU_VELO_REEL)


def velo_objet_de_la_couleur(couleur: int, garcon: bool) -> str:
    """Modèle de apVeloObjetDeLaCouleur : nom interne de l'objet vélo de la couleur enregistrée (`bicycle_color_num`)
    pour ce joueur ; couleur 0 (jamais choisie) ou hors table : modèle par défaut du genre."""
    if 1 <= couleur <= 9:
        return "iky%04d" % ((65 if garcon else 74) + couleur)
    return "iky0011" if garcon else "iky0012"


def velo_reel_evaluation(b: bytes, flag39: bool, flag40: bool, velos: int, phase: int) -> dict | None:
    """Modèle d'une évaluation de apVeloReelImage (terrain libre d'une sauvegarde liée) : état après l'évaluation,
    {flag39, flag40, velos (nombre d'objets vélo), donne, retire, ecrit} ; None hors du mode (rien n'est fait).
    Vélo reçu : flag 39 posé s'il ne l'est pas (et flag 40 avant la phase 7-40), un objet vélo donné si l'inventaire
    n'en a aucun ; pas reçu : tout objet vélo de l'inventaire est retiré, les flags ne sont jamais touchés."""
    if not velo_reel_en_vigueur(b):
        return None
    if not dec_verrous(b)["recu"][VERROU_VELO]:
        return {"flag39": flag39, "flag40": flag40, "velos": 0, "donne": False, "retire": velos > 0, "ecrit": False}
    ecrit = not flag39
    if ecrit and phase < VELO_PHASE_TEMPETE:
        flag40 = True
    return {"flag39": True, "flag40": flag40, "velos": max(velos, 1), "donne": velos == 0, "retire": False,
            "ecrit": ecrit}


RANGS_MONTRE = {1: "D", 2: "C", 3: "B", 4: "A", 5: "S"}
RANG_D, RANG_C, RANG_A, RANG_IMPOSSIBLE = 1, 2, 4, 6


def _verrou_en_vigueur(v: dict, k: int) -> bool:
    return bool((v["compiles"] & ~VERROUS_PUBLIES) >> k & 1 and v["actifs"] >> k & 1)


def peche_vue(b: bytes, flag_brut: bool, liee: bool = True, reelle: bool = True) -> bool:
    """Modèle de apVerrouFiltreFlag pour le flag 29 (pêche, verrous.cpp, objets_cles_v11 §19) : valeur vue par le jeu.
    Verrou de la Canne (k = 5) en vigueur (compilé, actif, sauvegarde liée) : « Canne reçue », que le flag natif (posé
    seulement par la requête 99) le soit ou non ; sinon la valeur native. `reelle=False` : build
    YKW2_AP_SANS_CANNE_REELLE (ancien masque : le flag natif reste nécessaire)."""
    v = dec_verrous(b)
    if not (liee and _verrou_en_vigueur(v, VERROU_CANNE)):
        return bool(flag_brut)
    recu = bool(v["recu"][VERROU_CANNE])
    return recu if reelle else (recu and bool(flag_brut))


def modele_zero_vue(b: bytes, flag_natif: bool, tutoriels_finis: bool, combat_gagne: bool, liee: bool = True,
                    reelle: bool = True, garde: bool = True) -> bool:
    """Modèle de la commande 0x3CEF remplacée (0x0051C624, verrous.cpp, objets_cles_v11 §19.4), hors mémoire de combat :
    interface de la Modèle zéro dans les combats. Verrou k = 6 en vigueur : reçue -> active même avant le flag 21 (phase
    6-20), une fois les tutoriels de combat finis (flag de PhCmd_2_70 ; `garde=False` : build
    YKW2_AP_MODELE_ZERO_SANS_GARDE) ; non reçue -> flag natif, masqué après la victoire ev06_btl0040. Hors vigueur :
    flag natif. `reelle=False` : build YKW2_AP_SANS_MODELE_ZERO_REEL (ancien verrou seul)."""
    v = dec_verrous(b)
    if not (liee and _verrou_en_vigueur(v, VERROU_MODELE_ZERO)):
        return bool(flag_natif)
    if v["recu"][VERROU_MODELE_ZERO]:
        if flag_natif or not reelle:
            return bool(flag_natif)
        return bool(tutoriels_finis) or not garde
    return bool(flag_natif) and not combat_gagne


def appli_invocation_vue(b: bytes, flag_brut: bool, liee: bool = True) -> bool:
    """Modèle de apVerrouFiltreFlag pour le flag 73 (entrée 20 du menu principal, appli d'invocation par médailles) :
    vraie dès que la Modèle zéro est reçue (verrou k = 6 en vigueur), jamais masquée."""
    v = dec_verrous(b)
    return bool(flag_brut) or (liee and _verrou_en_vigueur(v, VERROU_MODELE_ZERO) and bool(v["recu"][VERROU_MODELE_ZERO]))


def possession_masquee(scripts, bits_poses, objet: int, liee: bool = True) -> bool:
    """Modèle de apBoitePossessionMasquee (boite.cpp, condition IsHaveItem d'un objet possédé, objets_cles_v11 §19.3) :
    vrai si l'objet est l'origine d'une entrée de la table des dons de script (`scripts` : dictionnaires de dec_script,
    dans l'ordre de la table) dont le bit de check est dans la réserve « répétable » et pas encore posé (`bits_poses` :
    ensemble des index TBox posés). La première entrée de cet objet décide, comme dans la substitution."""
    if not objet or not liee:
        return False
    for e in scripts:
        if e["origine"] != objet:
            continue
        return TBOX_REPETABLE_PREMIER <= e["bit"] <= TBOX_REPETABLE_DERNIER and e["bit"] not in bits_poses
    return False


def combat_memo(memo: int, loop: int) -> int:
    """Modèle de apBoiteCombatMemo : valeur de 0x3CEF figée pour le combat du loop `loop` (0 / 1), ou -1."""
    if not loop or not memo & 2 or memo & ~3 != loop & ~3:
        return -1
    return memo & 1


def combat_memoriser(memo: int, loop: int, valeur: bool) -> int:
    """Modèle de apBoiteCombatMemoriser : nouveau mot ApPrive + 0x38."""
    return (loop & ~3) | 2 | int(bool(valeur)) if loop else memo


def rang_ap(b: bytes) -> tuple[int, bool] | None:
    """Rang AP que le jeu compare aux portes de montre (apVerrouRangMontre), et mode « portes D » ; None si le verrou
    des rangs n'est pas en vigueur (non compilé ou inactif : jeu d'origine). Mode « portes D » (k = 19 compilé et
    actif, graine récente) : rang AP = recu[18] (0 aucun, 1 D … 4 A) ; sinon : D + recu[18]."""
    v = dec_verrous(b)
    if not _verrou_en_vigueur(v, VERROU_RANGS):
        return None
    portes_d = _verrou_en_vigueur(v, VERROU_RANGS_D)
    return (v["recu"][VERROU_RANGS] if portes_d else RANG_D + v["recu"][VERROU_RANGS]), portes_d


def rang_exige_vu(b: bytes, rang_exige: int) -> int:
    """Modèle de apVerrouRangMontre (verrous.cpp) : rang exigé que voit le script d'un verrou de montre (ev98_0060)
    pour ce rang exigé d'origine. Verrou des rangs compilé et actif (la sauvegarde liée est vérifiée à part par le
    jeu) et rang exigé dans les portes concernées (D, C, B, A en mode « portes D », sinon C, B, A) : si le rang AP
    (`rang_ap`) est inférieur, 6 (aucun rang réel, 0..5, ne suffit) ; sinon (et pour S) inchangé : le rang réel
    reste exigé comme d'origine."""
    r = rang_ap(b)
    if r is None:
        return rang_exige
    ap, portes_d = r
    if not (RANG_D if portes_d else RANG_C) <= rang_exige <= RANG_A:
        return rang_exige
    return rang_exige if ap >= rang_exige else RANG_IMPOSSIBLE


def rang_reel_en_vigueur(b: bytes) -> bool:
    """Mode « rang réel » (apRangReel, verrous.cpp) : verrou des rangs (k = 18) et mode 20 compilés et actifs (la
    sauvegarde liée est vérifiée à part par le jeu)."""
    v = dec_verrous(b)
    return _verrou_en_vigueur(v, VERROU_RANGS) and _verrou_en_vigueur(v, VERROU_RANG_REEL)


def rang_reel_cible(b: bytes, rang: int) -> int:
    """Modèle de apRangReelImage : rang réel de la montre (octet O + 0x2E) après une image de terrain d'une sauvegarde
    liée dont le rang vaut `rang`. Mode « rang réel » : max(rang, min(recu[18], A)) (jamais de baisse, rang S gardé) ;
    sinon inchangé."""
    if not rang_reel_en_vigueur(b):
        return rang
    return max(rang, min(dec_verrous(b)["recu"][VERROU_RANGS], RANG_A))


def rang_ecrit_par_script(b: bytes, rang: int, valeur: int, relatif: bool = False, liee: bool = True) -> int:
    """Modèle de la garde 0x004CD6F8 (commande 0x364C, RunkUp) : rang réel après `0x364C(valeur [, relatif])` quand
    il valait `rang`. Mode « rang réel » et sauvegarde liée : une valeur finale E..A (0..4) est ignorée (le rang ne
    vient que de l'objet AP) ; au-dessus (rang S de la requête 28, après-jeu) et hors du mode : écriture d'origine."""
    finale = (rang + valeur if relatif else valeur) & 0xFF
    if liee and rang_reel_en_vigueur(b) and finale <= RANG_A:
        return rang
    return finale


def fenetre_rang_filtree(b: bytes, rang: int, liee: bool = True) -> bool:
    """Modèle de apRangFenetreFiltree (commande 0x35B8, type 17) : la fenêtre « rang » d'un script n'est pas mise en
    file en mode « rang réel » pour E..A (le mod la met en file lui-même quand il monte la montre)."""
    return liee and rang <= RANG_A and rang_reel_en_vigueur(b)


def adr_script(i: int) -> int:
    return ZONE + OFF_SCRIPTS + i * TAILLE_SCRIPT


def adr_nom(i: int) -> int:
    return ZONE + OFF_NOMS + i * TAILLE_NOM


# --- v5 : récompenses de quête ---
def enc_quete(affiche: int = 0, etiquette: int = 0, drapeaux: int = QUETE_VALIDE, texte: str | bytes = b"",
              utilisations: int = 0) -> bytes:
    """Entrée de la table des récompenses de quête (80 octets) ; texte = nom de la vitrine (vide : nom par défaut)."""
    return (struct.pack("<IIBBHI", affiche & 0xFFFFFFFF, etiquette & 0xFFFFFFFF, drapeaux, utilisations, 0, 0)
            + _champ_texte(texte, QUETE_TEXTE) + bytes(8))


def dec_quete(b: bytes) -> dict:
    a, e, d, u, _, _ = struct.unpack_from("<IIBBHI", b)
    return {"affiche": a, "etiquette": e, "drapeaux": d, "utilisations": u, "texte": b[16:16 + QUETE_TEXTE].split(b"\0")[0]}


def dec_quetes_entete(b: bytes) -> dict:
    v, c, n, der = struct.unpack_from("<IIII", b)
    return {"valide": v, "compile": c, "substitutions": n, "derniere": der}


def adr_quete(numero: int) -> int:
    return ZONE + OFF_QUETES_TABLE + numero * TAILLE_QUETE


def recompenses_compilees(entete_quetes: bytes) -> bool | None:
    """Champ `compile` publié par le jeu v5 : True (substitution compilée), False (build sans, --define
    YKW2_AP_SANS_RECOMPENSES), None (non publié : jeu antérieur)."""
    c = struct.unpack_from("<I", entete_quetes, 4)[0]
    if not c & QUETES_PUBLIE:
        return None
    return bool(c & QUETES_COMPILE)


# --- fenêtre « objet obtenu » des checks sans affichage (§27) ---
def enc_anim(numero: int, etiquette: int, affiche: int = 0, ident: int = 0, quantite: int = 1,
             texte: str | bytes = b"") -> bytes:
    """Entrée de la file des fenêtres (80 octets) ; affiche = 0 : la vitrine, nommée par `texte` (vide : nom par
    défaut)."""
    return (struct.pack("<IIIIHBBI", numero & 0xFFFFFFFF, etiquette & 0xFFFFFFFF, affiche & 0xFFFFFFFF,
                        ident & 0xFFFFFFFF, quantite & 0xFFFF, 0, 0, 0) + _champ_texte(texte, ANIM_TEXTE))


def dec_anim(b: bytes) -> dict:
    n, e, a, i, q, d, _r, _r2 = struct.unpack_from("<IIIIHBBI", b)
    return {"numero": n, "etiquette": e, "affiche": a, "ident": i, "quantite": q, "drapeaux": d,
            "texte": b[24:24 + ANIM_TEXTE].split(b"\0")[0]}


def dec_anim_entete(b: bytes) -> dict:
    return dict(zip(ANIM_ENTETE, struct.unpack_from("<11I", b)))


def adr_anim(numero: int) -> int:
    """Adresse de l'entrée n (1, 2, …) de la file des fenêtres."""
    return ZONE + OFF_ANIM_TABLE + ((numero - 1) % CAP_ANIM) * TAILLE_ANIM


def anim_compilee(verrous: bytes) -> bool:
    """Fenêtre « objet obtenu » des checks compilée dans le jeu (bit 29 de `compiles`, liste publiée)."""
    return option_compilee(verrous, FONCTION_ANIM)


# --- Yo-criminels trouvables (docs/systemes/archipelago_criminels_combats_jour.md §8) ---
# Fonction 30 de `compiles` (information : aucune graine ne l'exige, le client n'écrit rien). Quand le bit est publié,
# le jeu tient un diagnostic de 0x20 octets dans sa zone privée (ApCriminels, src/archipelago/boite.h) ; ces octets
# valent 0 dans un jeu antérieur : ne les lire que si le bit est publié.
FONCTION_CRIMINELS_TROUVABLES = 30
OFF_CRIMINELS, TAILLE_CRIMINELS = OFF_PRIVE + 0x80, 0x20
CRIMINELS_MOTIFS = {0: "un criminel est posé (rien à faire)", 1: "sauvegarde non liée",
                    2: "singleton du jeu absent (transition)", 3: "Yo-criminels pas débloqués, ou fenêtre fermée",
                    4: "tous les Yo-criminels sont arrêtés", 5: "aucun emplacement, tirage déjà fait pendant ce passage",
                    6: "tirage fait"}
CRIMINELS_CAUSES = {0: "aucun", 1: "aucun emplacement posé", 2: "criminel proposé changé (arrestation complète)"}
# Octets globaux de catégorie 6 (P + 0x144 + index) et bits globaux (catégorie 0) des Yo-criminels [C]
OCTET_WANTED_NO, OCTET_WANTED_LIEU = 21, 23          # criminel stocké (écrit par le jeu), emplacement (1..30, 0 aucun)
FLAG_WANTED_OUVERT, FLAG_WANTED_FERME_1, FLAG_WANTED_FERME_2 = 69, 62, 63
FLAG_WANTED_SEMAINE, FLAG_WANTED_TOUS = 2072, 2073
# Les 5 cartes de la ville (WANTED_MAP, dans l'ordre de wanted_config) : point p (1..30) = carte (p - 1) // 6, rang
# (p - 1) % 6. Noms internes de cartes (déjà dans le dépôt : cartes du tracker), pas des données du jeu en masse.
CARTES_CRIMINELS = ("t101g00", "t103g00", "t104g00", "t105g00", "t106g00")
POINTS_PAR_CARTE = 6


def carte_du_point(point: int) -> int | None:
    """Index (0..4) de la carte de la ville du point `point` (1..30), None sinon."""
    return (point - 1) // POINTS_PAR_CARTE if 1 <= point <= len(CARTES_CRIMINELS) * POINTS_PAR_CARTE else None


def point_homologue(point: int, carte: int | None) -> int:
    """Modèle d'apCriminelsEmplacementVu (limites.cpp) : valeur de l'emplacement vue par les NPC_APPEAR quand le
    joueur est sur la carte de la ville d'index `carte` (None : hors des 5 cartes) : le point de même rang."""
    if carte is None or carte_du_point(point) is None or not 0 <= carte < len(CARTES_CRIMINELS):
        return point
    return carte * POINTS_PAR_CARTE + (point - 1) % POINTS_PAR_CARTE + 1


def points_homologues(point: int) -> list[int]:
    """Les 5 points (un par carte) où le criminel posé au point `point` est visible ; [] si aucun n'est posé."""
    if carte_du_point(point) is None:
        return []
    return [point_homologue(point, c) for c in range(len(CARTES_CRIMINELS))]


def criminels_trouvables_compiles(verrous: bytes) -> bool:
    """Yo-criminels trouvables compilés dans le jeu (bit 30 de `compiles`, liste publiée)."""
    return option_compilee(verrous, FONCTION_CRIMINELS_TROUVABLES)


def dec_criminels(b: bytes) -> dict:
    """ApCriminels (0x20 octets à OFF_CRIMINELS) : état et diagnostic du jeu."""
    terrain, carte = struct.unpack_from("<II", b, 0)
    miroirs, evaluations = struct.unpack_from("<II", b, 0x14)
    return {"terrain": terrain, "carte": carte, "carte_lieu": b[8], "dernier": b[9], "criminel": b[0xA], "lieu": b[0xB],
            "motif": b[0xC], "tirages": b[0xD], "tire_avant": b[0xE], "tire_apres": b[0xF], "tire_cause": b[0x10],
            "vu_stocke": b[0x11], "vu_rendu": b[0x12], "rafraichis": b[0x13], "miroirs": miroirs,
            "evaluations": evaluations}


# --- Invités de l'Auberge des voyageurs (docs/systemes/archipelago_invites.md §14, archipelago_boite.md §31) ---
# Zone ApInvites (0x200 octets) dans le trou de la zone v10 entre la table M de ap/boss-adaptes (0x22800..0x23000) et l'enregistreur de
# panique (0x23E00) : version et taille inchangées. `compile` (J, +0) ; le client écrit ident (+8), nombre (+0xC) et la
# liste (+0xC0, 8 octets par invité : CHARA_PARAM, n° du Médaillium u16, drapeaux u8), puis `sequence` (+4) EN DERNIER,
# et SEULEMENT si le jeu publie INVITES_COMPILE. `forcer` (+0x10) n'est écrit que par `ap_boite_test.py invites`.
# Le n° FONCTION_INVITES de `fonctions_exigees` (slot_data) désigne les invités : il n'est JAMAIS publié dans
# ApVerrous::compiles (un client d'avant les invités refuse donc la graine : « Verrous incompatibles ») ; ce client-ci
# le vérifie dans ApInvites::compile.
FONCTION_INVITES = 23
OFF_INVITES, TAILLE_INVITES, CAP_INVITES, TAILLE_INVITE = 0x23000, 0x200, 32, 8
OFF_INVITES_LISTE, INVITES_TEXTE = 0xC0, 0x60
INVITES_PUBLIE = 0x80000000
INVITES_COMPILE, INVITES_NIVEAU, INVITES_AMITIE, INVITES_ANNONCE, INVITES_ESPECE = 0x01, 0x02, 0x04, 0x08, 0x10
INVITES_CHAMBRES = 0x20                              # les neuf chambres logent aussi un invité
# Règle d'affectation « Suite réservée, chambres gardées » (archipelago_invites.md §18) : la Suite ne loge que
# Pandanoko (reconnu par son CHARA_PARAM, INVITES_PARAM_PNJ), les autres invités seulement les chambres 101 à 109 (neuf
# à la fois), et un invité logé GARDE sa chambre jusqu'à l'amitié (personne ne se décale ; la chambre libérée va au
# premier de la file). Le JEU décide et signale chaque chambre attribuée (EVT_INVITE_CHAMBRE) ; le client la note pour
# la sauvegarde liée (liaisons.json) et la réécrit dans l'entrée de l'invité (octet +7) : elle vaut d'un lancement à
# l'autre. Le client ne calcule donc RIEN pour ce patch : `invites.json` dit ce que le jeu a confirmé.
# Sans ce bit (patch d'avant le 2026-10-09) : la Suite d'abord puis les chambres, pour tous, et tout le monde avance ;
# le client refait alors ce calcul-là pour le lanceur (`regle_invites`).
INVITES_SUITE_RESERVEE = 0x40
# Pièces d'invité (archipelago_invites.md §15) : 0 = Suite (t103i69), 1..9 = chambres 101..109 (t103i60..68) ; CRC-32
# du nom de carte, hachage et index du bit global de la pièce (`appear_sasurai_npc%02d` pour les chambres)
INVITES_PIECES = 10
INVITES_NOMS_PIECES = ("Suite",) + tuple(f"chambre {101 + i}" for i in range(9))
INVITES_CARTES_NOMS = ("t103i69",) + tuple(f"t103i6{i}" for i in range(9))
INVITES_CARTES = (0x98CDF955, 0xE11141F1, 0x96167167, 0x0F1F20DD, 0x7818104B,
                  0xE67C85E8, 0x917BB57E, 0x0872E4C4, 0x7F75D452, 0xEFCAC9C3)
INVITES_FLAGS = (0x3CDB0D89, 0x278F7E9D, 0x50884E0B, 0xC9811FB1, 0xBE862F27,
                 0x20E2BA84, 0x57E58A12, 0xCEECDBA8, 0xB9EBEB3E, 0x2954F6AF)
INVITES_BITS = (1502, 1505, 1506, 1507, 1508, 1509, 1510, 1511, 1512, 1513)
INVITES_PNJ = 0x95C2369D                             # crc32("npc_sasurai")
INVITES_BASE_SUITE, INVITES_BASE_CHAMBRE = 0xBD17305C, 0xF1CFD67A   # bases d'origine du PNJ (Pandanoko, attente)
# Motif du dernier refus de l'accroche (ApInvites::refus_motif, valeur en cause dans `refus_valeur`). Le mot +8 d'un
# NPC_BASE est le POINTEUR de l'enregistrement CHARA_BASE (FUN_004C32F8 -> FUN_0064DF3C), pas le hachage de la base.
INVITES_REFUS_AUCUN, INVITES_REFUS_POINTEUR, INVITES_REFUS_ORIGINE, INVITES_REFUS_PARAM, INVITES_REFUS_BASE = range(5)
INVITES_REFUS = {
    INVITES_REFUS_AUCUN: "aucun",
    INVITES_REFUS_POINTEUR: "le mot +8 du NPC_BASE n'est pas un pointeur d'enregistrement CHARA_BASE (mot lu : {v:#010x})",
    INVITES_REFUS_ORIGINE: "base d'origine du PNJ inattendue (base lue : {v:#010x})",
    INVITES_REFUS_PARAM: "CHARA_PARAM de l'invité introuvable dans le jeu ({v:#010x})",
    INVITES_REFUS_BASE: "enregistrement CHARA_BASE de la base de l'invité introuvable (base {v:#010x})",
}
# Valeurs RÉELLES lues dans un état d'Azahar pris dans la Suite (2026-10-09, ROM européenne) : CHARA_PARAM -> base
# (FUN_003AE640 -> +4), base -> adresse de l'enregistrement CHARA_BASE (FUN_0064DF3C ; +0 = la base). Servent au modèle
# du jeu des tests ; les adresses ne sont dans aucun code du jeu ni du client.
INVITES_JEU_PARAMS = {0xDB1CC069: 0xBD17305C, 0x33077779: 0x550C874C}            # Pandanoko, Corniot
INVITES_JEU_BASES = {0xBD17305C: 0x084F51E4, 0x550C874C: 0x084F2C3C, 0xF1CFD67A: 0x084F647C}


def pointeur_du_jeu(p: int) -> bool:
    """pointeurDuJeu d'invites.cpp : mot aligné dans le tas ordinaire ou la mémoire linéaire."""
    return p & 3 == 0 and (0x08000000 <= p < 0x10000000 or 0x14000000 <= p < 0x1C000000)


def texte_refus_invite(motif: int, valeur: int) -> str:
    return INVITES_REFUS.get(motif, f"motif {motif} ({{v:#010x}})").format(v=valeur)
INVITE_DECLARE, INVITE_ANNONCE = 0x01, 0x02
INVITES_FEN_AUCUNE, INVITES_FEN_AJOUTEE, INVITES_FEN_OUVERTE = 0, 1, 2
INVITES_FEN_ETATS = {0: "aucune", 1: "ajoutée (ouverture attendue)", 2: "ouverte (appui attendu)"}
(INVITES_MOTIF_AUCUN, INVITES_MOTIF_LISTE, INVITES_MOTIF_PARTIE, INVITES_MOTIF_NON_DECLARE, INVITES_MOTIF_TOUS_AMIS,
 INVITES_MOTIF_ESPECE, INVITES_MOTIF_PIECES) = range(7)
INVITES_MOTIFS = {
    INVITES_MOTIF_AUCUN: "un invité est présent",
    INVITES_MOTIF_LISTE: "pas de liste valide (client absent, ou graine sans invité)",
    INVITES_MOTIF_PARTIE: "pas de partie, ou sauvegarde non liée / autre que celle de la liste",
    INVITES_MOTIF_NON_DECLARE: "aucun invité déclaré (déclencheur pas encore rempli)",
    INVITES_MOTIF_TOUS_AMIS: "tous les invités déclarés sont déjà amis",
    INVITES_MOTIF_ESPECE: "l'invité courant n'est pas l'espèce d'origine du PNJ (patch antérieur)",
    INVITES_MOTIF_PIECES: "des invités attendent mais aucune pièce n'est libre pour eux (errants StreetPass des "
                          "chambres, Suite prise par le jeu)",
}
INVITES_IMAGES_SURES, INVITES_IMAGES_OUVERTURE = 30, 90
INVITES_TEXTE_HASH = 0x8277B40F                      # crc32("ap_invite_fenetre") : faux label de texte de l'annonce
EVT_INVITE = 8                                       # journal : annonce fermée (id = CHARA_PARAM, valeur = n° du
#                                                      Médaillium, index = rang dans la liste, valeur2 = séquence)
INVITES_FLAG_SUITE, INVITES_FLAG_AMITIE = 0x3CDB0D89, 0xABCB4EE6   # bits globaux 1502 et 24 (lus, jamais écrits)
INVITES_RENCONTRE = 0x713FE778                       # rencontre de script du combat de la Suite (ev98_0100)
INVITES_CARTE_SUITE = 0x98CDF955                     # crc32("t103i69")
INVITES_PARAM_PNJ, INVITES_NIVEAU_PNJ = 0xDB1CC069, 10   # combattant d'origine (Pandanoko, niveau 10)
P_AMIS_COMP, P_AMIS_COMPEX = 0x44C, 0x604            # bits « ami » du Médaillium (bit n = octet n >> 3, bit n & 7)
INVITES_CHAMPS = ("compile", "sequence", "ident", "nombre", "forcer", "param_ecrit", "base_ecrite", "fen_masque",
                  "present", "annoncees", "etat", "images", "fenetres", "montrees", "annulees", "textes")   # 16 u32
INVITES_OCTETS = ("en_suite", "combat_vu", "combat_invite", "niveau_ecrit", "niveau_equipe", "fen_invite",
                  "motif", "piece_chargee")                                                 # u8 à partir de +0x40
INVITES_COMPTEURS = ("lectures", "amities", "combats", "niveaux", "restaurations", "especes")   # u32 à partir de +0x48
# fin de la zone (J) : pieces[10] +0x1C0, invite_charge +0x1CA, visite +0x1CB, occupees u16 +0x1CC, retour +0x1CE,
# refus_motif +0x1CF, puis charges, refus, especes_combat, refus_valeur, champ_lu, base_lue (u32 à partir de +0x1D0)
OFF_INVITES_PIECES = 0x1C0
# (privé, J) chambres TENUES : garde[10] +0x1E8 (rang + 1 de l'invité qui tient la chambre p = 1..9), signale u16
# +0x1F2, garde_ident +0x1F4, signale_seq +0x1F8 (anciennes réserves : 0 dans un patch antérieur)
OFF_INVITES_GARDE = 0x1E8
EVT_INVITE_CHAMBRE = 9                               # journal : un invité tient une chambre que la liste du client ne
                                                     # connaît pas (id = CHARA_PARAM, valeur = n° du Médaillium, index =
                                                     # rang, quantité = chambre 1..9) : à mémoriser (liaisons.json)
INVITES_FIN_OCTETS = ((0x1CA, "invite_charge"), (0x1CB, "visite"), (0x1CE, "retour"), (0x1CF, "refus_motif"))
INVITES_FIN_COMPTEURS = ("charges", "refus", "especes_combat", "refus_valeur", "champ_lu", "base_lue")   # u32 à partir de +0x1D0
# Texte de l'annonce (composerTexte d'invites.cpp ; langue des notifications), deux lignes : chacune tient dans la
# largeur des lignes des messages d'information du jeu lui-même (au plus ~116 demi-unités du modèle de largeur_car :
# « disponibles à la Librairie Plume, au », `sys_info_win_*`).
INVITES_ANNONCE_TEXTE = {0: "Un Yo-kai est apparu à l'Auberge\ndes voyageurs, allez le voir.",
                         1: "A Yo-kai has appeared at\nWayfarer Manor, go and see it."}
INVITES_LARGEUR_LIGNE = 116


# --- PNJ des cartes et fonctions ÉTENDUES du patch (src/archipelago/pnj.cpp, boite.h ApPnj ; archipelago_boite.md §32) ---
# Les 32 bits de `compiles` sont pris : une fonction étendue n (>= 32) est publiée dans le bit n - 32 de ApPnj::fonctions
# (0x40 octets juste après ApInvites, même trou de la zone v10 : 0 dans un jeu antérieur). Dans `fonctions_exigees`,
# une graine qui en exige une ajoute FONCTION_ETENDUES (22), JAMAIS publié dans `compiles` : un client d'avant les
# fonctions étendues (qui ignore les n° >= 31) refuse la graine sur le 22 ; ce client-ci retire le 22 et vérifie chaque
# n° >= 32 dans ApPnj::fonctions, lu UNE fois par instance du jeu et seulement si la graine en exige. Le client n'écrit
# dans cette zone que `ev_declares` / `ev_ident` (8 octets en +0x24), et seulement si le jeu publie la fonction 34.
FONCTION_ETENDUES = 22
FONCTION_ETENDUE_BASE = 32
FONCTION_DEUX_ULTRAMAX = 32          # Ultramax N et K dans la même partie (archipelago_ultramax_deux.md)
FONCTION_INVITES_ESPECE = 33         # invités de l'Auberge à leur espèce (archipelago_invites.md §15)
# Yo-kai d'évènement à leur emplacement d'origine (archipelago_evenement_invitation.md §9) : quand l'objet AP du
# Yo-kai k est reçu, le client pose le bit k de ApPnj::ev_declares (avec l'identifiant de partie en `ev_ident`) ; le
# jeu neutralise alors les clauses « jeu fini » / « transfert » de la condition d'apparition de SON PNJ.
FONCTION_EVENEMENT_PLACE = 34
# Même fonction, version corrigée (2026-10-09, archipelago_evenement_invitation.md §10) : le Yo-kai n'apparaît que
# lorsque sa place est LIBRE (Jibanyan S : Jibanyan déjà ami ET flag « évènement vu » ev01_2200 ; Hovernyan : flag de
# fin du chapitre 6). Publiée par le jeu (bit 3 de ApPnj::fonctions) ; exigée par les graines générées depuis : un
# patch d'avant (Jibanyan S par-dessus le Jibanyan de l'histoire au chapitre 1 : histoire bloquée) est refusé. Rien de
# plus à faire pour le client : n° vérifié comme toute fonction étendue.
FONCTION_EVENEMENT_LIBRE = 35
# N° JAMAIS publié par le jeu, ajouté par une graine dont une fonction demande au CLIENT d'écrire quelque chose de
# nouveau (ici `ev_declares`) : un client d'avant tient tout n° >= 63 pour absent et refuse la graine, même avec le
# patch à jour ; ce client-ci le retire.
FONCTION_CLIENT_2 = 63
# Idem pour une LECTURE nouvelle du client (archipelago_boss.md §11) : entrée {location, octet, seuil} de la liste `boss`
# (« Boss : Taprice » : octet global de progression du Tunnel sans fin). Un client d'avant ignorerait l'entrée sans
# rien dire (check jamais envoyé) : il refuse la graine sur ce n°, que ce client-ci retire.
FONCTION_CLIENT_3 = 64
FONCTIONS_CLIENT_CONNUES = frozenset({FONCTION_CLIENT_2, FONCTION_CLIENT_3})
# Boss détecté par un octet global de catégorie 6 (P + P_FLAGS_OCTETS + index) qui ne décroît jamais : pseudo-flag
# rangé avec les flags de boss (catalogue, instantané de liaison `boss`), au-dessus de tout index de flag bit réel
# (FLAG_GLOBAL_MAX < 0x10000). Lu comme les 8 flags bit de son octet, dans la même lecture groupée que les autres.
BOSS_OCTET_BASE = 0x100000


def boss_octet_valide(octet: int, seuil: int) -> bool:
    """Octet global lisible par le client (avant les octets du mod, P + P_LIAISON) et seuil d'un octet non nul."""
    return 0 <= octet < P_LIAISON - P_FLAGS_OCTETS and 1 <= seuil <= 255


def boss_octet_pseudo(octet: int, seuil: int) -> int:
    """Pseudo-flag d'un boss détecté par « octet global `octet` >= `seuil` »."""
    return BOSS_OCTET_BASE | (octet & 0xFFF) << 8 | (seuil & 0xFF)


def boss_octet_decode(pseudo: int) -> tuple[int, int] | None:
    """(octet, seuil) d'un pseudo-flag de `boss_octet_pseudo`, None pour un flag bit ordinaire."""
    if pseudo < BOSS_OCTET_BASE:
        return None
    return (pseudo >> 8) & 0xFFF, pseudo & 0xFF


def boss_octet_flags(octet: int) -> list[int]:
    """Les 8 index de flags bit globaux (bit i % 8 de P + 4 + i // 8) qui recouvrent l'octet global `octet`
    (P + 0x144 + octet), du bit 0 au bit 7."""
    base = (P_FLAGS_OCTETS + octet - P_FLAGS_GLOBAUX) * 8
    return list(range(base, base + 8))


def boss_octets_atteints(pseudos, poses) -> set[int]:
    """Parmi les pseudo-flags `pseudos`, ceux dont l'octet (reconstruit depuis les flags bit `poses`) atteint le seuil."""
    out = set()
    for p in pseudos:
        d = boss_octet_decode(p)
        if d is None:
            continue
        valeur = sum(1 << k for k, f in enumerate(boss_octet_flags(d[0])) if f in poses)
        if valeur >= d[1]:
            out.add(p)
    return out
EV_JIBANYAN_S, EV_KOMASAN_S, EV_KOMAJIRO_S, EV_HOVERNYAN, EV_NOMBRE = 0, 1, 2, 3, 4
EV_NOMS = ("Jibanyan S", "Komasan S", "Komajiro S", "Hovernyan")
EV_MEDAILLES = (433, 434, 435, 351)
EV_CARTES = ("t101g00", "t104i27", "t104g00", "t231i01")
EV_APPARITIONS = ("y1529000_01_01", "y159900_01_01", "y159910_01_01", "y236000_01")   # NPC_APPEAR +4
EV_LONGUEURS = (194, 50, 17, 26)                     # u16 +1 de la condition décodée (longueur - 3)
EV_FLAG_FINI, EV_OCTET_TRANSFERT, EV_GAMECLEAR = 0x176F56BB, 0xB3E9494F, 0x10B14096
EV_JIB_CLAUSE_1, EV_JIB_CLAUSE_2 = 23, 46            # Jibanyan S : jetons « entier 1, == » (le 2e est neutralisé)
EV_FLAG_OFFSET = 19                                  # k = 0, 3 : hachage du flag de la 1re clause, remplacé par :
EV_JIB_FLAG_LIBRE = 0xC3966699                       # crc32("ev01_2200"), bit global n° 128 : place de Jibanyan S libre
EV_HOV_FLAG_LIBRE = 0xD4058588                       # bit global n° 281 : chapitre 6 fini (pièce de Hovernyan libre)
EV_JIB_AMI_MEDAILLE = 135                            # Jibanyan S attend que Jibanyan (n° 135) soit ami
EV_FLAGS_LIBRES = {EV_JIBANYAN_S: EV_JIB_FLAG_LIBRE, EV_HOVERNYAN: EV_HOV_FLAG_LIBRE}
OFF_PNJ_EV_ATTENTE = 0x12                            # u8 ev_attente (J) : bit k = déclaré mais en attente (k = 0)
OFF_PNJ_EV = 0x24                                    # ev_declares (C), ev_ident (C), ev_forcer (T), puis J
PNJ_EV_CHAMPS = ("ev_declares", "ev_ident", "ev_forcer", "ev_poses", "ev_charges", "ev_ecrits", "ev_refus")
OFF_PNJ, TAILLE_PNJ = 0x23200, 0x40
PNJ_PUBLIE = 0x80000000
ULTRAMAX_N, ULTRAMAX_K = 1, 2
ULTRAMAX_NOMS = {0: "celui du personnage joué", ULTRAMAX_N: "Ultramax N", ULTRAMAX_K: "Ultramax K"}
ULTRAMAX_MEDAILLE_N, ULTRAMAX_MEDAILLE_K = 431, 432
ULTRAMAX_CARTE = 0x507C7926          # crc32("t131g00") : Ourcival
ULTRAMAX_OBJET = 0xF2A2F16F          # Marque d'Ultramax
PNJ_CHAMPS = ("fonctions", "accroches", "contexte")                       # u32 à partir de +0
PNJ_OCTETS = ("um_forcer", "um_voulu", "um_quitte", "um_montre", "um_genre", "um_amis")   # u8 à partir de +0x0C
PNJ_COMPTEURS = ("um_charges", "um_echanges", "um_choix", "um_refus")     # u32 à partir de +0x14


def dec_pnj(b: bytes) -> dict:
    """ApPnj (0x40 octets à OFF_PNJ)."""
    d = dict(zip(PNJ_CHAMPS, struct.unpack_from("<3I", b, 0)))
    d.update(zip(PNJ_OCTETS, b[0x0C:0x0C + len(PNJ_OCTETS)]))
    d.update(zip(PNJ_COMPTEURS, struct.unpack_from("<4I", b, 0x14)))
    d.update(zip(PNJ_EV_CHAMPS, struct.unpack_from("<7I", b, OFF_PNJ_EV)))
    d["ev_attente"] = b[OFF_PNJ_EV_ATTENTE]
    return d


def ecriture_evenement(masque: int, ident: int) -> tuple[int, bytes]:
    """(adresse, octets) de `ev_declares` + `ev_ident` (8 octets, une seule écriture, jeu arrêté). Ne touche ni
    `ev_forcer` (outil de test) ni les champs du jeu."""
    return ZONE + OFF_PNJ + OFF_PNJ_EV, struct.pack("<II", masque & ((1 << EV_NOMBRE) - 1), ident & 0xFFFFFFFF)


def evenement_attend(k: int, declare: bool, jibanyan_ami: bool) -> bool:
    """Objet reçu mais apparition en attente (`ev_attente`) : Jibanyan S tant que Jibanyan n'est pas ami."""
    return declare and k == EV_JIBANYAN_S and not jibanyan_ami


def evenement_condition(k: int, cond: bytes | None, declare: bool,
                        jibanyan_ami: bool = True) -> tuple[bytes | None, bool]:
    """Modèle d'`evenementCharges` (pnj.cpp) pour l'apparition du Yo-kai k : (condition après l'accroche — None =
    pointeur nul = sans condition —, refus). Non déclaré, ou en attente (Jibanyan S sans Jibanyan ami) : inchangée.
    Condition inattendue : inchangée, refus. Jibanyan S et Hovernyan gardent une condition : leur 1re clause lit le
    flag « place libre » (EV_FLAGS_LIBRES) au lieu de « jeu fini »."""
    if not declare or evenement_attend(k, declare, jibanyan_ami):
        return cond, False

    def cite(c: bytes, h: int) -> bool:
        fin = 3 + (c[1] | c[2] << 8)
        return fin <= 256 and h.to_bytes(4, "big") in c[3:fin]
    un_egal = b"\x32\x00\x00\x00\x01\x78"
    ok = cond is not None and len(cond) >= 3 and cond[0] == 0 and (cond[1] | cond[2] << 8) == EV_LONGUEURS[k] \
        and len(cond) >= EV_LONGUEURS[k] + 3
    if ok and k == EV_JIBANYAN_S:
        ok = cond[19:23] == EV_FLAG_FINI.to_bytes(4, "big") and cond[23:29] == un_egal \
            and cond[42:46] == EV_OCTET_TRANSFERT.to_bytes(4, "big") and cond[46:52] == un_egal
    elif ok and k == EV_KOMASAN_S:
        ok = cite(cond, EV_FLAG_FINI) and cite(cond, EV_OCTET_TRANSFERT)
    elif ok and k == EV_KOMAJIRO_S:
        ok = cite(cond, EV_GAMECLEAR)
    elif ok:
        ok = cond[19:23] == EV_FLAG_FINI.to_bytes(4, "big") and cond[23:29] == un_egal
    if not ok:
        return cond, True
    if k not in EV_FLAGS_LIBRES:
        return None, False
    c = bytearray(cond)
    c[EV_FLAG_OFFSET:EV_FLAG_OFFSET + 4] = EV_FLAGS_LIBRES[k].to_bytes(4, "big")
    if k == EV_JIBANYAN_S:
        c[EV_JIB_CLAUSE_2 + 1:EV_JIB_CLAUSE_2 + 6] = b"\x7F\xFF\xFF\xFF\x79"
    return bytes(c), False


def fonctions_etendues(b: bytes) -> int | None:
    """Bits des fonctions étendues compilées dans le jeu (bit b = fonction 32 + b), None si le champ n'est pas publié
    (jeu antérieur aux fonctions étendues)."""
    c = struct.unpack_from("<I", b, 0)[0]
    return c & ~PNJ_PUBLIE if c & PNJ_PUBLIE else None


def fonction_etendue_compilee(bits: int | None, n: int) -> bool:
    return (bits is not None and FONCTION_ETENDUE_BASE <= n < FONCTION_ETENDUE_BASE + 31
            and bool(bits >> (n - FONCTION_ETENDUE_BASE) & 1))


def ultramax_choix(voulu: int, quitte: bool, genre: int, ami_n: bool, ami_k: bool) -> int:
    """Modèle d'apUltramaxImage (pnj.cpp), joueur libre sur une autre carte qu'Ourcival : Ultramax voulu au prochain
    chargement d'Ourcival. Celui qui n'est pas encore ami ; si aucun ou les deux le sont : alternance à chaque sortie
    d'Ourcival (`quitte`), en commençant par celui du personnage joué (`genre` : 1 garçon -> N, 2 fille -> K)."""
    if ami_n != ami_k:
        return ULTRAMAX_K if ami_n else ULTRAMAX_N
    if voulu not in (ULTRAMAX_N, ULTRAMAX_K):
        voulu = ULTRAMAX_K if genre == 2 else ULTRAMAX_N
    return ULTRAMAX_N + ULTRAMAX_K - voulu if quitte else voulu


def ultramax_montre(forcer: int, voulu: int, genre: int) -> tuple[int, bool]:
    """Modèle de l'accroche (ultramaxCharges) : (Ultramax montré au chargement d'Ourcival, conditions échangées)."""
    naturel = ULTRAMAX_K if genre == 2 else ULTRAMAX_N
    v = forcer if forcer in (ULTRAMAX_N, ULTRAMAX_K) else voulu
    if v not in (ULTRAMAX_N, ULTRAMAX_K):
        v = naturel
    return v, v != naturel


def texte_annonce_invite(langue: int = 0) -> bytes:
    """Texte que le jeu compose pour l'annonce d'un invité (invites.cpp)."""
    return INVITES_ANNONCE_TEXTE[1 if langue == 1 else 0].encode("utf-8")[:INVITES_TEXTE - 1]


def enc_invite(param: int, medaille: int, drapeaux: int = 0, chambre: int = 0) -> bytes:
    """Entrée ApInvite (8 octets). `chambre` : chambre mémorisée pour cet invité (1..9 = 101..109, 0 : aucune)."""
    return struct.pack("<IHBB", param & 0xFFFFFFFF, medaille & 0xFFFF, drapeaux & 0xFF,
                       chambre if 0 < chambre < INVITES_PIECES else 0)


def dec_invite(b: bytes) -> dict:
    param, medaille, drapeaux, chambre = struct.unpack_from("<IHBB", b)
    return {"param": param, "medaille": medaille, "drapeaux": drapeaux, "chambre": chambre}


def dec_invites(b: bytes) -> dict:
    """ApInvites (0x200 octets à OFF_INVITES)."""
    d = dict(zip(INVITES_CHAMPS, struct.unpack_from("<16I", b, 0)))
    d.update(zip(INVITES_OCTETS, b[0x40:0x40 + len(INVITES_OCTETS)]))
    d.update(zip(INVITES_COMPTEURS, struct.unpack_from("<6I", b, 0x48)))
    d["texte"] = bytes(b[0x60:0x60 + INVITES_TEXTE]).split(b"\0")[0]
    n = min(d["nombre"], CAP_INVITES)
    d["liste"] = [dec_invite(b[OFF_INVITES_LISTE + i * TAILLE_INVITE:]) for i in range(n)]
    d["pieces"] = list(b[OFF_INVITES_PIECES:OFF_INVITES_PIECES + INVITES_PIECES])
    for off, nom in INVITES_FIN_OCTETS:
        d[nom] = b[off]
    d["occupees"] = struct.unpack_from("<H", b, 0x1CC)[0]
    d.update(zip(INVITES_FIN_COMPTEURS, struct.unpack_from("<%dI" % len(INVITES_FIN_COMPTEURS), b, 0x1D0)))
    d["garde"] = list(b[OFF_INVITES_GARDE:OFF_INVITES_GARDE + INVITES_PIECES])
    d["signale"], d["garde_ident"], d["signale_seq"] = struct.unpack_from("<HII", b, OFF_INVITES_GARDE + INVITES_PIECES)
    return d


def invites_compiles(b: bytes) -> int | None:
    """Bits INVITES_* compilés dans le jeu (début de ApInvites), None si le champ n'est pas publié (jeu antérieur aux
    invités, ou compilé sans)."""
    c = struct.unpack_from("<I", b, 0)[0]
    return c & ~INVITES_PUBLIE if c & INVITES_PUBLIE else None


def ecritures_invites(invites: list[tuple], ident: int, sequence: int) -> list[tuple[int, bytes]]:
    """Écritures (adresse, octets) de la liste des invités, dans l'ordre : liste, puis ident et nombre, puis `sequence`
    EN DERNIER. `invites` = [(CHARA_PARAM, n° du Médaillium, drapeaux[, chambre])] dans l'ordre de la graine. Ne touche ni
    `compile` ni `forcer`."""
    if len(invites) > CAP_INVITES:
        raise ValueError("trop d'invités")
    liste = b"".join(enc_invite(*x) for x in invites).ljust(CAP_INVITES * TAILLE_INVITE, b"\0")
    base = ZONE + OFF_INVITES
    return [(base + OFF_INVITES_LISTE, liste),
            (base + 8, struct.pack("<II", ident & 0xFFFFFFFF, len(invites))),
            (base + 4, struct.pack("<I", sequence & 0xFFFFFFFF))]


def regle_invites(compile_bits: int | None) -> tuple[int, bool]:
    """(nombre de pièces d'invité, Suite réservée à Pandanoko) d'après les bits INVITES_* publiés par le jeu : la règle
    d'`affecter` que CE patch applique. Patch d'avant la Suite réservée : 10 pièces pour tous (ou la Suite seule, pour
    un build d'essai sans les chambres)."""
    c = compile_bits or 0
    return (INVITES_PIECES if c & INVITES_CHAMBRES else 1), bool(c & INVITES_SUITE_RESERVEE)


def affectation_gardee(liste: list[tuple], amis: set[int], occupees: int = 0,
                        garde: list[int] | None = None) -> tuple[list[int], int, list[int]]:
    """Modèle d'`affecter` (invites.cpp), règle « Suite réservée, chambres gardées ». `liste` = [(CHARA_PARAM, n° du
    Médaillium, déclaré[, chambre mémorisée par le client : 1..9, 0 aucune])] ; `amis` = n° déjà amis ; `occupees` :
    bit p = pièce p dont le jeu se sert ; `garde` : rang + 1 de l'invité qui tenait chaque chambre à l'image précédente
    (mémoire du jeu, même liste ; None : aucune). Rend ([rang + 1 de l'invité LOGÉ dans chaque pièce], motif, [rang + 1
    de l'invité qui TIENT chaque pièce, logé ou non]).
      0. Pandanoko tient la Suite (pièce 0) ; il ne compte pas dans les chambres et n'en attend jamais une ;
      1. un candidat (déclaré, pas encore ami) tient la chambre mémorisée par le client ;
      2. sinon celle qu'il tenait à l'image précédente ;
      3. les candidats sans chambre prennent, dans l'ordre de la liste, les chambres que personne ne tient et dont le
         jeu ne se sert pas ; les suivants attendent. Personne ne change jamais de chambre."""
    t = [0] * INVITES_PIECES
    candidats, chambres, tient = set(), [], set()
    des_amis = False
    for i, e in enumerate(liste[:CAP_INVITES]):
        param, medaille, declare = e[0], e[1], e[2]
        if not param or not 0 < medaille < 512 or not declare:
            continue
        if medaille in amis:
            des_amis = True
            continue
        candidats.add(i)
        if param == INVITES_PARAM_PNJ:
            if not t[0]:
                t[0] = i + 1
            continue
        chambres.append(i)
        c = e[3] if len(e) > 3 else 0
        if 1 <= c < INVITES_PIECES and not t[c]:
            t[c] = i + 1
            tient.add(i)
    for p in range(1, INVITES_PIECES):
        g = garde[p] if garde else 0
        if not t[p] and g and g - 1 in chambres and g - 1 not in tient:
            t[p] = g
            tient.add(g - 1)
    p = 1
    for i in chambres:
        if i in tient:
            continue
        while p < INVITES_PIECES and (t[p] or occupees >> p & 1):
            p += 1
        if p >= INVITES_PIECES:
            break
        t[p] = i + 1
        tient.add(i)
    loges = [0 if occupees >> q & 1 else g for q, g in enumerate(t)]
    motif = INVITES_MOTIF_AUCUN if any(loges) else INVITES_MOTIF_PIECES if candidats \
        else INVITES_MOTIF_TOUS_AMIS if des_amis else INVITES_MOTIF_NON_DECLARE
    return loges, motif, t


def affectation_invites(liste: list[tuple], amis: set[int], occupees: int = 0, pieces: int = INVITES_PIECES,
                        reservee: bool = True, garde: list[int] | None = None) -> tuple[list[int], int]:
    """Qui loge où, selon la règle du patch (`regle_invites`) : ([rang + 1 de l'invité de chaque pièce, 0 = personne]
    sur 10 pièces, motif INVITES_MOTIF_* quand personne n'est logé). `reservee` : règle courante (`affectation_gardee`).
    Sans `reservee` (patch antérieur) : les invités déclarés pas encore amis prennent, dans l'ordre de la liste, les
    `pieces` premières pièces libres, la Suite d'abord (`pieces` = 1 : build d'essai « Suite seule ») ; tout le monde
    avance quand une pièce se libère."""
    if reservee:
        return affectation_gardee(liste, amis, occupees, garde)[:2]
    loges = [0] * INVITES_PIECES
    motif = INVITES_MOTIF_NON_DECLARE
    p = n = 0
    for i, e in enumerate(liste[:CAP_INVITES]):
        param, medaille, declare = e[0], e[1], e[2]
        if not param or not 0 < medaille < 512 or not declare:
            continue
        if medaille in amis:
            if not n and motif == INVITES_MOTIF_NON_DECLARE:
                motif = INVITES_MOTIF_TOUS_AMIS
            continue
        while p < pieces and occupees >> p & 1:
            p += 1
        if p >= pieces:
            if not n:
                motif = INVITES_MOTIF_PIECES
            break
        loges[p] = i + 1
        p += 1
        n += 1
        motif = INVITES_MOTIF_AUCUN
    return loges, motif


def etats_invites(liste: list[tuple], amis: set[int], pieces: int = INVITES_PIECES,
                  reservee: bool = True) -> list[dict]:
    """État de chaque invité pour le lanceur (même ordre que `liste`) : {"etat": "attente" (pas encore déclaré) |
    "file" (déclaré, attend qu'une chambre se libère ; "rang" : sa place dans la file, 1 = le prochain) | "present"
    ("piece" : 0 Suite, 1..9 chambres 101..109) | "ami"}. `pieces`, `reservee` : la règle du patch (`regle_invites`).
    Règle courante (`reservee`) : RIEN n'est calculé ici ; Pandanoko déclaré est dans la Suite, un invité est dans la
    chambre que le jeu lui a attribuée (4e élément de son entrée, mémoire du client), et « dans la file » tant que le
    jeu ne lui en a signalé aucune. Patch antérieur : même calcul que ce patch-là, sans les errants StreetPass du
    joueur (non lus : un invité annoncé dans une chambre qu'un errant occupe est en réalité dans la suivante)."""
    if reservee:
        piece_de: dict[int, int] = {}
        prises: set[int] = set()
        for i, e in enumerate(liste):
            if not e[2] or e[1] in amis:
                continue
            c = 0 if e[0] == INVITES_PARAM_PNJ else (e[3] if len(e) > 3 else 0)
            if (e[0] == INVITES_PARAM_PNJ or 1 <= c < INVITES_PIECES) and c not in prises:
                piece_de[i] = c
                prises.add(c)
    else:
        loges, _motif = affectation_invites(liste, amis, 0, pieces, False)
        piece_de = {g - 1: p for p, g in enumerate(loges) if g}
    etats, attente = [], 0
    for i, e in enumerate(liste):
        if e[1] in amis:
            etats.append({"etat": "ami"})
        elif i in piece_de:
            etats.append({"etat": "present", "piece": piece_de[i]})
        elif e[2]:
            attente += 1
            etats.append({"etat": "file", "rang": attente})
        else:
            etats.append({"etat": "attente"})
    return etats


def invites_zone(zone: bytes, ident_sauvegarde: int, amis: set[int] | None, liee: bool = True, occupees: int = 0,
                 pieces: int = INVITES_PIECES, reservee: bool = True) -> tuple[list[int], int]:
    """`affecter` sur une zone ApInvites lue : ([rang + 1 par pièce], motif). `amis` = n° du Médaillium déjà amis
    (Comp | CompEx) de la sauvegarde chargée, None sans partie."""
    d = dec_invites(zone)
    if d["sequence"] == 0 or not 0 < d["nombre"] <= CAP_INVITES:
        return [0] * INVITES_PIECES, INVITES_MOTIF_LISTE
    if amis is None or d["ident"] == 0 or d["ident"] != ident_sauvegarde or not liee:
        return [0] * INVITES_PIECES, INVITES_MOTIF_PARTIE
    liste = [(e["param"], e["medaille"], bool(e["drapeaux"] & INVITE_DECLARE or d["forcer"] >> i & 1), e["chambre"])
             for i, e in enumerate(d["liste"])]
    garde = d["garde"] if d["garde_ident"] == d["ident"] else None
    return affectation_invites(liste, amis, occupees, pieces, reservee, garde)


def invite_courant(zone: bytes, ident_sauvegarde: int, amis: set[int] | None, liee: bool = True,
                   pieces: int = INVITES_PIECES, reservee: bool = True) -> tuple[int, int]:
    """(Rang du premier invité logé, la Suite d'abord, ou -1 ; motif INVITES_MOTIF_*) : `present` - 1 de la zone."""
    loges, motif = invites_zone(zone, ident_sauvegarde, amis, liee, 0, pieces, reservee)
    premier = next((g for g in loges if g), 0)
    return premier - 1, motif


# --- v9 : boutiques ---
def enc_boutique(article: int, affiche: int = 0, etiquette: int = 0, bit: int = 0, drapeaux: int = BOUTIQUE_VALIDE,
                 texte: str | bytes = b"", utilisations: int = 0) -> bytes:
    """Entrée de la table des boutiques (80 octets) ; texte = nom de la vitrine (vide : nom par défaut)."""
    return (struct.pack("<IIIHBB", article & 0xFFFFFFFF, affiche & 0xFFFFFFFF, etiquette & 0xFFFFFFFF, bit & 0xFFFF,
                        drapeaux, utilisations) + _champ_texte(texte, BOUTIQUE_TEXTE) + bytes(8))


def dec_boutique(b: bytes) -> dict:
    a, af, e, bit, d, u = struct.unpack_from("<IIIHBB", b)
    return {"article": a, "affiche": af, "etiquette": e, "bit": bit, "drapeaux": d, "utilisations": u,
            "texte": b[16:16 + BOUTIQUE_TEXTE].split(b"\0")[0]}


def dec_boutiques_entete(b: bytes) -> dict:
    return dict(zip(BOUTIQUES_ENTETE, struct.unpack_from("<11I", b)))


def boutiques_compilees(entete_boutiques: bytes) -> bool | None:
    """Champ `compile` publié par le jeu v9 : True (articles AP compilés), False (build --define
    YKW2_AP_SANS_BOUTIQUES), None (non publié : jeu antérieur)."""
    c = struct.unpack_from("<I", entete_boutiques, 4)[0]
    if not c & BOUTIQUES_PUBLIE:
        return None
    return bool(c & BOUTIQUES_COMPILE)


def indices_boutiques_compiles(entete_boutiques: bytes) -> bool | None:
    """Évènement BOUTIQUE (indices automatiques) écrit par le jeu ? None : champ non publié (jeu v8 ou antérieur)."""
    c = struct.unpack_from("<I", entete_boutiques, 4)[0]
    if not c & BOUTIQUES_PUBLIE:
        return None
    return bool(c & BOUTIQUES_INDICES)


def bits_evt_boutique(e: dict) -> list[int]:
    """Bits d'articles d'un évènement BOUTIQUE (dans l'ordre, places vides omises, `quantite` au plus)."""
    bits = []
    for nom in BOUTIQUE_CHAMPS_BITS:
        v = e[nom]
        bits += [v & 0xFFFF, v >> 16 & 0xFFFF]
    return [b for b in bits[:min(e["quantite"], BOUTIQUE_BITS_EVT)] if b != BOUTIQUE_BIT_AUCUN]


def enc_bits_evt_boutique(bits: list[int]) -> dict:
    """Champs id, valeur, valeur2, etiquette, index d'un évènement BOUTIQUE pour au plus BOUTIQUE_BITS_EVT bits."""
    if len(bits) > BOUTIQUE_BITS_EVT:
        raise ValueError("trop de bits pour un évènement BOUTIQUE")
    m = list(bits) + [BOUTIQUE_BIT_AUCUN] * (BOUTIQUE_BITS_EVT - len(bits))
    return {nom: m[2 * i] | m[2 * i + 1] << 16 for i, nom in enumerate(BOUTIQUE_CHAMPS_BITS)}


def enc_table_boutiques(entrees: list[bytes]) -> bytes:
    """Table complète (CAP_BOUTIQUES entrées) : entrées triées par article (recherche dichotomique du jeu), zéros
    ensuite ; une clé en double est une erreur (le jeu n'en verrait qu'une)."""
    tri = sorted(entrees, key=lambda e: struct.unpack_from("<I", e)[0])
    cles = [struct.unpack_from("<I", e)[0] for e in tri]
    if len(tri) > CAP_BOUTIQUES or len(set(cles)) != len(cles) or 0 in cles:
        raise ValueError("table des boutiques invalide (capacité, doublon ou article nul)")
    return b"".join(tri) + bytes(TAILLE_BOUTIQUE * (CAP_BOUTIQUES - len(tri)))


def plage_octets_boutiques() -> tuple[int, int]:
    """(offset dans P, taille) de la plage des octets des bits de boutique (P + 0x14E .. P + 0x3AC)."""
    lo, hi = min(BOUTIQUE_OCTETS), max(BOUTIQUE_OCTETS)
    return P_FLAGS_OCTETS + lo, hi - lo + 1


def bits_boutiques(octets: bytes) -> set[int]:
    """Bits posés, depuis les octets de `plage_octets_boutiques()`."""
    lo = min(BOUTIQUE_OCTETS)
    out = set()
    for k in range(BOUTIQUE_BITS):
        i = BOUTIQUE_OCTETS[k >> 3] - lo
        if 0 <= i < len(octets) and octets[i] >> (k & 7) & 1:
            out.add(k)
    return out


def adr_octet_bit_boutique(adresse_p: int, bit: int) -> tuple[int, int]:
    """(adresse de l'octet, masque) du bit persistant `bit` dans la partie P."""
    return adresse_p + P_FLAGS_OCTETS + BOUTIQUE_OCTETS[bit >> 3], 1 << (bit & 7)


# --- v6 : randomizer de Yo-kai ---
def dec_rando_entete(b: bytes) -> dict:
    v = struct.unpack_from("<IIIHHIIIIIIIIIIIHH", b)
    return dict(zip(RANDO_ENTETE, v))


def rando_compile(entete_rando: bytes) -> int | None:
    """Champ `compile` publié par le jeu v6 : masque RANDO_RENCONTRES | RANDO_LOUPE (| RANDO_PAR_RENCONTRE en v10,
    | RANDO_LOUPE_DECOR avec le garde-fou de la loupe ; 0 : build --define YKW2_AP_SANS_RANDO_YOKAI), None (non publié :
    jeu antérieur)."""
    c = struct.unpack_from("<I", entete_rando, 4)[0]
    if not c & RANDO_PUBLIE:
        return None
    return c & (RANDO_RENCONTRES | RANDO_LOUPE | RANDO_PAR_RENCONTRE | RANDO_LOUPE_DECOR)


def enc_paires(paires: dict[int, int], cap: int) -> bytes:
    """Table de paires (origine, cible) triées par origine, identités exclues, complétée par des zéros."""
    lp = sorted((a & 0xFFFFFFFF, b & 0xFFFFFFFF) for a, b in paires.items() if a != b)
    if len(lp) > cap:
        raise ValueError(f"{len(lp)} paires (capacité {cap})")
    return b"".join(struct.pack("<II", a, b) for a, b in lp) + bytes(8 * (cap - len(lp)))


def enc_w(w, cap: int = CAP_RANDO_W) -> bytes:
    lw = sorted({x & 0xFFFFFFFF for x in w})
    if len(lw) > cap:
        raise ValueError(f"{len(lw)} rencontres (capacité {cap})")
    return struct.pack(f"<{len(lw)}I", *lw) + bytes(4 * (cap - len(lw)))


def dec_paires(b: bytes, n: int) -> dict[int, int]:
    return dict(struct.unpack_from("<II", b, 8 * i) for i in range(n))


def dec_w(b: bytes, n: int) -> list[int]:
    return list(struct.unpack_from(f"<{n}I", b))


def enc_especes(especes, cap: int = CAP_RANDO_ESPECES) -> bytes:
    """v10 : table des espèces du mélange par rencontre [(CHARA_PARAM, CHARA_BASE)] (id = rang), sans remplissage."""
    if len(especes) > cap:
        raise ValueError(f"{len(especes)} espèces (capacité {cap})")
    return b"".join(struct.pack("<II", p & 0xFFFFFFFF, b & 0xFFFFFFFF) for p, b in especes)


def enc_p(entrees, cap: int = CAP_RANDO_P) -> bytes:
    """v10 : entrées P (u32) triées par clé (bits 0-13), clés distinctes, sans remplissage."""
    le = sorted((x & 0xFFFFFFFF for x in entrees), key=lambda x: x & RANDO_P_CLE)
    if len(le) > cap:
        raise ValueError(f"{len(le)} entrées (capacité {cap})")
    cles = [x & RANDO_P_CLE for x in le]
    if cles != sorted(set(cles)):
        raise ValueError("entrées P : clés non distinctes ou non triées")
    return struct.pack(f"<{len(le)}I", *le)


# --- v7 : randomizer des boss ---
def dec_boss_entete(b: bytes) -> dict:
    v = struct.unpack_from("<IIIHHIIIIIIIIIII", b)
    return dict(zip(BOSS_ENTETE, v))


def boss_compile(entete_boss: bytes) -> int | None:
    """Champ `compile` publié par le jeu v7 : BOSS_COMPILE (0 : build --define YKW2_AP_SANS_RANDO_BOSS), None (non
    publié : jeu antérieur)."""
    c = struct.unpack_from("<I", entete_boss, 4)[0]
    if not c & BOSS_PUBLIE:
        return None
    return c & BOSS_COMPILE


def enc_boss_b(b: dict[int, int], cap: int = CAP_BOSS_B) -> bytes:
    """Table B : {place: donneur} triée par place, complétée par des zéros."""
    lp = sorted((p & 0xFFFFFFFF, d & 0xFFFFFFFF) for p, d in b.items())
    if len(lp) > cap:
        raise ValueError(f"{len(lp)} places de boss (capacité {cap})")
    return b"".join(struct.pack("<II", p, d) for p, d in lp) + bytes(8 * (cap - len(lp)))


def enc_boss_n(n: dict[int, tuple[int, int]], cap: int = CAP_BOSS_N) -> bytes:
    """Table N : {place: (espèce d'origine, espèce cible)} triée par place, complétée par des zéros."""
    lp = sorted((p & 0xFFFFFFFF, o & 0xFFFFFFFF, c & 0xFFFFFFFF) for p, (o, c) in n.items())
    if len(lp) > cap:
        raise ValueError(f"{len(lp)} boss sans script (capacité {cap})")
    return b"".join(struct.pack("<IIII", p, o, c, 0) for p, o, c in lp) + bytes(16 * (cap - len(lp)))


def dec_boss_b(b: bytes, n: int) -> dict[int, int]:
    return dict(struct.unpack_from("<II", b, 8 * i) for i in range(n))


def dec_boss_n(b: bytes, n: int) -> dict[int, tuple[int, int]]:
    out = {}
    for i in range(n):
        p, o, c, _r = struct.unpack_from("<IIII", b, 16 * i)
        out[p] = (o, c)
    return out


def nom_vitrine(objet: str, joueur: str | None = None, max_largeur: int | None = None) -> bytes:
    """Nom de vitrine conseillé : « objet (pour joueur) », une ligne, neutralisé, au plus NOM_TEXTE - 1
    octets (même traitement que le jeu). `max_largeur` : coupe à la largeur estimée (modèle du bandeau)."""
    t = f"{objet} (pour {joueur})" if joueur else objet
    b = copier_texte(t.encode("utf-8"), True)
    if max_largeur:
        b = copier_limite(b, max_largeur)
    return _champ_texte(b, NOM_TEXTE).split(b"\0")[0]


def spots_bits(spots: int) -> list[int]:
    """Index TBox (558..575) des bits de spots publiés dans l'en-tête (champ spots)."""
    return [TBOX_SPOT_PREMIER + k for k in range(TBOX_NOMBRE - TBOX_SPOT_PREMIER) if spots >> k & 1]


def victoire(h: dict) -> bool:
    """Critère de victoire (J2) : flag « partie terminée », ou chapitre >= 11 en secours ; partie chargée."""
    return bool(h["etat"] & ETAT_PARTIE) and bool(h.get("progression", 0)
                                                  & (PROGRESSION_VICTOIRE | PROGRESSION_APRES_JEU))


# --- Notifications : encodage et textes (mêmes règles que boite.cpp) ---
def texte_utf8(texte: str) -> bytes:
    """Texte -> octets UTF-8 d'une entrée (au plus NOTIF_TEXTE - 1, sans couper un caractère)."""
    b = texte.encode("utf-8")
    if len(b) > NOTIF_TEXTE - 1:
        b = b[:NOTIF_TEXTE - 1]
        while b and b[-1] & 0xC0 == 0x80:          # octets de continuation d'un caractère coupé
            b = b[:-1]
        if b and b[-1] >= 0xC0:                    # octet de tête sans sa suite
            b = b[:-1]
    return b


def enc_notif(numero: int, texte: bytes, duree: int = 0, drapeaux: int = 0) -> bytes:
    assert len(texte) < NOTIF_TEXTE
    return struct.pack("<IHBB", numero, duree, drapeaux, 0) + texte.ljust(NOTIF_TEXTE, b"\0")


def dec_notif(b: bytes) -> dict:
    n, d, dr, _ = struct.unpack_from("<IHBB", b)
    return {"numero": n, "duree": d, "drapeaux": dr, "texte": b[8:].split(b"\0")[0]}


def _octets_car(c: int) -> int:
    return 4 if c >= 0xF0 else 3 if c >= 0xE0 else 2 if c >= 0xC0 else 1


def largeur_car(b: bytes, i: int = 0) -> int:
    """Modèle de apLargeurCar : largeur estimée (demi-unités) du caractère UTF-8 en b[i]."""
    c = b[i]
    if c < 0x80:
        ch = chr(c)
        if ch in " il!.,:;'|()[]-Ijftr\"":
            return 2
        if ch in "mwMW@%&":
            return 6
        return 5 if "A" <= ch <= "Z" else 4
    if b[i:i + 3] == "€".encode():
        return 6
    if c == 0xC3 and i + 1 < len(b) and b[i + 1] >= 0x9F:
        return 4
    return 5


def largeur(texte: str | bytes) -> int:
    b = texte.encode() if isinstance(texte, str) else texte
    w, i = 0, 0
    while i < len(b) and b[i]:
        w += largeur_car(b, i)
        i += _octets_car(b[i])
    return w


def copier_limite(src: bytes, max_largeur: int = NOTIF_LARGEUR, cap: int = TAILLE_TAMPON) -> bytes:
    """Modèle de apCopierLimite : coupe src à max_largeur (estimée), suivi de "..." si coupé."""
    couper = largeur(src) > max_largeur
    limite = (max_largeur - 6 if max_largeur > 6 else 0) if couper else max_largeur
    reserve = 3 if couper else 0
    out, i, larg = bytearray(), 0, 0
    while i < len(src) and src[i]:
        n = _octets_car(src[i])
        lc = largeur_car(src, i)
        if larg + lc > limite or len(out) + n + reserve + 1 > cap:
            break
        out += src[i:i + n]
        i += n
        larg += lc
    return bytes(out) + (b"..." if couper else b"")


def copier_texte(src: bytes, neutral: bool = True) -> bytes:
    """Modèle de apCopierTexte : mono-ligne (0x0A, 0x0D et « \\n » -> espace), neutralisation."""
    out, i = bytearray(), 0
    while i < len(src) and src[i]:
        c = src[i]
        i += 1
        if c in (10, 13):
            c = 0x20
        elif c == 0x5C and i < len(src) and src[i] == 0x6E:
            c = 0x20
            i += 1
        elif neutral:
            c = {0x3C: 0x28, 0x5B: 0x28, 0x3E: 0x29, 0x5D: 0x29, 0x5C: 0x2F}.get(c, c)
        out.append(c)
    return bytes(out)


def neutraliser(b: bytes) -> bytes:
    return copier_texte(b, True)


def formater_notif(texte: str, de: str | None = None, max_largeur: int = NOTIF_LARGEUR,
                   une_ligne: bool = False) -> list[str]:
    """Texte(s) conseillé(s) pour le bandeau MONO-LIGNE (~121 demi-unités, E9C) : chaque texte tient
    sur une ligne, coupé avec « ... » au-delà de `max_largeur`. Avec `de` : une 2e notification
    « De : X » (ou, avec une_ligne, « texte (X) » sur la même ligne, coupé si besoin)."""
    texte = copier_texte(texte.encode(), False).decode()
    textes = [f"{texte} ({de})"] if de and une_ligne else [texte] + ([f"De : {de}"] if de else [])
    return [copier_limite(t.encode(), max_largeur).decode() for t in textes]


def texte_evt(e: dict) -> str:
    t = EVTS.get(e["type"], f"?{e['type']}")
    d = e["drapeaux"]
    if e["type"] == 1:
        dr = ",".join(n for b, n in ((1, "marqué-ouvert"), (2, "remplacé"), (4, "affichage-seul")) if d & b) or "-"
        return (f"#{e['numero']} COFFRE tbox={e['id']:#010x} index={e['index'] if e['index'] != 0xFFFFFFFF else '?'} "
                f"natif={e['valeur']:#010x}x{e['quantite']} rendu={e['valeur2']:#010x} etiquette={e['etiquette']} [{dr}]")
    if e["type"] == 2:
        dr = ",".join(n for b, n in ((1, "supprimé"), (2, "réussi"), (4, "substitué"), (8, "bit-posé"))
                      if d & b) or "échec"
        if d & EVT_OBJET_SUBSTITUE:
            idx = e["index"] if e["index"] != 0xFFFFFFFF else "-"
            return (f"#{e['numero']} OBJET_JEU objet={e['id']:#010x}x{e['quantite']} affiché={e['valeur2']:#010x} "
                    f"bit={idx} etiquette={e['etiquette']} retour={e['valeur']} [{dr}]")
        return f"#{e['numero']} OBJET_JEU objet={e['id']:#010x}x{e['quantite']} retour={e['valeur']} [{dr}]"
    if e["type"] == EVT_RECOMPENSE:
        dr = ",".join(n for b, n in ((RECOMPENSE_FIXE, "objets-fixes"), (RECOMPENSE_CHOIX, "choix"),
                                     (RECOMPENSE_DONNE, "donné")) if d & b) or "-"
        return (f"#{e['numero']} RECOMPENSE quête={e['id']} affiché={e['valeur']:#010x} etiquette={e['etiquette']} "
                f"[{dr}]")
    if e["type"] == EVT_BOUTIQUE:
        dernier = " [dernier]" if d & BOUTIQUE_EVT_DERNIER else ""
        return f"#{e['numero']} BOUTIQUE bits visibles={bits_evt_boutique(e)}{dernier}"
    if e["type"] in (3, 4):
        q = struct.unpack("<i", struct.pack("<I", e["valeur2"]))[0]
        return (f"#{e['numero']} {t} numero_don={e['valeur']} type={NOMS_DON.get(e['index'], e['index'])} "
                f"hash={e['id']:#010x} quantite={q} code={CODES.get(d, d)}")
    return f"#{e['numero']} {t} {e}"


# --- Compléments pour le client du mod (valeurs de la doc, pas de #define dans boite.h) ---
TAILLE_ENTETE = 0x100
TAILLE_DON, TAILLE_EVT, TAILLE_COFFRE = 16, 32, 16
EVT_COFFRE, EVT_OBJET_JEU, EVT_DON, EVT_DON_ECHEC = 1, 2, 3, 4
DON_OBJET, DON_ARGENT, DON_YOKAI = 1, 2, 3
CODE_OK, CODE_TYPE_INCONNU, CODE_OBJET_INCONNU, CODE_ECHEC_DON, CODE_PARTIE, CODE_QUANTITE = 0, 1, 2, 3, 4, 5
CODE_NON_LIEE = 6


def hachage_invitation(cle: str) -> int:
    """Hachage de l'objet du JEU d'une invitation (clé de `objets.json`, « invitation_<nom> ») : `crc32("ap_" + clé)`,
    la convention de `installation/invitations.py` qui ajoute ces objets au RomFS du joueur (identifiant à nous, absent
    du jeu d'origine ; `docs/systemes/archipelago_invites.md` §16)."""
    import zlib
    return zlib.crc32(("ap_" + cle).encode("ascii")) & 0xFFFFFFFF
ETAT_PARTIE, ETAT_TERRAIN, ETAT_STABLE, ETAT_BLOQUE, ETAT_ATTENTE, ETAT_PAUSE = 0x01, 0x02, 0x04, 0x08, 0x10, 0x20
ETAT_PANIQUE = 0x40          # le jeu a paniqué (svc Break) : enregistrement ApPanique (§28), bit collant
# Lieu du joueur (§29, branche ap/carte-suivi) : carte courante et position publiées dans l'en-tête (aucune lecture en
# plus : le tour de base lit déjà l'en-tête). ETAT_LIEU : ce jeu publie `carte` (0x80, CRC-32 du nom de la carte, 0 =
# aucune) ; ETAT_POSITION : `pos_x` / `pos_z` (0x84 / 0x88) valides à cette image.
ETAT_LIEU, ETAT_POSITION = 0x80, 0x100
POSITION_MAX = 1.0e6         # garde-fou : une coordonnée au-delà (ou non finie) n'est pas une position


def lieu_publie(etat: int, carte: int, pos_x: int, pos_z: int) -> tuple[int, tuple[float, float] | None] | None:
    """(hachage de la carte courante, position (x, z) ou None) publiés par le jeu ; None si le jeu ne publie pas le
    lieu (patch antérieur : bit ETAT_LIEU absent, les octets 0x80..0x8B y sont privés). Carte 0 : aucune carte (titre,
    chargement, pas de partie)."""
    if not etat & ETAT_LIEU:
        return None
    if not carte or not etat & ETAT_POSITION:
        return carte, None
    x, z = struct.unpack("<ff", struct.pack("<II", pos_x & 0xFFFFFFFF, pos_z & 0xFFFFFFFF))
    if not (x == x and z == z and abs(x) <= POSITION_MAX and abs(z) <= POSITION_MAX):
        return carte, None
    return carte, (x, z)
# drapeaux des évènements (§6)
EVT_COFFRE_MARQUE_OUVERT, EVT_COFFRE_REMPLACE, EVT_COFFRE_AFFICHAGE_SEUL = 0x01, 0x02, 0x04
EVT_OBJET_SAUTE, EVT_OBJET_REUSSI = 0x01, 0x02
# bloc de progression P (adresse publiée dans l'en-tête, champ adresse_p)
P_COMPTEUR, P_IDENT, P_LIAISON = 0x3B8, 0x3BC, 0x3B6
P_FLAGS_TBOX, TAILLE_FLAGS_TBOX = 0x3C4, 0x48      # 576 bits : bit i = flag TBox d'index i
# flags bit globaux (FUN_00412F08 / FUN_00413464) : flag i = bit i % 8 de l'octet P + 4 + i // 8 (sauvegardés,
# bloc 1) ; le client ne lit que des flags dont l'octet précède P_LIAISON (octets libres du mod ensuite)
P_FLAGS_GLOBAUX = 0x004
FLAG_GLOBAL_MAX = (P_LIAISON - P_FLAGS_GLOBAUX) * 8 - 1
# Yo-criminels (docs/systemes/archipelago_amis_criminels.md §3) : octet `wantedNN` (flag de catégorie 6 n° 396 + N de
# flag_config ; octets de catégorie 6 à P + 0x144 + i) = P + 0x2D0 + N, N = 1..52 : nombre d'étapes gagnées contre le
# criminel N (+1 à chaque victoire, ev76_0400 ; jamais remis à zéro) [C]
P_CRIMINELS, NB_CRIMINELS = 0x2D0, 52
# Détection de secours d'un don de script fait SANS table de substitution (client absent, table perdue au
# relancement : le script donne l'objet d'origine, aucun bit de spot n'est posé, §12.2) : bit de spot -> flag bit
# global « évènement vu » posé à la fin de la scène jouée juste après le don dans le même script, et nulle part
# ailleurs [C]. Filet : c01_trigger RunCmd_Phase16, AddItem 0x4806448E puis RunEvent('ev01_0800') (seul appel de
# cette scène) ; crc32("ev01_0800") = 0x64082BC4 = flag 113 (catégorie 0 de flag_config_0.01), qu'aucun script
# n'écrit. Seul le Filet en a besoin : seul emplacement qui accepte la progression (archipelago_logique_audit.md G1-3).
SPOTS_SECOURS = {558: 113}
INDEX_INCONNU = 0xFFFFFFFF
# bloc des quêtes Q = *(*0x00815244 + 0x10), HORS boîte (le client le suit lui-même, archipelago_boss.md §10) :
# phase de la quête n (4e champ de QUEST_CONFIG, nom « qs%04d ») = octet Q + 4 + n, n < 192 (GetQuestPhase
# 0x004BE680 -> FUN_0041015C -> FUN_00646EB8) ; 255 = terminée. 0x815244 est un pointeur partagé {objet, compteur}
# créé et libéré avec P et les autres blocs de sauvegarde (FUN_005D9438 / FUN_005DE030) ; le chargement d'une
# sauvegarde relit le bloc 0xC EN PLACE (Q+4..Q+0xF3, FUN_003FC408).
ADR_SINGLETON_QUETES = 0x00815244
OFF_OBJET_SINGLETON = 0x10
Q_PHASES, NB_QUETES = 0x004, 192
PHASE_QUETE_TERMINEE = 255
# rang de montre réel (valeur de la condition GetWatchRank, 0 = E … 5 = S) : octet O + 0x2E, O = *(*0x0081521C + 0x10)
# (FUN_0040F420 ; 0x0081521C est un pointeur partagé {objet, compteur} comme 0x00815244 ; l'objet +8 est le bloc 0xF2
# de la sauvegarde, rang à +0x26 du bloc [C, archipelago_objets_cles_v11.md §5.1 ; sauvegardes de l'humain]).
ADR_SINGLETON_RANG = 0x0081521C
OFF_RANG_MONTRE = 0x2E
RANG_MONTRE_MAX = 5
# adresses de tas plausibles pour un objet du jeu (tas 0x08000000.., tas linéaire 0x14000000.. / 0x30000000..)
ADR_TAS_MIN, ADR_TAS_MAX = 0x08000000, 0x40000000

# --- Enregistreur de panique (§28, src/archipelago/panique.cpp ; absent avec --define YKW2_AP_SANS_PANIQUE) ---
# ApPanique (0x200 octets) à 0x23E00, dans la zone v10 (taille et version inchangées). Le jeu y recopie, à la panique
# (FUN_001371D4, svc Break « PANIC »), l'adresse de retour empilée (après le `bl` fautif), r4..r11 et 96 mots de la pile
# de la fonction qui a paniqué, pose ETAT_PANIQUE dans l'en-tête, puis attend (au plus 20 s, l'émulateur tourne) que le
# client écrive `lu` = `compte` avant de rendre la main (svc Break comme d'origine).
OFF_PANIQUE, TAILLE_PANIQUE, PANIQUE_MOTS = 0x23E00, 0x200, 96
PANIQUE_OFF_LU = 0x40
PANIQUE_CHAMPS = ("compte", "appelant", "raison", "pile")
# Plages d'adresses de code (adresses de retour plausibles dans la pile) : .text d'origine, zone d'extension (code du mod
# relogé ou ajouté, après la boîte : 0x0091C000 + 0x24000).
CODE_TEXTE = (0x00100000, 0x006F4000)
CODE_EXTENSION = (0x00940000, 0x00A00000)


def enc_panique(compte: int, appelant: int, raison: int = 0, pile: int = 0, regs=(), images: int = 0, etat: int = 0,
                chapitre: int = 0, pas: int = 0, terrain: int = 0, lu: int = 0, attendu_ms: int = 0,
                mots=()) -> bytes:
    """Enregistrement tel que le jeu l'écrit (tests, ap_boite_test.py)."""
    r = list(regs)[:8] + [0] * (8 - len(list(regs)[:8]))
    m = list(mots)[:PANIQUE_MOTS] + [0] * (PANIQUE_MOTS - len(list(mots)[:PANIQUE_MOTS]))
    return (struct.pack("<4I8I2I2HI2I", compte, appelant, raison, pile, *r, images, etat, chapitre, pas, terrain, lu,
                        attendu_ms) + bytes(14 * 4) + struct.pack(f"<{PANIQUE_MOTS}I", *m))


def dec_panique(b: bytes) -> dict:
    compte, appelant, raison, pile = struct.unpack_from("<4I", b)
    regs = list(struct.unpack_from("<8I", b, 0x10))
    images, etat, chapitre, pas, terrain, lu, attendu = struct.unpack_from("<2I2HI2I", b, 0x30)
    mots = list(struct.unpack_from(f"<{PANIQUE_MOTS}I", b, 0x80))
    return {"compte": compte, "appelant": appelant, "raison": raison, "pile": pile, "regs": regs, "images": images,
            "etat": etat, "chapitre": chapitre, "pas": pas, "terrain_numero": terrain, "lu": lu, "attendu_ms": attendu,
            "mots": mots}


def est_code(v: int) -> bool:
    return CODE_TEXTE[0] <= v < CODE_TEXTE[1] or CODE_EXTENSION[0] <= v < CODE_EXTENSION[1]


def retours_panique(d: dict) -> list[tuple[int, int]]:
    """Mots de la pile qui ressemblent à des adresses de retour (code d'origine ou du mod) : [(décalage, adresse)].
    Bit 0 (retour Thumb) gardé tel quel. Les adresses se lisent avec la carte du build installé (ykw2.map)."""
    return [(4 * i, v) for i, v in enumerate(d["mots"]) if est_code(v & ~1)]


def texte_panique(d: dict) -> str:
    """Une ligne pour le journal du client."""
    r = ", ".join(f"+{o:#x}:{v:#010x}" for o, v in retours_panique(d)) or "aucune"
    return (f"panique n° {d['compte']} (raison {d['raison']}) : retour {d['appelant']:#010x} (le `bl` fautif est juste "
            f"avant), pile {d['pile']:#010x}, image {d['images']}, état {d['etat']:#x}, chapitre {d['chapitre']}-"
            f"{d['pas']}, terrain n° {d['terrain_numero']} ; r4..r11 "
            + " ".join(f"{x:#x}" for x in d["regs"]) + f" ; adresses de retour dans la pile : {r}")
